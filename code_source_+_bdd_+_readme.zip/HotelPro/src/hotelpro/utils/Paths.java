/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.utils;

import java.io.File;

/**
 *
 * @author Serge
 */
public class Paths {

    public Paths() {
    }
    
    public String recupererHomeDirectory() {
        return (System.getProperty("user.home") + File.separator + "hotel");
    }
    public String recupererHomePath() {
        return (new Paths().recupererHomeDirectory() + File.separator);
    }
    
    /**
     * *** Scans ****
     */
//    public static String SCANS_DIRECTORY = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "HOTELPRO CLIENTS";
    public String recupererScansDirectory() {
        return (new Paths().recupererHomePath() + "HOTELPRO CLIENTS");
    }
//    public static String SCANS_PATH = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "HOTELPRO CLIENTS" + File.separator;
    public String recupererScansPath() {
        return (new Paths().recupererScansDirectory() + File.separator);
    }
    /**
     * *** Scanner ****
     */
//    public static String SCANNER_DIRECTORY = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "HOTELPRO CLIENTS" + File.separator + "SCANNER";
    public String recupererScannerDirectory() {
        return (new Paths().recupererHomePath() + "SCANNER");
    }
    /**
     * *** Clients ****
     */
//    public static String CLIENTS_PHOTOS_PASSPORT_DIRECTORY = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "HOTELPRO CLIENTS" + File.separator + "CLIENTS PASSPORT PHOTOS";
    public String recupererClientsPhotosPassportDirectory() {
        return (new Paths().recupererHomePath() + "CLIENTS PASSPORT PHOTOS");
    }
//    public static String CLIENTS_PHOTOS_PASSPORT_PATH = System.getProperty("user.home") + File.separator + "Documents" + File.separator + "HOTELPRO CLIENTS" + File.separator + "CLIENTS PASSPORT PHOTOS" + File.separator;
    public String recupererClientsPhotosPassportPath() {
        return (new Paths().recupererClientsPhotosPassportDirectory() + File.separator);
    }

    public String recupererDataDirectory() {
        return (new Paths().recupererHomePath() + "data");
    }

//    public static String DATA_DIRECTORY = new Paths().recupererDataDirectory();
    /**
     * *** Database Files ****
     */
//    public static String DATABASE_FILES_DIRECTORY = new Paths().recupererDataDirectory() + File.separator + "database_files";
    public String recupererDataBaseFilesDirectory() {
        return (new Paths().recupererDataDirectory() + File.separator + "database_files");
    }
//    public static String DATABASE_FILES_PATH = new Paths().recupererDataDirectory() + File.separator + "database_files" + File.separator;

    public String recupererDataBaseFilesPath() {
        return (new Paths().recupererDataBaseFilesDirectory() + File.separator);
    }

    /**
     * *** Personal sounds ****
     */
//    public static String PERSONAL_SOUNDS_DIRECTORY = new Paths().recupererDataDirectory() + File.separator + "personal_sounds";
    public String recupererPersonalSoundsDirectory() {
        return (new Paths().recupererDataDirectory() + File.separator + "personal_sounds");
    }
//    public static String PERSONAL_SOUNDS_PATH = new Paths().recupererDataDirectory() + File.separator + "personal_sounds" + File.separator;

    public String recupererPersonalSoundsPath() {
        return (new Paths().recupererPersonalSoundsDirectory() + File.separator);
    }

    /**
     * *** Hardware Address ****
     */
//    public static String HARDWARE_ADDRESS_DIRECTORY = new Paths().recupererDataDirectory() + File.separator + "hardware_address";
    public String recupererHardwareAddressDirectory() {
        return (new Paths().recupererDataDirectory() + File.separator + "hardware_address");
    }
//    public static String HARDWARE_ADDRESS_PATH = new Paths().recupererDataDirectory() + File.separator + "hardware_address" + File.separator;

    public String recupererHardwareAddressPath() {
        return (new Paths().recupererHardwareAddressDirectory() + File.separator);
    }

    /**
     * *** Software Users ****
     */
//    public static String USERS_PHOTOS_PASSPORT_DIRECTORY = new Paths().recupererDataDirectory() + File.separator + "users_passport_photos";
    public String recupererUsersPhotosPassportDirectory() {
        return (new Paths().recupererDataDirectory() + File.separator + "users_passport_photos");
    }
//    public static String USERS_PHOTOS_PASSPORT_PATH = new Paths().recupererDataDirectory() + File.separator + "users_passport_photos" + File.separator;

    public String recupererUsersPhotosPassportPath() {
        return (new Paths().recupererUsersPhotosPassportDirectory() + File.separator);
    }
    /**
     * *** Logs ****
     */
//    public static String LOGS_DIRECTORY = new Paths().recupererDataDirectory() + File.separator + "logs";
    public String recupererLogsDirectory() {
        return (new Paths().recupererDataDirectory() + File.separator + "logs");
    }
//    public static String LOGS_PATH = new Paths().recupererDataDirectory() + File.separator + "logs" + File.separator;
    public String recupererLogsPath() {
        return (new Paths().recupererLogsDirectory() + File.separator);
    }
    /**
     * *** Staff ****
     */
//    public static String STAFF_PHOTOS_PASSPORT_DIRECTORY = new Paths().recupererDataDirectory() + File.separator + "staff_passport_photos";
    public String recupererStaffPhotosPassportDirectory() {
        return (new Paths().recupererDataDirectory() + File.separator + "staff_passport_photos");
    }
//    public static String STAFF_PHOTOS_PASSPORT_PATH = new Paths().recupererDataDirectory() + File.separator + "staff_passport_photos" + File.separator;
    public String recupererStaffPhotosPassportPath() {
        return (new Paths().recupererStaffPhotosPassportDirectory() + File.separator);
    }
    
}
