/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.utils;

import hotelpro.entities.Accreditation;
import hotelpro.entities.Bar;
import hotelpro.entities.BarVente;
import hotelpro.entities.Bloc;
import hotelpro.entities.Boisson;
import hotelpro.entities.BoissonSeuil;
import hotelpro.entities.CaisseBar;
import hotelpro.entities.CaisseDivers;
import hotelpro.entities.CaissePiscine;
import hotelpro.entities.CaisseReservation;
import hotelpro.entities.CaisseRestaurant;
import hotelpro.entities.CaracteristiqueChambre;
import hotelpro.entities.CategorieBoisson;
import hotelpro.entities.CategorieChambre;
import hotelpro.entities.CategorieClient;
import hotelpro.entities.CategorieLit;
import hotelpro.entities.CategorieMenu;
import hotelpro.entities.Chambre;
import hotelpro.entities.Client;
import hotelpro.entities.Etage;
import hotelpro.entities.Facture;
import hotelpro.entities.FactureTable;
import hotelpro.entities.FluxPrixBoisson;
import hotelpro.entities.FluxPrixMenu;
import hotelpro.entities.Lit;
import hotelpro.entities.Log;
import hotelpro.entities.Menu;
import hotelpro.entities.Pays;
import hotelpro.entities.Penalite;
import hotelpro.entities.Piscine;
import hotelpro.entities.Reservation;
import hotelpro.entities.Restaurant;
import hotelpro.entities.RestaurantVente;
import hotelpro.entities.Serveur;
import hotelpro.entities.SituationChambre;
import hotelpro.entities.StockBoisson;
import hotelpro.entities.TableHotel;
import hotelpro.entities.TypeChambre;
import hotelpro.entities.Utilisateur;
import hotelpro.entities.VenteAccesPiscine;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.text.JTextComponent;

/**
 *
 * @author Serge
 */
public class Hotel {

    public Hotel() {
    }

    //	Controle des reservations et liberation des chambres
    public static void termReservation() {
        Hotel hotel = new Hotel();
        String delaiConfirmation = "72:00:00.0";
        List<Reservation> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT r FROM Reservation r WHERE r.etatReservation = 'RESERVE' "
                + "OR r.etatReservation = 'CONFIRME'");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }

        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (Exception e) {

            for (Iterator<Reservation> it = list.iterator(); it.hasNext();) {
                Reservation reservation = it.next();
                if ("CONFIRME".equals(reservation.getEtatReservation())) {
                    String date = Hotel.returnNow();
                    String timeDiff = Hotel.selectTimeDiff(date, reservation.getDateDepart());
                    if (timeDiff.charAt(0) != '-') {
                        Chambre chambre = hotel.listerChambreParId((int) reservation.getChambre());
                        chambre.setStatut("DISPONIBLE");
                        em.getTransaction().begin();
                        em.merge(chambre);
                        em.getTransaction().commit();
                        em.getTransaction().begin();
                        reservation.setEtatReservation("DEPASSE");
                        em.merge(reservation);
                        em.getTransaction().commit();
                    }
                } else {
                    String date = Hotel.returnNow();
                    String addTime = Hotel.selectAddTime(reservation.getDateReservation(), delaiConfirmation);
                    String timeDiff = Hotel.selectTimeDiff(date, addTime);
                    if (timeDiff.charAt(0) != '-') {
                        Chambre chambre = hotel.listerChambreParId((int) reservation.getChambre());
                        chambre.setStatut("DISPONIBLE");
                        em.getTransaction().begin();
                        em.merge(chambre);
                        em.getTransaction().commit();
                        em.getTransaction().begin();
                        reservation.setEtatReservation("ANNULE");
                        em.merge(reservation);
                        em.getTransaction().commit();
                    }
                }
            }
        }
        em.close();
        emf.close();
    }

    public static String returnNow() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createNativeQuery("SELECT NOW()");
        em.getTransaction().begin();
        String now = String.valueOf(query.getSingleResult());
        em.close();
        emf.close();
        return now;
    }

    public static String selectAddTime(String temps_initial, String temps_a_ajouter) {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/hotel";
            String user = "root";
            String passwd = "amaterasu";

            Connection conn = DriverManager.getConnection(url, user, passwd);
            try (java.sql.Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)) {
                String query = "SELECT ADDTIME('" + temps_initial + "','" + temps_a_ajouter + "')";
                ResultSet res = state.executeQuery(query);
                res.next();
                return res.getString("ADDTIME('" + temps_initial + "','" + temps_a_ajouter + "')");
            }
        } catch (ClassNotFoundException | SQLException | NullPointerException e) {
        }
        return null;
    }

    public static String selectTimeDiff(String temps1, String temps2) {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/hotel";
            String user = "root";
            String passwd = "amaterasu";

            Connection conn = DriverManager.getConnection(url, user, passwd);
            try (java.sql.Statement state = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)) {
                String query = "SELECT TIMEDIFF('" + temps1 + "','" + temps2 + "')";
                ResultSet res = state.executeQuery(query);
                res.next();
                return Hotel.recupererTempsDansMessage(res.getString("TIMEDIFF('" + temps1 + "','" + temps2 + "')"));
            }
        } catch (ClassNotFoundException | SQLException | NullPointerException e) {
            return Hotel.recupererTempsDansMessage(e.getMessage());
        }
    }

    public static int selectNbJoursFromTime(String time) {
        int heure = 0;
        try {
            heure = (int) Integer.parseInt(String.valueOf(
                    new StringTokenizer(time, ":").nextToken()));
        } catch (NumberFormatException numberFormatException) {
        }
        float nbJours = heure / 24;

        int partieEntiereNbJours = 0;
        try {
            partieEntiereNbJours = (int) Integer.parseInt(String.valueOf(
                    new StringTokenizer(String.valueOf(nbJours), ":").nextToken()));
        } catch (NumberFormatException numberFormatException) {
        }
        if (nbJours > partieEntiereNbJours) {
            partieEntiereNbJours += 1;
        }
        return partieEntiereNbJours;
    }

    public static String recupererTempsDansMessage(String message) {
        String recherche = " ";
        try {
            StringTokenizer stringTokenizer = new StringTokenizer(message, "'");

            recherche = stringTokenizer.nextToken();

            while (!recherche.contains(":")) {
                recherche = stringTokenizer.nextToken();
            }
        } catch (Exception e) {
        }
        return recherche;
    }

    public static void refreshEntitiesBar() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Bar> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT b FROM Bar b");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesBarVente() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.BarVente> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT b FROM BarVente b");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesBloc() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Bloc> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT b FROM Bloc b");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesBoisson() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Boisson> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT b FROM Boisson b");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCaisseBar() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CaisseBar> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CaisseBar c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCaisseDivers() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CaisseDivers> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CaisseDivers c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCaisseRestaurant() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CaisseRestaurant> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CaisseRestaurant c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCaissePiscine() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CaissePiscine> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CaissePiscine c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCaisseReservation() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CaisseReservation> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CaisseReservation c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCaracteristiqueChambre() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CaracteristiqueChambre> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CaracteristiqueChambre c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCarteFidelite() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CarteFidelite> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CarteFidelite c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCategorieBoisson() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CategorieBoisson> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CategorieBoisson c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCategorieChambre() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CategorieChambre> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CategorieChambre c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCategorieClient() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CategorieClient> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CategorieClient c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCategorieLit() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CategorieLit> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CategorieLit c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesCategorieMenu() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.CategorieMenu> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM CategorieMenu c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesChambre() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Chambre> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Chambre c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesClient() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Client> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Client c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesEtage() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Etage> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT e FROM Etage e");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesFacture() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Facture> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT f FROM Facture f");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesFactureTable() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.FactureTable> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT f FROM FactureTable f");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesFluxPrixBoisson() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.FluxPrixBoisson> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT f FROM FluxPrixBoisson f");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesFluxPrixMenu() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.FluxPrixMenu> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT f FROM FluxPrixMenu f");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesLit() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Lit> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT l FROM Lit l");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesMenu() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Menu> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT m FROM Menu m");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesPenalite() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Penalite> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT p FROM Penalite p");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesPerte() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Perte> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT p FROM Perte p");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesPiscine() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Piscine> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT p FROM Piscine p");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesReservation() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Reservation> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT r FROM Reservation r");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesRestaurant() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Restaurant> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT r FROM Restaurant r");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesRestaurantVente() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.RestaurantVente> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT r FROM RestaurantVente r");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesSituationChambre() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.SituationChambre> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT s FROM SituationChambre s");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesServeur() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Serveur> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT s FROM Serveur s");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesStockBoisson() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.StockBoisson> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT s FROM StockBoisson s");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesTableHotel() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.TableHotel> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT t FROM TableHotel t");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesTypeChambre() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.TypeChambre> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT t FROM TypeChambre t");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesUtilisateur() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.Utilisateur> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT u FROM Utilisateur u");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

    public static void refreshEntitiesVenteAccesPiscine() {
        javax.persistence.EntityManager entityManager;
        javax.persistence.Query query;
        java.util.List<hotelpro.entities.VenteAccesPiscine> list;
        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT v FROM VenteAccesPiscine v");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);
    }

//    Utilisateurs, Accreditation
    public List<Utilisateur> listerUtilisateurs() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT u FROM Utilisateur u");
        List<Utilisateur> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public Utilisateur listerUtilisateurParID(int id) {
        List<Utilisateur> listUtilisateurs = new Hotel().listerUtilisateurs();
        for (Utilisateur utilisateur : listUtilisateurs) {
            if ((int) utilisateur.getId() == id) {
                return utilisateur;
            }
        }
        return null;
    }

    public Utilisateur listerUtilisateurParLogin(String login) {
        try {
            List<Utilisateur> listUtilisateurs = new Hotel().listerUtilisateurs();
            for (Utilisateur utilisateur : listUtilisateurs) {
                if (utilisateur.getLogin().equals(login)) {
                    return utilisateur;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public Utilisateur authentifier(Utilisateur utilisateur) throws NoSuchAlgorithmException {
        List<Utilisateur> list = new Hotel().listerUtilisateurs();
        for (Utilisateur user : list) {
            if (utilisateur.getLogin().equals(user.getLogin()) && new Hotel().sha1(utilisateur.getPasswd()).equals(user.getPasswd())) {
                return user;
            }
        }
        return utilisateur;
    }

    public Utilisateur authentifierAdmin(Utilisateur utilisateur) throws NoSuchAlgorithmException {
        utilisateur.setAccreditation("Administrateur");
        List<Utilisateur> list = new Hotel().listerUtilisateurs();
        for (Utilisateur user : list) {
            if (utilisateur.getLogin().equals(user.getLogin()) && new Hotel().sha1(utilisateur.getPasswd()).equals(user.getPasswd()) && utilisateur.getAccreditation().equals(user.getAccreditation())) {
                return user;
            }
        }
        return utilisateur;
    }

    public List<Accreditation> listerAccreditations() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT a FROM Accreditation a ORDER BY a.libelle ASC");
        List<Accreditation> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public long listerMaxIdAccreditation() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(a.id) FROM Accreditation a");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    //Logs
    public List<Log> listerLogs() {
        List<Log> list = new LinkedList<>();
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            Query query = em.createQuery("SELECT l FROM Log l");
            list = query.getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }

    public void majLog(Log log) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Log> listLogs = new Hotel().listerLogs();
        em.persist(log);
        listLogs.add(log);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<Log> merged = new ArrayList<>(listLogs.size());
            for (Log l : listLogs) {
                merged.add(em.merge(l));
            }
            listLogs.clear();
            listLogs.addAll(merged);
        }
    }

    public long listerMaxIdInfo() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(i.id) FROM Info i");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerMaxIdCarteFidelite() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT Max(c.id) from carte_fidelite c");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerMaxIdCarteFideliteParClient(Client client) {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT Max(id) from carte_fidelite c where c.client = " + client.getId());
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerMaxIdCategorieClient() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(c.id) FROM categorie_client c");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    //	Events, Components et JPopupMenu
    public JPopupMenu clicDroit(MouseEvent evt, final JTextComponent jTextComponent) {
        JPopupMenu jPopupMenu = new JPopupMenu();

        JMenuItem jMenuItemCopy = new JMenuItem("Copy");
        jMenuItemCopy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                jTextComponent.copy();
            }
        });

        JMenuItem jMenuItemCut = new JMenuItem("Cut");
        jMenuItemCut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                jTextComponent.cut();
            }
        });

        JMenuItem jMenuItemPaste = new JMenuItem("Paste");
        jMenuItemPaste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                jTextComponent.paste();
            }
        });


        jPopupMenu.add(jMenuItemCopy);
        jPopupMenu.add(jMenuItemCut);
        jPopupMenu.add(jMenuItemPaste);

        return jPopupMenu;
    }

    public String entreeKeyTyped(KeyEvent evt) {
        String recherche = "";
        StringTokenizer stringTokenizer = new StringTokenizer(evt.toString(), ",");
        for (int i = 0; i < stringTokenizer.countTokens(); i++) {
            stringTokenizer.nextToken();
            if (i == 2) {
                recherche += stringTokenizer.nextToken();
            }
        }

        stringTokenizer = new StringTokenizer(recherche, "=");
        for (int i = 0; i < stringTokenizer.countTokens(); i++) {
            stringTokenizer.nextToken();
            if (i == 0) {
                recherche = stringTokenizer.nextToken();
            }
        }
        return recherche;
    }

    public String sha1(String input) throws NoSuchAlgorithmException {
        MessageDigest mDigest = MessageDigest.getInstance("SHA1");
        byte[] result = mDigest.digest(input.getBytes());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < result.length; i++) {
            sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
        }

        return sb.toString();
    }

    //	Clients
    public List<Client> listerClients() {
        List<Client> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsOrderByNomAsc() {
        List<Client> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c ORDER BY c.nom ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsOrderByPrenoms() {
        List<Client> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c ORDER BY c.prenoms");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<String> listerDistinctNomClients() {
        List<String> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT DISTINCT c.nom FROM Client c ORDER BY c.nom ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<String> listerPrenomsClients() {
        List<String> list = new LinkedList<>();
        try {
            List<Client> listClients = new Hotel().listerClientsOrderByPrenoms();
            for (Client client : listClients) {
                list.add(client.getPrenoms());
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Client> listerClientsByNom(String nom) {
        Hotel hotel = new Hotel();
        List<Client> list = new LinkedList<>();
        try {
            List<Client> listClients = hotel.listerClients();
            for (Client client : listClients) {
                if (client.getNom().equals(nom)) {
                    list.add(client);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Client> listerClientsByNomOrderByPrenom(String nom) {
        Hotel hotel = new Hotel();
        List<Client> list = new LinkedList<>();
        try {
            List<Client> listClients = hotel.listerClientsOrderByPrenoms();
            for (Client client : listClients) {
                if (client.getNom().equals(nom)) {
                    list.add(client);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Client> listerClientsOrdonnesParNom() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParNomComme(String nom) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.nom LIKE '%" + nom + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParPrenomComme(String prenom) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.prenoms LIKE '%" + prenom + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParSurnomComme(String surnom) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.surnom LIKE '%" + surnom + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParTelephoneComme(String telephone) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.mobilePerso LIKE '%" + telephone + "%' OR c.mobilePro LIKE '%" + telephone + "%' OR c.fixePerso LIKE '%" + telephone + "%' OR c.fixePro LIKE '%" + telephone + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParFaxComme(String fax) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.fax LIKE '%" + fax + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParSiteWebComme(String site) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.website LIKE '%" + site + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParSocieteComme(String societe) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.societe LIKE '%" + societe + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParProfessionComme(String profession) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.profession LIKE '%" + profession + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParAdresseComme(String adresse) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.adresse LIKE '%" + adresse + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParAnniversaireComme(String anniversaire) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.anniversaire LIKE '%" + anniversaire + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientsParEmailComme(String email) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Client c WHERE c.email LIKE '%" + email + "%' ORDER BY c.nom ASC");
        List<Client> list = query.getResultList();
        em.close();
        emf.close();
        return list;
    }

    public List<Client> listerClientParCategorieClient(CategorieClient categorieClient) {
        List<Client> list = new LinkedList<>();
        try {
            Hotel hotel = new Hotel();
            List<Client> listClients = hotel.listerClientsOrdonnesParNom();

            for (Client client : listClients) {
                if ((int) client.getCategorieClient() == (int) categorieClient.getId()) {
                    list.add(client);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Client listerClientParNomComplet(String nom_complet) {
        Hotel hotel = new Hotel();
        try {
            List<Client> listClients = hotel.listerClients();
            for (Client client : listClients) {
                if ((client.getNom() + " " + client.getPrenoms()).equals(nom_complet)) {
                    return client;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public Client listerClientParNomPrenoms(String nom, String prenoms) {
        try {
            List<Client> listClients = new Hotel().listerClients();
            for (Client client : listClients) {
                if (client.getNom().equals(nom) && (client.getPrenoms().equals(prenoms))) {
                    return client;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public Client listerClientParId(int id) {
        try {
            List<Client> list = new Hotel().listerClients();
            for (Client client : list) {
                if ((int) client.getId() == id) {
                    return client;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Client> ListerDistinctClientsByNom(String string) {
        List<Client> list = new LinkedList<>();
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            Query query = em.createQuery("SELECT c FROM Client c WHERE c.nom LIKE " + string + "'% ORDER BY c.nom ASC");
            list = query.getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }

//    Categories des Clients
    public CategorieClient listerCategorieClientParId(int id) {
        try {
            List<CategorieClient> list = new Hotel().listerCategoriesClientOrderByDesignationASC();
            for (CategorieClient categorieClient : list) {
                if ((int) categorieClient.getId() == id) {
                    return categorieClient;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<CategorieClient> listerCategoriesClientOrderByDesignationASC() {
        List<CategorieClient> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CategorieClient c ORDER BY c.designation ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public CategorieClient listerCategorieClientParDesignation(String designation) {
        try {
            List<CategorieClient> list = new Hotel().listerCategoriesClientOrderByDesignationASC();
            for (Iterator<CategorieClient> it = list.iterator(); it.hasNext();) {
                CategorieClient categorieClient = it.next();
                if (categorieClient.getDesignation().equals(designation)) {
                    return categorieClient;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

//	Profession des Clients
    public List<String> ListerDistinctProfessions() {
        List<String> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT DISTINCT c.profession FROM Client c ORDER BY c.profession ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

//	Reservations
    public List<Reservation> listerReservations() {
        List<Reservation> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT r FROM Reservation r");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<Reservation> listerReservationsEnCoursParClient(Client client) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        List<Reservation> listReservations = new LinkedList<>();
        try {
            listReservations = hotel.listerReservations();
        } catch (Exception e) {
        }
        for (Reservation reservation : listReservations) {
            try {
                if ((int) reservation.getClient() == (int) client.getId()) {
                    if ("CONFIRME".equals(reservation.getEtatReservation())) {
                        list.add(reservation);
                    }

                    if ("RESERVE".equals(reservation.getEtatReservation())) {
                        list.add(reservation);
                    }
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<Reservation> listerVieillesReservationsParClient(Client client) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        List<Reservation> listReservations = hotel.listerReservations();
        for (Reservation reservation : listReservations) {
            try {
                if ((int) reservation.getClient() == (int) client.getId()) {
                    if ("ANNULE".equals(reservation.getEtatReservation())) {
                        list.add(reservation);
                    }
                    if ("DEPASSE".equals(reservation.getEtatReservation())) {
                        list.add(reservation);
                    }
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<Reservation> listerReservationsFacturablesParClient(Client client) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        List<Reservation> listReservations = new LinkedList<>();
        try {
            listReservations = hotel.listerReservations();
        } catch (Exception e) {
        }
        for (Reservation reservation : listReservations) {
            try {
                if ((int) reservation.getClient() == (int) client.getId()) {
                    if ("CONFIRME".equals(reservation.getEtatReservation())) {
                        list.add(reservation);
                    }

                    if ("DEPASSE".equals(reservation.getEtatReservation())) {
                        list.add(reservation);
                    }
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<Reservation> listerReservationsOrderByIdDesc() {
        List<Reservation> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT r FROM Reservation r ORDER BY r.id DESC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<Reservation> listerReservationsParClient(Client client) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        List<Reservation> listReservations = hotel.listerReservationsOrderByIdDesc();
        for (Reservation reservation : listReservations) {
            try {
                if (reservation.getClient() == (int) client.getId()) {
                    list.add(reservation);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<Reservation> listerReservantsPartants() {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        try {
            List<Reservation> listReservations = hotel.listerReservations();
            for (Reservation reservation : listReservations) {
                if (new StringTokenizer(reservation.getDateDepart(), " ").nextToken().equals(new java.sql.Date(new Date().getTime()).toString())) {
                    list.add(reservation);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Reservation> listerReservantsPartants(Date date) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        try {
            List<Reservation> listReservations = hotel.listerReservations();
            for (Reservation reservation : listReservations) {
                if (new StringTokenizer(reservation.getDateDepart(), " ").nextToken().equals(new java.sql.Date(date.getTime()).toString())) {
                    list.add(reservation);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Reservation> listerReservantsPartants(java.sql.Date date) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        try {
            List<Reservation> listReservations = hotel.listerReservations();
            for (Reservation reservation : listReservations) {
                if (new StringTokenizer(reservation.getDateDepart(), " ").nextToken().equals(date.toString())) {
                    list.add(reservation);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Reservation> listerReservantsArrivants() {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        try {
            List<Reservation> listReservations = hotel.listerReservations();
            for (Reservation reservation : listReservations) {
                if (new StringTokenizer(reservation.getDateArrivee(), " ").nextToken().equals(new java.sql.Date(new Date().getTime()).toString())) {
                    list.add(reservation);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Reservation> listerReservantsArrivants(Date date) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        try {
            List<Reservation> listReservations = hotel.listerReservations();
            for (Reservation reservation : listReservations) {
                if (new StringTokenizer(reservation.getDateArrivee(), " ").nextToken().equals(new java.sql.Date(date.getTime()).toString())) {
                    list.add(reservation);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Reservation> ListerReservantsArrivants(java.sql.Date date) {
        Hotel hotel = new Hotel();
        List<Reservation> list = new LinkedList<>();
        try {
            List<Reservation> listReservations = hotel.listerReservations();
            for (Reservation reservation : listReservations) {
                if (new StringTokenizer(reservation.getDateArrivee(), " ").nextToken().equals(date.toString())) {
                    list.add(reservation);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

//    public Reservation listerReservationParClientEtDateDepart(Client client, String date_depart) {
//        List<Reservation> listReservations = new Hotel().listerReservations();
//        for (Reservation reservation : listReservations) {
//            try {
//                if (reservation.getClient() == (int) client.getId() && reservation.getDateDepart().equals(date_depart)) {
//                    return reservation;
//                }
//            } catch (Exception e) {
//            }
//        }
//        return null;
//    }
    public Reservation listerReservationParId(int id) {
        try {
            List<Reservation> list = new Hotel().listerReservations();
            for (Reservation reservation : list) {
                if ((int) reservation.getId() == id) {
                    return reservation;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    //	Files
    public void verificationFichier(String nom_fichier) throws IOException {
        Hotel hotel = new Hotel();
        String fichier_log_du_jour = new Paths().recupererLogsPath() + String.valueOf(new java.sql.Date(new java.util.Date().getTime())) + ".txt";
        String tampon = "";
        Boolean ok = false;
        //Fichier log du jour
        while (ok != true) {
            try {
                ok = new File(fichier_log_du_jour).createNewFile();
            } catch (IOException iOException) {
            }
            if (ok != true) {
                ok = true;
            } else {
                tampon = "Mettre a jour listefichier";
            }
        }

        ok = false;
        //Creation d'un nouveau fichier et verification de son existence
        while (ok != true) {
            try {
                ok = new File(nom_fichier).createNewFile();
            } catch (IOException iOException) {
            }
            if (ok != true) {
                ok = true;
                Boolean verif = null;
                try {
                    verif = hotel.verifierPresenceContenuDansFichier(fichier_log_du_jour, nom_fichier);
                } catch (IOException iOException) {
                }
                try {
                    if (!verif) {
                        if (!tampon.equals("")) {
                            try {
                                hotel.ecrireDansFichier(fichier_log_du_jour, nom_fichier);
                            } catch (IOException iOException) {
                            }
                        }
                    }
                } catch (Exception exception) {
                }
            } else {
                try {
                    if (!tampon.equals("")) {
                        try {
                            hotel.ecrireDansFichier(fichier_log_du_jour, nom_fichier);
                        } catch (IOException iOException) {
                        }
                    }
                } catch (Exception e) {
                }
            }
        }

    }

    public Boolean verifierPresenceContenuDansFichier(String contenu, String fichier) throws FileNotFoundException, IOException {
        Boolean ok = Boolean.FALSE;
        String ligne;
        try (BufferedReader entree = new BufferedReader(new FileReader(fichier))) {
            do {
                ligne = entree.readLine();
                if (ligne != null) {
                    if (ligne.equals(contenu)) {
                        ok = Boolean.TRUE;
                    }
                }
            } while (ligne != null);
        }
        return ok;
    }

    public String lireDerniereLigneFichierTexte(File file) throws FileNotFoundException, IOException {
        String ligne;
        String resultat = null;
        try (BufferedReader entree = new BufferedReader(new FileReader(file.getPath()))) {
            do {
                ligne = entree.readLine();
                if (ligne != null) {
                    resultat = ligne;
                }
            } while (ligne != null);
        }
        return resultat;
    }

    public int countNbLignesFichiers(String nom_fichier) throws FileNotFoundException, IOException {
        int nbLignes = 0;
        BufferedReader entree = new BufferedReader(new FileReader(nom_fichier));
        while (true) {
            String ligneLue = entree.readLine();
            if (ligneLue == null) {
                break;
            }
            nbLignes++;
        }
        return nbLignes;
    }

    public void ecrireDansFichier(String contenu, String nom_fichier) throws IOException {
        try {
            try (PrintWriter sortiecreation = new PrintWriter(new BufferedWriter(new FileWriter(nom_fichier, true)))) {
                sortiecreation.println(contenu + " \n ");
            }
        } catch (IOException iOException) {
        }
    }

    public boolean copyFile(File source, File dest) {
        try {

            try (java.io.FileInputStream sourceFile = new java.io.FileInputStream(source)) {
                FileOutputStream destinationFile = null;

                try {
                    destinationFile = new FileOutputStream(dest);

                    // Lecture par segment de 0.5Mo
                    byte buffer[] = new byte[512 * 1024];
                    int nbLecture;

                    while ((nbLecture = sourceFile.read(buffer)) != -1) {
                        destinationFile.write(buffer, 0, nbLecture);
                    }
                } finally {
                    destinationFile.close();
                }
            }
        } catch (IOException e) {
            return false; // Erreur
        }

        return true; // Résultat OK
    }

    public boolean moveFile(File source, File destination) {
        if (!destination.exists()) {
            // On essaye avec renameTo
            boolean result = source.renameTo(destination);
            if (!result) {
                // On essaye de copier
                result = true;
                result &= new Hotel().copyFile(source, destination);
                if (result) {
                    result &= source.delete();
                }

            }
            return (result);
        } else {
            // Si le fichier destination existe, on annule ...
            return (false);
        }
    }

    public boolean deleteDirectory(File path) {
        boolean resultat = true;

        if (path.exists()) {
            File[] files = path.listFiles();
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    resultat &= deleteDirectory(files[i]);
                } else {
                    resultat &= files[i].delete();
                }
            }
        }
        resultat &= path.delete();
        return (resultat);
    }

    public File listerFileByName(File[] files, String fileName) {
        for (int i = 0; i < files.length; i++) {
            if (files[i].getName().equals(fileName)) {
                return files[i];
            }
        }
        return null;
    }

    //	Configuration, Blocs, Etages, Chambres, Lits, Categories
    public List<Bloc> listerBlocs() {
        List<Bloc> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT b FROM Bloc b");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public long listerNbreBlocs() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT COUNT(*) FROM Bloc b");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerNbreEtagesParBloc(Bloc bloc) {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT COUNT(*) FROM Etage e WHERE e.bloc = " + bloc.getId());
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public Bloc listerBlocParId(int id) {
        try {
            List<Bloc> list = new Hotel().listerBlocs();
            for (Bloc bloc : list) {
                if ((int) bloc.getId() == id) {
                    return bloc;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Bloc> listerBlocsOrderByDesignationASC() {
        List<Bloc> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT b FROM Bloc b ORDER BY b.designation ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Bloc listerBlocByDesignation(String designation) {
        try {
            List<Bloc> list = new Hotel().listerBlocs();
            for (Bloc bloc : list) {
                if (bloc.getDesignation().equals(designation)) {
                    return bloc;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Chambre> listerChambres() {
        List<Chambre> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Chambre c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public long listerNbreChambresParEtage(Etage etage) {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT COUNT(*) FROM Chambre c WHERE c.etage = " + etage.getId());
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerNbreChambresDispoParEtage(Etage etage) {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT COUNT(*) FROM Chambre c WHERE c.statut = 'DISPONIBLE' AND c.etage = " + etage.getId());
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public List<Chambre> listerChambresOrderByDesignation() {
        List<Chambre> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM Chambre c ORDER BY c.designation ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<Chambre> listerChambresDispo() {
        Hotel hotel = new Hotel();
        List<Chambre> list, listChambresDispo;
        listChambresDispo = new LinkedList<>();
        try {
            list = hotel.listerChambres();
            for (Chambre chambre : list) {
                Bloc bloc = hotel.listerBlocParId((int) chambre.getBloc());
                Etage etage = hotel.listerEtageParId((int) chambre.getEtage());
                if (bloc.getDisponibilite() == Boolean.TRUE) {
                    if (etage.getDisponibilite() == Boolean.TRUE) {
                        if (chambre.getDisponibilite() == Boolean.TRUE) {
                            listChambresDispo.add(chambre);
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
        return listChambresDispo;
    }

    public Chambre listerChambreParId(int id) {
        try {
            List<Chambre> list = new Hotel().listerChambres();
            for (Chambre chambre : list) {
                if ((int) chambre.getId() == id) {
                    return chambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public Chambre listerChambreByDesignation(String designation) {
        List<Chambre> list = new Hotel().listerChambres();
        for (Chambre chambre : list) {
            try {
                if (chambre.getDesignation().equals(designation)) {
                    return chambre;
                }
            } catch (Exception e) {
            }
        }
        return null;
    }

    public List<Chambre> listerChambresByEtage(Etage etage) {
        List<Chambre> list = new LinkedList<>();
        List<Chambre> listChambres = new Hotel().listerChambresOrderByDesignation();
        for (Chambre chambre : listChambres) {
            try {
                if (chambre.getEtage() == (int) etage.getId()) {
                    list.add(chambre);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<Chambre> listerChambresByBloc(Bloc bloc) {
        Hotel hotel = new Hotel();
        List<Chambre> list = new LinkedList<>();
        List<Chambre> listChambres = hotel.listerChambres();
        for (Chambre chambre : listChambres) {
            try {
                if (chambre.getBloc() == (int) bloc.getId()) {
                    list.add(chambre);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<CategorieChambre> listerCategorieChambres() {
        List<CategorieChambre> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CategorieChambre c ORDER BY c.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public CategorieChambre listerCategorieChambreParId(int id) {
        try {
            List<CategorieChambre> list = new Hotel().listerCategorieChambres();
            for (CategorieChambre categorieChambre : list) {
                if ((int) categorieChambre.getId() == id) {
                    return categorieChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public CategorieChambre listerCategorieChambreByLibelle(String libelle) {
        try {
            List<CategorieChambre> listCategorieChambre = new Hotel().listerCategorieChambres();
            for (CategorieChambre categorieChambre : listCategorieChambre) {
                if (categorieChambre.getLibelle().equals(libelle)) {
                    return categorieChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public CategorieChambre listerCategorieChambreParChambre(Chambre chambre) {
        try {
            List<CategorieChambre> listCategorieChambre = new Hotel().listerCategorieChambres();
            for (CategorieChambre categorieChambre : listCategorieChambre) {
                if ((int) categorieChambre.getId() == (int) chambre.getCategorie()) {
                    return categorieChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

//    TypeChambre
    public List<TypeChambre> listerTypesChambre() {
        List<TypeChambre> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT t FROM TypeChambre t ORDER BY t.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public TypeChambre listerTypeChambreParId(int id) {
        try {
            List<TypeChambre> list = new Hotel().listerTypesChambre();
            for (TypeChambre typeChambre : list) {
                if ((int) typeChambre.getId() == id) {
                    return typeChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public TypeChambre listerTypeChambreByLibelle(String libelle) {
        try {
            List<TypeChambre> list = new Hotel().listerTypesChambre();
            for (TypeChambre typeChambre : list) {
                if (typeChambre.getLibelle().equals(libelle)) {
                    return typeChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public TypeChambre listerTypeChambreParChambre(Chambre chambre) {
        try {
            List<TypeChambre> list = new Hotel().listerTypesChambre();
            for (TypeChambre typeChambre : list) {
                if ((int) typeChambre.getId() == (int) chambre.getTypeChambre()) {
                    return typeChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

//    CaracteristiquesChambres
    public List<CaracteristiqueChambre> listerCaracteristiquesChambre() {
        List<CaracteristiqueChambre> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CaracteristiqueChambre c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public CaracteristiqueChambre listerCaracteristiqueChambreParId(int id) {
        try {
            List<CaracteristiqueChambre> list = new Hotel().listerCaracteristiquesChambre();
            for (CaracteristiqueChambre caracteristiqueChambre : list) {
                if ((int) caracteristiqueChambre.getId() == id) {
                    return caracteristiqueChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public CaracteristiqueChambre listerCaracteristiqueChambreByLibelle(String libelle) {
        try {
            List<CaracteristiqueChambre> list = new Hotel().listerCaracteristiquesChambre();
            for (CaracteristiqueChambre caracteristiqueChambre : list) {
                if (caracteristiqueChambre.getLibelle().equals(libelle)) {
                    return caracteristiqueChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public CaracteristiqueChambre listerCaracteristiqueChambreParChambre(Chambre chambre) {
        try {
            List<CaracteristiqueChambre> list = new Hotel().listerCaracteristiquesChambre();
            for (CaracteristiqueChambre caracteristiqueChambre : list) {
                if ((int) caracteristiqueChambre.getId() == (int) chambre.getCaracteristiqueChambre()) {
                    return caracteristiqueChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

//    SituationChambre
    public List<SituationChambre> listerSituationsChambre() {
        List<SituationChambre> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT s FROM SituationChambre s ORDER BY s.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public SituationChambre listerSituationChambreParId(int id) {
        try {
            List<SituationChambre> list = new Hotel().listerSituationsChambre();
            for (SituationChambre situationChambre : list) {
                if ((int) situationChambre.getId() == id) {
                    return situationChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public SituationChambre listerSituationChambreByLibelle(String libelle) {
        try {
            List<SituationChambre> list = new Hotel().listerSituationsChambre();
            for (SituationChambre situationChambre : list) {
                if (situationChambre.getLibelle().equals(libelle)) {
                    return situationChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public SituationChambre listerSituationChambreParChambre(Chambre chambre) {
        try {
            List<SituationChambre> list = new Hotel().listerSituationsChambre();
            for (SituationChambre situationChambre : list) {
                if ((int) situationChambre.getId() == (int) chambre.getSituationChambre()) {
                    return situationChambre;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

//    CategoriesLit
    public List<CategorieLit> listerCategoriesLitOrderByDesignationASC() {
        List<CategorieLit> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CategorieLit c ORDER BY c.designation");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<CategorieLit> listerCategoriesLit() {
        List<CategorieLit> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CategorieLit c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public CategorieLit listerCategorieLitById(int id) {
        try {
            List<CategorieLit> list = new Hotel().listerCategoriesLit();
            for (CategorieLit categorieLit : list) {
                if ((int) categorieLit.getId() == (int) id) {
                    return categorieLit;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Lit> listerLits() {
        List<Lit> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT l FROM Lit l");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public long listerNbreLitsParChambre(Chambre chambre) {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT COUNT(*) FROM Lit l WHERE l.chambre = " + chambre.getId());
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public Lit listerLitByDesignation(String designation) {
        try {
            List<Lit> list = new Hotel().listerLits();
            for (Lit lit : list) {
                if (lit.getDesignation().equals(designation)) {
                    return lit;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Lit> listerLitsByChambre(List<Lit> listLits, Chambre chambre) {
        List<Lit> list = new LinkedList<>();
        try {
            for (Lit lit : listLits) {
                if (lit.getChambre() == (int) chambre.getId()) {
                    list.add(lit);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Lit> listerLitsDispoByListLits(List<Lit> listLits) {
        List<Lit> list = new LinkedList<>();
        try {
            for (Lit lit : listLits) {
                if (lit.getDisponibilite() == Boolean.TRUE) {
                    list.add(lit);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Lit> listerLitsDisponibles() {
        List<Lit> list = new LinkedList<>();
        try {
            List<Lit> listLits = new Hotel().listerLits();
            for (Lit lit : listLits) {
                if (lit.getDisponibilite() == true) {
                    list.add(lit);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Lit listerLitById(int id) {
        try {
            List<Lit> listLit = new Hotel().listerLits();
            for (Lit lit : listLit) {
                if ((int) lit.getId() == id) {
                    return lit;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Lit> listerLitsDisponiblesByEtage(List<Lit> listLitsDispo, Etage etage) {
        Hotel hotel = new Hotel();
        List<Lit> list = new LinkedList<>();
        try {
            List<Chambre> listChambreByEtage = hotel.listerChambresByEtage(etage);
            for (Chambre chambre : listChambreByEtage) {
                List<Lit> listLitsByChambre = hotel.listerLitsByChambre(listLitsDispo, chambre);
                list.addAll(listLitsByChambre);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Etage> listerEtages() {
        List<Etage> list = new LinkedList<>();
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            list = em.createNamedQuery("Etage.findAll").getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }

    public Etage listerEtageParId(int id) {
        List<Etage> list = new Hotel().listerEtages();
        try {
            for (Etage etage : list) {
                if ((int) etage.getId() == id) {
                    return etage;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public List<Etage> listerEtagesOrderByDesignation() {
        List<Etage> list = new LinkedList<>();
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            Query query = em.createQuery("SELECT e FROM Etage e ORDER BY e.designation ASC");
            list = query.getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }

    public List<Etage> listerEtagesByBloc(Bloc bloc) {
        List<Etage> list = new LinkedList<>();
        try {
            List<Etage> listEtages = new Hotel().listerEtagesOrderByDesignation();
            for (Etage etage : listEtages) {
                if ((int) etage.getBloc() == (int) bloc.getId()) {
                    list.add(etage);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public Etage listerEtageByDesignation(String designation) {
        try {
            List<Etage> list = new Hotel().listerEtages();
            for (Etage etage : list) {
                if (etage.getDesignation().equals(designation)) {
                    return etage;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public long listerMaxIdEtage() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(e.id) FROM Etage e");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerMaxIdLog() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(l.id) FROM Log l");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerMaxIdClient() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(c.id) FROM Client c");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public long listerMaxIdReservation() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(r.id) FROM Reservation r");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    //	Countries
    public List<Pays> listerPays() {
        List<Pays> list = new LinkedList<>();
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            Query query = em.createQuery("SELECT p FROM Pays p");
            list = query.getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }

    public Pays listerPaysParNom(String nomPays) {
        try {
            List<Pays> listPays = new Hotel().listerPays();
            for (Pays pays : listPays) {
                if (nomPays.equals(pays.getNom())) {
                    return pays;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    // Bars
    public List<Bar> listerBars() {
        List<Bar> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT b FROM Bar b ORDER BY b.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Bar listerBarParId(int id) {
        List<Bar> list = new Hotel().listerBars();
        for (Iterator<Bar> it = list.iterator(); it.hasNext();) {
            Bar bar = it.next();
            if ((int) bar.getId() == id) {
                return bar;
            }
        }
        return null;
    }

    public Bar listerBarParLibelle(String libelle) {
        List<Bar> list = new Hotel().listerBars();
        for (Iterator<Bar> it = list.iterator(); it.hasNext();) {
            Bar bar = it.next();
            if (libelle.equals(bar.getLibelle())) {
                return bar;
            }
        }
        return null;
    }

    public List<BarVente> listerBarVentes() {
        List<BarVente> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT b FROM BarVente b ORDER BY b.id DESC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public BarVente listerBarVenteParId(int id) {
        List<BarVente> list = new Hotel().listerBarVentes();
        for (Iterator<BarVente> it = list.iterator(); it.hasNext();) {
            BarVente barVente = it.next();
            if ((int) barVente.getId() == id) {
                return barVente;
            }
        }
        return null;
    }

    public float listerBarVentesToday() {
        Hotel hotel = new Hotel();
        List<BarVente> listBarVentes = hotel.listerBarVentes();
        List<BarVente> list = new LinkedList<>();
        String today = new StringTokenizer(Hotel.returnNow(), " ").nextToken();
        for (BarVente barVente : listBarVentes) {
            try {
                if ((barVente.getNumFacture() == null) || ("".equals(barVente.getNumFacture().trim()))) {
                    String dateBarVente = new StringTokenizer(barVente.getDateHeure(), " ").nextToken();
                    if (today.equals(dateBarVente)) {
                        list.add(barVente);
                    }
                } else {
                    String dateBarVente = barVente.getDateFacture();
                    if (today.equals(dateBarVente)) {
                        list.add(barVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (BarVente barVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(barVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }

    public float listerBarVentesTodayParBar(Bar bar) {
        Hotel hotel = new Hotel();
        List<BarVente> listBarVentesParBar = hotel.listerBarVentesParBar(bar);
        List<BarVente> list = new LinkedList<>();
        String today = new StringTokenizer(Hotel.returnNow(), " ").nextToken();
        for (BarVente barVente : listBarVentesParBar) {
            try {
                if ((barVente.getNumFacture() == null) || ("".equals(barVente.getNumFacture().trim()))) {
                    String dateBarVente = new StringTokenizer(barVente.getDateHeure(), " ").nextToken();
                    if (today.equals(dateBarVente)) {
                        list.add(barVente);
                    }
                } else {
                    String dateBarVente = barVente.getDateFacture();
                    if (today.equals(dateBarVente)) {
                        list.add(barVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (BarVente barVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(barVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }
    
    public float listerBarVentesJournalieresParBar(String jour, Bar bar) {
        Hotel hotel = new Hotel();
        List<BarVente> listBarVentesParBar = hotel.listerBarVentesParBar(bar);
        List<BarVente> list = new LinkedList<>();
        for (BarVente barVente : listBarVentesParBar) {
            try {
                if ((barVente.getNumFacture() == null) || ("".equals(barVente.getNumFacture().trim()))) {
                    String dateBarVente = new StringTokenizer(barVente.getDateHeure(), " ").nextToken();
                    if (jour.equals(dateBarVente)) {
                        list.add(barVente);
                    }
                } else {
                    String dateBarVente = barVente.getDateFacture();
                    if (jour.equals(dateBarVente)) {
                        list.add(barVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (BarVente barVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(barVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }
    
    public float listerBarVentesMensuellesParBar(String mois, Bar bar) {
        Hotel hotel = new Hotel();
        List<BarVente> listBarVentesParBar = hotel.listerBarVentesParBar(bar);
        List<BarVente> list = new LinkedList<>();
        for (BarVente barVente : listBarVentesParBar) {
            try {
                if ((barVente.getNumFacture() == null) || ("".equals(barVente.getNumFacture().trim()))) {
                    String dateBarVente = new StringTokenizer(barVente.getDateHeure(), " ").nextToken();
                    StringTokenizer string = new StringTokenizer(dateBarVente, "-");
                    String moisBarVente = string.nextToken();
                    moisBarVente += "-" + string.nextToken();
                    
                    if (mois.equals(moisBarVente)) {
                        list.add(barVente);
                    }
                } else {
                    String dateBarVente = barVente.getDateFacture();
                    StringTokenizer string = new StringTokenizer(dateBarVente, "-");
                    String moisBarVente = string.nextToken();
                    moisBarVente += "-" + string.nextToken();
                    
                    if (mois.equals(moisBarVente)) {
                        list.add(barVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (BarVente barVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(barVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }
    
    public float listerBarVentesAnnuellesParBar(String annee, Bar bar) {
        Hotel hotel = new Hotel();
        List<BarVente> listBarVentesParBar = hotel.listerBarVentesParBar(bar);
        List<BarVente> list = new LinkedList<>();
        for (BarVente barVente : listBarVentesParBar) {
            try {
                if ((barVente.getNumFacture() == null) || ("".equals(barVente.getNumFacture().trim()))) {
                    String dateBarVente = new StringTokenizer(barVente.getDateHeure(), " ").nextToken();
                    String anneeBarVente = new StringTokenizer(dateBarVente, "-").nextToken();
                    
                    if (annee.equals(anneeBarVente)) {
                        list.add(barVente);
                    }
                } else {
                    String dateBarVente = barVente.getDateFacture();
                    String anneeBarVente = new StringTokenizer(dateBarVente, "-").nextToken();
                    
                    if (annee.equals(anneeBarVente)) {
                        list.add(barVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (BarVente barVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(barVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }

    public List<BarVente> listerBarVentesImpayeesParServeur(Serveur serveur) {
        List<BarVente> listBarVentes = new Hotel().listerBarVentes();
        List<BarVente> list = new LinkedList<>();
        for (Iterator<BarVente> it = listBarVentes.iterator(); it.hasNext();) {
            BarVente barVente = it.next();
            if (!barVente.getPaye()) {
                if ((int) barVente.getServeur() == (int) serveur.getId()) {
                    list.add(barVente);
                }
            }
        }
        return list;
    }

    public List<BarVente> listerBarVentesParTableOuverte(TableHotel table) {
        List<BarVente> listBarVentes = new Hotel().listerBarVentes();
        List<BarVente> list = new LinkedList<>();
        for (BarVente barVente : listBarVentes) {
            if (barVente.getCloture() != Boolean.TRUE) {
                if ((int) barVente.getTableId() == (int) table.getId()) {
                    list.add(barVente);
                }
            }
        }
        return list;
    }

    public long listerMaxIdBarVente() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(b.id) FROM bar_vente b");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public List<BarVente> listerBarVentesParReservation(Reservation reservation) {
        List<BarVente> listBarVentes = new Hotel().listerBarVentes();
        List<BarVente> list = new LinkedList<>();
        for (BarVente barVente : listBarVentes) {
            try {
                if ((int) barVente.getReservation() == (int) reservation.getId()) {
                    list.add(barVente);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<BarVente> listerBarVentesParBar(Bar bar) {
        List<BarVente> listBarVentes = new Hotel().listerBarVentes();
        List<BarVente> list = new LinkedList<>();
        for (BarVente barVente : listBarVentes) {
            try {
                if ((int) barVente.getBar() == (int) bar.getId()) {
                    list.add(barVente);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<CategorieBoisson> listerCategoriesBoisson() {
        List<CategorieBoisson> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CategorieBoisson c ORDER BY c.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public CategorieBoisson listerCategorieBoissonParId(int id) {
        List<CategorieBoisson> list = new Hotel().listerCategoriesBoisson();
        for (Iterator<CategorieBoisson> it = list.iterator(); it.hasNext();) {
            CategorieBoisson categorieBoisson = it.next();
            if ((int) categorieBoisson.getId() == id) {
                return categorieBoisson;
            }
        }
        return null;
    }

    public CategorieBoisson listerCategorieBoissonParLibelle(String libelle) {
        List<CategorieBoisson> list = new Hotel().listerCategoriesBoisson();
        for (Iterator<CategorieBoisson> it = list.iterator(); it.hasNext();) {
            CategorieBoisson categorieBoisson = it.next();
            if (libelle.equals(categorieBoisson.getLibelle())) {
                return categorieBoisson;
            }
        }
        return null;
    }

    public List<Boisson> listerBoissons() {
        List<Boisson> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT b FROM Boisson b ORDER BY b.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Boisson listerBoissonParId(int id) {
        List<Boisson> list = new Hotel().listerBoissons();
        for (Iterator<Boisson> it = list.iterator(); it.hasNext();) {
            Boisson boisson = it.next();
            if ((int) boisson.getId() == id) {
                return boisson;
            }
        }
        return null;
    }

    public Boisson listerBoissonParLibelle(String libelle) {
        List<Boisson> list = new Hotel().listerBoissons();
        for (Iterator<Boisson> it = list.iterator(); it.hasNext();) {
            Boisson boisson = it.next();
            if (libelle.equals(boisson.getLibelle())) {
                return boisson;
            }
        }
        return null;
    }

    public List<Boisson> listerBoissonsParCategorieBoisson(CategorieBoisson categorieBoisson) {
        List<Boisson> listBoissons = new Hotel().listerBoissons();
        List<Boisson> list = new LinkedList<>();
        for (Boisson boisson : listBoissons) {
            if (categorieBoisson.getId() == boisson.getCategorieBoisson()) {
                list.add(boisson);
            }
        }
        return list;
    }

    public List<FluxPrixBoisson> listerFluxPrixBoissons() {
        List<FluxPrixBoisson> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT f FROM FluxPrixBoisson f");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<FluxPrixBoisson> listerFluxPrixBoissonParBoisson(Boisson boisson) {
        List<FluxPrixBoisson> listFluxPrixBoissons = new Hotel().listerFluxPrixBoissons();
        List<FluxPrixBoisson> list = new LinkedList<>();
        for (Iterator<FluxPrixBoisson> it = listFluxPrixBoissons.iterator(); it.hasNext();) {
            FluxPrixBoisson fluxPrixBoisson = it.next();
            if ((int) fluxPrixBoisson.getBoisson() == (int) boisson.getId()) {
                list.add(fluxPrixBoisson);
            }
        }
        return list;
    }

    public void majFluxPrixBoisson(FluxPrixBoisson fluxPrixBoisson) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<FluxPrixBoisson> listFluxPrixBoissons = new Hotel().listerFluxPrixBoissons();
        em.persist(fluxPrixBoisson);
        listFluxPrixBoissons.add(fluxPrixBoisson);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<FluxPrixBoisson> merged = new ArrayList<>(listFluxPrixBoissons.size());
            for (FluxPrixBoisson f : listFluxPrixBoissons) {
                merged.add(em.merge(f));
            }
            listFluxPrixBoissons.clear();
            listFluxPrixBoissons.addAll(merged);
        }
    }

    public List<BoissonSeuil> listerBoissonSeuils() {
        List<BoissonSeuil> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT b FROM BoissonSeuil b");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public BoissonSeuil listerBoissonSeuilParBoisson(Boisson boisson) {
        List<BoissonSeuil> list = new Hotel().listerBoissonSeuils();
        for (Iterator<BoissonSeuil> it = list.iterator(); it.hasNext();) {
            BoissonSeuil boissonSeuil = it.next();
            if ((int) boissonSeuil.getBoisson() == (int) boisson.getId()) {
                return boissonSeuil;
            }
        }
        return null;
    }

    public List<StockBoisson> listerStockBoissons() {
        List<StockBoisson> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT s FROM StockBoisson s");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public void stockerBoisson(StockBoisson stockBoisson) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<StockBoisson> listStockBoissons = new Hotel().listerStockBoissons();
        em.persist(stockBoisson);
        listStockBoissons.add(stockBoisson);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<StockBoisson> merged = new ArrayList<>(listStockBoissons.size());
            for (StockBoisson sb : listStockBoissons) {
                merged.add(em.merge(sb));
            }
            listStockBoissons.clear();
            listStockBoissons.addAll(merged);
        }
    }

    public int getStockRestantBoisson(Boisson boisson) {
        int res = 0;
        List<StockBoisson> listStockBoissons = new Hotel().listerStockBoissons();
        for (Iterator<StockBoisson> it = listStockBoissons.iterator(); it.hasNext();) {
            StockBoisson stockBoisson = it.next();
            if ((int) stockBoisson.getBoisson() == (int) boisson.getId()) {
                int variation = 0;
                try {
                    variation = (int) Integer.parseInt(String.valueOf(stockBoisson.getVariation()));
                } catch (NumberFormatException numberFormatException) {
                }
                res += variation;
            }
        }
        return res;
    }

    public List<Serveur> listerServeurs() {
        List<Serveur> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT s FROM Serveur s ORDER BY s.identifiant ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Serveur listerServeurParId(int id) {
        List<Serveur> list = new Hotel().listerServeurs();
        for (Iterator<Serveur> it = list.iterator(); it.hasNext();) {
            Serveur serveur = it.next();
            if ((int) serveur.getId() == id) {
                return serveur;
            }
        }
        return null;
    }

    public Serveur listerServeurParIdentifiant(String identifiant) {
        List<Serveur> list = new Hotel().listerServeurs();
        for (Iterator<Serveur> it = list.iterator(); it.hasNext();) {
            Serveur serveur = it.next();
            if (identifiant.equals(serveur.getIdentifiant())) {
                return serveur;
            }
        }
        return null;
    }

    // Restaurants
    public List<Restaurant> listerRestaurants() {
        List<Restaurant> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT r FROM Restaurant r ORDER BY r.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Restaurant listerRestaurantParId(int id) {
        List<Restaurant> list = new Hotel().listerRestaurants();
        for (Iterator<Restaurant> it = list.iterator(); it.hasNext();) {
            Restaurant restaurant = it.next();
            if ((int) restaurant.getId() == id) {
                return restaurant;
            }
        }
        return null;
    }

    public Restaurant listerRestaurantParLibelle(String libelle) {
        List<Restaurant> list = new Hotel().listerRestaurants();
        for (Iterator<Restaurant> it = list.iterator(); it.hasNext();) {
            Restaurant restaurant = it.next();
            if (libelle.equals(restaurant.getLibelle())) {
                return restaurant;
            }
        }
        return null;
    }

    public List<RestaurantVente> listerRestaurantVentes() {
        List<RestaurantVente> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT r FROM RestaurantVente r");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public RestaurantVente listerRestaurantVenteParId(int id) {
        List<RestaurantVente> list = new Hotel().listerRestaurantVentes();
        for (Iterator<RestaurantVente> it = list.iterator(); it.hasNext();) {
            RestaurantVente restaurantVente = it.next();
            if ((int) restaurantVente.getId() == id) {
                return restaurantVente;
            }
        }
        return null;
    }

    public List<RestaurantVente> listerRestaurantVentesImpayeesParServeur(Serveur serveur) {
        List<RestaurantVente> listRestaurantVentes = new Hotel().listerRestaurantVentes();
        List<RestaurantVente> list = new LinkedList<>();
        for (Iterator<RestaurantVente> it = listRestaurantVentes.iterator(); it.hasNext();) {
            RestaurantVente restaurantVente = it.next();
            if (!restaurantVente.getPaye()) {
                if ((int) restaurantVente.getServeur() == (int) serveur.getId()) {
                    list.add(restaurantVente);
                }
            }
        }
        return list;
    }

    public List<RestaurantVente> listerRestaurantVentesParReservation(Reservation reservation) {
        List<RestaurantVente> listRestaurantVentes = new Hotel().listerRestaurantVentes();
        List<RestaurantVente> list = new LinkedList<>();
        for (RestaurantVente restaurantVente : listRestaurantVentes) {
            try {
                if ((int) restaurantVente.getReservation() == (int) reservation.getId()) {
                    list.add(restaurantVente);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<RestaurantVente> listerRestaurantVentesParRestaurant(Restaurant restaurant) {
        List<RestaurantVente> listRestaurantVentes = new Hotel().listerRestaurantVentes();
        List<RestaurantVente> list = new LinkedList<>();
        for (RestaurantVente restaurantVente : listRestaurantVentes) {
            try {
                if ((int) restaurantVente.getRestaurant() == (int) restaurant.getId()) {
                    list.add(restaurantVente);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public float listerRestaurantVentesToday() {
        Hotel hotel = new Hotel();
        List<RestaurantVente> listRestaurantVentes = hotel.listerRestaurantVentes();
        List<RestaurantVente> list = new LinkedList<>();
        String today = new StringTokenizer(Hotel.returnNow(), " ").nextToken();
        for (RestaurantVente restaurantVente : listRestaurantVentes) {
            if ((restaurantVente.getNumFacture() == null) || ("".equals(restaurantVente.getNumFacture().trim()))) {
                String dateRestaurantVente = new StringTokenizer(restaurantVente.getDateHeure(), " ").nextToken();
                if (today.equals(dateRestaurantVente)) {
                    list.add(restaurantVente);
                }
            } else {
                String dateRestaurantVente = restaurantVente.getDateFacture();
                if (today.equals(dateRestaurantVente)) {
                    list.add(restaurantVente);
                }
            }
        }

        float total = 0;
        for (RestaurantVente restaurantVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(restaurantVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }

    public float listerRestaurantVentesTodayParRestaurant(Restaurant restaurant) {
        Hotel hotel = new Hotel();
        List<RestaurantVente> listRestaurantVentes = hotel.listerRestaurantVentesParRestaurant(restaurant);
        List<RestaurantVente> list = new LinkedList<>();
        String today = new StringTokenizer(Hotel.returnNow(), " ").nextToken();
        for (RestaurantVente restaurantVente : listRestaurantVentes) {
            try {
                if ((restaurantVente.getNumFacture() == null) || ("".equals(restaurantVente.getNumFacture().trim()))) {
                    String dateRestaurantVente = new StringTokenizer(restaurantVente.getDateHeure(), " ").nextToken();
                    if (today.equals(dateRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                } else {
                    String dateRestaurantVente = restaurantVente.getDateFacture();
                    if (today.equals(dateRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (RestaurantVente restaurantVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(restaurantVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }
    
    public float listerRestaurantVentesJournalieresParRestaurant(String jour, Restaurant restaurant) {
        Hotel hotel = new Hotel();
        List<RestaurantVente> listRestaurantVentesParRestaurant = hotel.listerRestaurantVentesParRestaurant(restaurant);
        List<RestaurantVente> list = new LinkedList<>();
        for (RestaurantVente restaurantVente : listRestaurantVentesParRestaurant) {
            try {
                if ((restaurantVente.getNumFacture() == null) || ("".equals(restaurantVente.getNumFacture().trim()))) {
                    String dateRestaurantVente = new StringTokenizer(restaurantVente.getDateHeure(), " ").nextToken();
                    if (jour.equals(dateRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                } else {
                    String dateRestaurantVente = restaurantVente.getDateFacture();
                    if (jour.equals(dateRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (RestaurantVente restaurantVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(restaurantVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }
    
    public float listerRestaurantVentesMensuellesParRestaurant(String mois, Restaurant restaurant) {
        Hotel hotel = new Hotel();
        List<RestaurantVente> listRestaurantVentesParRestaurant = hotel.listerRestaurantVentesParRestaurant(restaurant);
        List<RestaurantVente> list = new LinkedList<>();
        for (RestaurantVente restaurantVente : listRestaurantVentesParRestaurant) {
            try {
                if ((restaurantVente.getNumFacture() == null) || ("".equals(restaurantVente.getNumFacture().trim()))) {
                    String dateRestaurantVente = new StringTokenizer(restaurantVente.getDateHeure(), " ").nextToken();
                    StringTokenizer string = new StringTokenizer(dateRestaurantVente, "-");
                    String moisRestaurantVente = string.nextToken();
                    moisRestaurantVente += "-" + string.nextToken();
                    
                    if (mois.equals(moisRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                } else {
                    String dateRestaurantVente = restaurantVente.getDateFacture();
                    StringTokenizer string = new StringTokenizer(dateRestaurantVente, "-");
                    String moisRestaurantVente = string.nextToken();
                    moisRestaurantVente += "-" + string.nextToken();
                    
                    if (mois.equals(moisRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (RestaurantVente restaurantVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(restaurantVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }
    
    public float listerRestaurantVentesAnnuellesParRestaurant(String annee, Restaurant restaurant) {
        Hotel hotel = new Hotel();
        List<RestaurantVente> listRestaurantVentesParRestaurant = hotel.listerRestaurantVentesParRestaurant(restaurant);
        List<RestaurantVente> list = new LinkedList<>();
        for (RestaurantVente restaurantVente : listRestaurantVentesParRestaurant) {
            try {
                if ((restaurantVente.getNumFacture() == null) || ("".equals(restaurantVente.getNumFacture().trim()))) {
                    String dateRestaurantVente = new StringTokenizer(restaurantVente.getDateHeure(), " ").nextToken();
                    String anneeRestaurantVente = new StringTokenizer(dateRestaurantVente, "-").nextToken();
                    
                    if (annee.equals(anneeRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                } else {
                    String dateRestaurantVente = restaurantVente.getDateFacture();
                    String anneeRestaurantVente = new StringTokenizer(dateRestaurantVente, "-").nextToken();
                    
                    if (annee.equals(anneeRestaurantVente)) {
                        list.add(restaurantVente);
                    }
                }
            } catch (Exception e) {
            }
        }

        float total = 0;
        for (RestaurantVente restaurantVente : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(restaurantVente.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }

    public List<RestaurantVente> listerRestaurantVentesParTableOuverte(TableHotel table) {
        List<RestaurantVente> listRestaurantVentes = new Hotel().listerRestaurantVentes();
        List<RestaurantVente> list = new LinkedList<>();
        for (RestaurantVente restaurantVente : listRestaurantVentes) {
            if (restaurantVente.getCloture() != Boolean.TRUE) {
                if ((int) restaurantVente.getTableId() == (int) table.getId()) {
                    list.add(restaurantVente);
                }
            }
        }
        return list;
    }

    public List<Menu> listerMenus() {
        List<Menu> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT m FROM Menu m ORDER BY m.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Menu listerMenuParId(int id) {
        List<Menu> list = new Hotel().listerMenus();
        for (Iterator<Menu> it = list.iterator(); it.hasNext();) {
            Menu menu = it.next();
            if ((int) menu.getId() == id) {
                return menu;
            }
        }
        return null;
    }

    public Menu listerMenuParLibelle(String libelle) {
        List<Menu> list = new Hotel().listerMenus();
        for (Iterator<Menu> it = list.iterator(); it.hasNext();) {
            Menu menu = it.next();
            if (libelle.equals(menu.getLibelle())) {
                return menu;
            }
        }
        return null;
    }

    public List<Menu> listerMenusParCategorieMenu(CategorieMenu categorieMenu) {
        List<Menu> listMenus = new Hotel().listerMenus();
        List<Menu> list = new LinkedList<>();
        for (Iterator<Menu> it = listMenus.iterator(); it.hasNext();) {
            Menu menu = it.next();
            if ((int) menu.getCategorieMenu() == (int) categorieMenu.getId()) {
                list.add(menu);
            }
        }
        return list;
    }

    public List<CategorieMenu> listerCategoriesMenu() {
        List<CategorieMenu> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CategorieMenu c ORDER BY c.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public CategorieMenu listerCategorieMenuParId(int id) {
        List<CategorieMenu> list = new Hotel().listerCategoriesMenu();
        for (Iterator<CategorieMenu> it = list.iterator(); it.hasNext();) {
            CategorieMenu categorieMenu = it.next();
            if ((int) categorieMenu.getId() == id) {
                return categorieMenu;
            }
        }
        return null;
    }

    public CategorieMenu listerCategorieMenuParLibelle(String libelle) {
        List<CategorieMenu> list = new Hotel().listerCategoriesMenu();
        for (Iterator<CategorieMenu> it = list.iterator(); it.hasNext();) {
            CategorieMenu categorieMenu = it.next();
            if (libelle.equals(categorieMenu.getLibelle())) {
                return categorieMenu;
            }
        }
        return null;
    }

    public List<FluxPrixMenu> listerFluxPrixMenus() {
        List<FluxPrixMenu> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT f FROM FluxPrixMenu f");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<FluxPrixMenu> listerFluxPrixMenuParMenu(Menu menu) {
        List<FluxPrixMenu> listFluxPrixMenus = new Hotel().listerFluxPrixMenus();
        List<FluxPrixMenu> list = new LinkedList<>();
        for (Iterator<FluxPrixMenu> it = listFluxPrixMenus.iterator(); it.hasNext();) {
            FluxPrixMenu fluxPrixMenu = it.next();
            if ((int) fluxPrixMenu.getMenu() == (int) menu.getId()) {
                list.add(fluxPrixMenu);
            }
        }
        return list;
    }

    public void majFluxPrixMenu(FluxPrixMenu fluxPrixMenu) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<FluxPrixMenu> listFluxPrixMenus = new Hotel().listerFluxPrixMenus();
        em.persist(fluxPrixMenu);
        listFluxPrixMenus.add(fluxPrixMenu);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<FluxPrixMenu> merged = new ArrayList<>(listFluxPrixMenus.size());
            for (FluxPrixMenu f : listFluxPrixMenus) {
                merged.add(em.merge(f));
            }
            listFluxPrixMenus.clear();
            listFluxPrixMenus.addAll(merged);
        }
    }

    public List<Piscine> listerPiscines() {
        List<Piscine> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT p FROM Piscine p ORDER BY p.libelle ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Piscine listerPiscineParId(int id) {
        List<Piscine> listPiscines = new Hotel().listerPiscines();
        for (Piscine piscine : listPiscines) {
            if ((int) piscine.getId() == id) {
                return piscine;
            }
        }
        return null;
    }

    public Piscine listerPiscineParLibelle(String libelle) {
        List<Piscine> list = new Hotel().listerPiscines();
        for (Iterator<Piscine> it = list.iterator(); it.hasNext();) {
            Piscine piscine = it.next();
            if (libelle.equals(piscine.getLibelle())) {
                return piscine;
            }
        }
        return null;
    }

    public List<Facture> listerFactures() {
        List<Facture> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT f FROM Facture f");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Facture listerFactureParId(int id) {
        List<Facture> list = new Hotel().listerFactures();
        for (Iterator<Facture> it = list.iterator(); it.hasNext();) {
            Facture facture = it.next();
            if ((int) facture.getId() == id) {
                return facture;
            }
        }
        return null;
    }

    public List<Facture> listerFacturesParClient(Client client) {
        Hotel hotel = new Hotel();
        List<Facture> listFacturesParClient = new LinkedList<>();
        List<Facture> listFactures = hotel.listerFactures();
        List<Reservation> listReservationsParClient = hotel.listerReservationsParClient(client);
        for (Reservation reservation : listReservationsParClient) {
            for (Facture facture : listFactures) {
                try {
                    if ((int) facture.getReservation() == (int) reservation.getId()) {
                        listFacturesParClient.add(facture);
                    }
                } catch (Exception e) {
                }
            }
        }
        return listFacturesParClient;
    }

    public void majFacture(Facture facture) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Facture> listFactures = new Hotel().listerFactures();
        em.persist(facture);
        listFactures.add(facture);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<Facture> merged = new ArrayList<>(listFactures.size());
            for (Facture f : listFactures) {
                merged.add(em.merge(f));
            }
            listFactures.clear();
            listFactures.addAll(merged);
        }
    }

    public List<FactureTable> listerFacturesTables() {
        List<FactureTable> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT f FROM FactureTable f");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<FactureTable> listerFacturesTableParTableId(int tableId) {
        List<FactureTable> listFacturesTables = new Hotel().listerFacturesTables();
        List<FactureTable> list = new LinkedList<>();
        for (FactureTable factureTable : listFacturesTables) {
            if (factureTable.getTableId() == tableId) {
                list.add(factureTable);
            }
        }
        return list;
    }

    public FactureTable listerFactureTableParId(int id) {
        List<FactureTable> list = new Hotel().listerFacturesTables();
        for (FactureTable factureTable : list) {
            if ((int) factureTable.getId() == id) {
                return factureTable;
            }
        }
        return null;
    }

    public void majFactureTable(FactureTable factureTable) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<FactureTable> listFactureTables = new Hotel().listerFacturesTables();
        em.persist(factureTable);
        listFactureTables.add(factureTable);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<FactureTable> merged = new ArrayList<>(listFactureTables.size());
            for (FactureTable f : listFactureTables) {
                merged.add(em.merge(f));
            }
            listFactureTables.clear();
            listFactureTables.addAll(merged);
        }
    }

    // CAISSES
    public List<CaisseBar> listerCaisseBars() {
        List<CaisseBar> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CaisseBar c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public float listerTotalCaisseBars() {
        List<CaisseBar> listCaisseBar = new Hotel().listerCaisseBars();
        float totalCaisseBar = 0;
        try {
            for (CaisseBar caisseBar : listCaisseBar) {
                try {
                    totalCaisseBar += (float) Float.parseFloat(String.valueOf(caisseBar.getVariation()));
                } catch (NumberFormatException numberFormatException) {
                }
            }
        } catch (Exception e) {
        }
        return totalCaisseBar;
    }

    public void majCaisseBar(CaisseBar caisseBar) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<CaisseBar> listCaisseBars = new Hotel().listerCaisseBars();
        em.persist(caisseBar);
        listCaisseBars.add(caisseBar);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<CaisseBar> merged = new ArrayList<>(listCaisseBars.size());
            for (CaisseBar c : listCaisseBars) {
                merged.add(em.merge(c));
            }
            listCaisseBars.clear();
            listCaisseBars.addAll(merged);
        }
    }

    public List<CaisseDivers> listerCaisseDivers() {
        List<CaisseDivers> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CaisseDivers c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public float listerTotalCaisseDivers() {
        List<CaisseDivers> listCaisseDivers = new Hotel().listerCaisseDivers();
        float totalCaisseDivers = 0;
        try {
            for (CaisseDivers caisseDivers : listCaisseDivers) {
                try {
                    totalCaisseDivers += (float) Float.parseFloat(String.valueOf(caisseDivers.getVariation()));
                } catch (NumberFormatException numberFormatException) {
                }
            }
        } catch (Exception e) {
        }
        return totalCaisseDivers;
    }

    public void majCaisseDivers(CaisseDivers caisseDivers) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<CaisseDivers> listCaisseDivers = new Hotel().listerCaisseDivers();
        em.persist(caisseDivers);
        listCaisseDivers.add(caisseDivers);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<CaisseDivers> merged = new ArrayList<>(listCaisseDivers.size());
            for (CaisseDivers c : listCaisseDivers) {
                merged.add(em.merge(c));
            }
            listCaisseDivers.clear();
            listCaisseDivers.addAll(merged);
        }
    }

    public List<CaissePiscine> listerCaissePiscine() {
        List<CaissePiscine> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CaissePiscine c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public float listerTotalCaissePiscine() {
        List<CaissePiscine> listCaissePiscine = new Hotel().listerCaissePiscine();
        float totalCaissePiscine = 0;
        try {
            for (CaissePiscine caissePiscine : listCaissePiscine) {
                try {
                    totalCaissePiscine += (float) Float.parseFloat(String.valueOf(caissePiscine.getVariation()));
                } catch (NumberFormatException numberFormatException) {
                }
            }
        } catch (Exception e) {
        }
        return totalCaissePiscine;
    }

    public void majCaissePiscine(CaissePiscine caissePiscine) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<CaissePiscine> listCaissePiscines = new Hotel().listerCaissePiscine();
        em.persist(caissePiscine);
        listCaissePiscines.add(caissePiscine);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<CaissePiscine> merged = new ArrayList<>(listCaissePiscines.size());
            for (CaissePiscine c : listCaissePiscines) {
                merged.add(em.merge(c));
            }
            listCaissePiscines.clear();
            listCaissePiscines.addAll(merged);
        }
    }

    public List<CaisseReservation> listerCaisseReservations() {
        List<CaisseReservation> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CaisseReservation c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public float listerTotalCaisseReservation() {
        List<CaisseReservation> listCaisseReservation = new Hotel().listerCaisseReservations();
        float totalCaisseReservation = 0;
        try {
            for (CaisseReservation caisseReservation : listCaisseReservation) {
                try {
                    totalCaisseReservation += (float) Float.parseFloat(String.valueOf(caisseReservation.getVariation()));
                } catch (NumberFormatException numberFormatException) {
                }
            }
        } catch (Exception e) {
        }
        return totalCaisseReservation;
    }

    public void majCaisseReservation(CaisseReservation caisseReservation) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<CaisseReservation> listCaisseReservations = new Hotel().listerCaisseReservations();
        em.persist(caisseReservation);
        listCaisseReservations.add(caisseReservation);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<CaisseReservation> merged = new ArrayList<>(listCaisseReservations.size());
            for (CaisseReservation c : listCaisseReservations) {
                merged.add(em.merge(c));
            }
            listCaisseReservations.clear();
            listCaisseReservations.addAll(merged);
        }
    }

    public List<CaisseRestaurant> listerCaisseRestaurants() {
        List<CaisseRestaurant> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CaisseRestaurant c");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public float listerTotalCaisseRestaurant() {
        List<CaisseRestaurant> listCaisseRestaurant = new Hotel().listerCaisseRestaurants();
        float totalCaisseRestaurants = 0;
        try {
            for (CaisseRestaurant caisseRestaurant : listCaisseRestaurant) {
                try {
                    totalCaisseRestaurants += (float) Float.parseFloat(String.valueOf(caisseRestaurant.getVariation()));
                } catch (NumberFormatException numberFormatException) {
                }
            }
        } catch (Exception e) {
        }
        return totalCaisseRestaurants;
    }

    public void majCaisseRestaurant(CaisseRestaurant caisseRestaurant) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<CaisseRestaurant> listCaisseRestaurants = new Hotel().listerCaisseRestaurants();
        em.persist(caisseRestaurant);
        listCaisseRestaurants.add(caisseRestaurant);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<CaisseRestaurant> merged = new ArrayList<>(listCaisseRestaurants.size());
            for (CaisseRestaurant c : listCaisseRestaurants) {
                merged.add(em.merge(c));
            }
            listCaisseRestaurants.clear();
            listCaisseRestaurants.addAll(merged);
        }
    }

    public List<Penalite> listerPenalites() {
        List<Penalite> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT p FROM Penalite p");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public Penalite listerPenaliteParId(int id) {
        List<Penalite> list = new Hotel().listerPenalites();
        for (Penalite penalite : list) {
            if ((int) penalite.getId() == id) {
                return penalite;
            }
        }
        return null;
    }

    public List<Penalite> listerPenalitesParReservation(Reservation reservation) {
        List<Penalite> listPenalites = new Hotel().listerPenalites();
        List<Penalite> list = new LinkedList<>();
        for (Penalite penalite : listPenalites) {
            try {
                if ((int) penalite.getReservation() == (int) reservation.getId()) {
                    list.add(penalite);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<VenteAccesPiscine> listerVenteAccesPiscines() {
        List<VenteAccesPiscine> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT v FROM VenteAccesPiscine v ORDER BY v.id DESC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public List<VenteAccesPiscine> listerVenteAccesPiscinesParReservation(Reservation reservation) {
        List<VenteAccesPiscine> listVenteAccesPiscines = new Hotel().listerVenteAccesPiscines();
        List<VenteAccesPiscine> list = new LinkedList<>();
        for (VenteAccesPiscine venteAccesPiscine : listVenteAccesPiscines) {
            try {
                if ((int) venteAccesPiscine.getReservation() == (int) reservation.getId()) {
                    list.add(venteAccesPiscine);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public List<VenteAccesPiscine> listerVenteAccesPiscinesParPiscine(Piscine piscine) {
        List<VenteAccesPiscine> listVenteAccesPiscines = new Hotel().listerVenteAccesPiscines();
        List<VenteAccesPiscine> list = new LinkedList<>();
        for (VenteAccesPiscine venteAccesPiscine : listVenteAccesPiscines) {
            try {
                if ((int) venteAccesPiscine.getPiscine() == (int) piscine.getId()) {
                    list.add(venteAccesPiscine);
                }
            } catch (Exception e) {
            }
        }
        return list;
    }

    public float listerVenteAccesPiscinesToday() {
        Hotel hotel = new Hotel();
        List<VenteAccesPiscine> listVenteAccesPiscines = hotel.listerVenteAccesPiscines();
        List<VenteAccesPiscine> list = new LinkedList<>();
        String today = new StringTokenizer(Hotel.returnNow(), " ").nextToken();
        for (VenteAccesPiscine venteAccesPiscine : listVenteAccesPiscines) {
            String dateVenteAccesPiscine = new StringTokenizer(venteAccesPiscine.getDateHeure(), " ").nextToken();
            if (today.equals(dateVenteAccesPiscine)) {
                list.add(venteAccesPiscine);
            }
        }

        float total = 0;
        for (VenteAccesPiscine venteAccesPiscine : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(venteAccesPiscine.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }

    public float listerVenteAccesPiscinesTodayParPiscine(Piscine piscine) {
        Hotel hotel = new Hotel();
        List<VenteAccesPiscine> listVenteAccesPiscinesParPiscine = hotel.listerVenteAccesPiscinesParPiscine(piscine);
        List<VenteAccesPiscine> list = new LinkedList<>();
        String today = new StringTokenizer(Hotel.returnNow(), " ").nextToken();
        for (VenteAccesPiscine venteAccesPiscine : listVenteAccesPiscinesParPiscine) {
            String dateVenteAccesPiscine = new StringTokenizer(venteAccesPiscine.getDateHeure(), " ").nextToken();
            if (today.equals(dateVenteAccesPiscine)) {
                list.add(venteAccesPiscine);
            }
        }

        float total = 0;
        for (VenteAccesPiscine venteAccesPiscine : list) {
            try {
                total += (float) Float.parseFloat(String.valueOf(venteAccesPiscine.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        }

        return total;
    }

    public long listerMaxIdVenteAccesPiscine() {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(v.id) FROM vente_acces_piscine v");
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }

    public List<TableHotel> listerTablesHotel() {
        List<TableHotel> list = new LinkedList<>();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        Query query = em.createQuery("SELECT t FROM TableHotel t ORDER BY t.id ASC");
        try {
            list = query.getResultList();
        } catch (Exception e) {
        }
        em.close();
        emf.close();
        return list;
    }

    public TableHotel listerTableHotelParId(int id) {
        List<TableHotel> list = new Hotel().listerTablesHotel();
        for (Iterator<TableHotel> it = list.iterator(); it.hasNext();) {
            TableHotel table = it.next();
            if ((int) table.getId() == id) {
                return table;
            }
        }
        return null;
    }
}
