/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.dynamics;

import hotelpro.entities.Utilisateur;
import hotelpro.gui.Authentification;
import hotelpro.gui.Gui;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Serge
 */
public class ChargementGui extends Thread {
    
    Utilisateur utilisateur;
    Authentification authentification;

    public ChargementGui(Utilisateur utilisateur, Authentification authentification) {
        this.utilisateur = utilisateur;
        this.authentification = authentification;
    }

    @Override
    public void run() {
        try {
            sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(ChargementGui.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        new Gui(utilisateur).setVisible(Boolean.TRUE);
        authentification.dispose();
        interrupt();
    }
    
}
