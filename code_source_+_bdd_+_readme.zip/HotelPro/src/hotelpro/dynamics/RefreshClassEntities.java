/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.dynamics;

import hotelpro.entities.Boisson;
import hotelpro.entities.BoissonSeuil;
import hotelpro.entities.CategorieBoisson;
import hotelpro.gui.AlerteStock;
import hotelpro.gui.Gui;
import hotelpro.utils.Hotel;
import java.applet.AudioClip;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sun.applet.AppletAudioClip;

/**
 *
 * @author Serge
 */
public class RefreshClassEntities extends Thread {

    Gui gui;

    public RefreshClassEntities(Gui gui) {
        this.gui = gui;
    }

    @Override
    public void run() {
        try {
            Thread.sleep(300000);

            // Code actualisation
            Hotel.termReservation();
            Hotel.refreshEntitiesBar();
            Hotel.refreshEntitiesBarVente();
            Hotel.refreshEntitiesBloc();
            Hotel.refreshEntitiesBoisson();
            Hotel.refreshEntitiesCaisseBar();
            Hotel.refreshEntitiesCaisseDivers();
            Hotel.refreshEntitiesCaissePiscine();
            Hotel.refreshEntitiesCaisseReservation();
            Hotel.refreshEntitiesCaisseRestaurant();
            Hotel.refreshEntitiesCaracteristiqueChambre();
            Hotel.refreshEntitiesCarteFidelite();
            Hotel.refreshEntitiesCategorieBoisson();
            Hotel.refreshEntitiesCategorieChambre();
            Hotel.refreshEntitiesClient();
            Hotel.refreshEntitiesCategorieLit();
            Hotel.refreshEntitiesCategorieMenu();
            Hotel.refreshEntitiesChambre();
            Hotel.refreshEntitiesClient();
            Hotel.refreshEntitiesEtage();
            Hotel.refreshEntitiesFacture();
            Hotel.refreshEntitiesFactureTable();
            Hotel.refreshEntitiesLit();
            Hotel.refreshEntitiesPenalite();
            Hotel.refreshEntitiesPerte();
            Hotel.refreshEntitiesPiscine();
            Hotel.refreshEntitiesReservation();
            Hotel.refreshEntitiesRestaurant();
            Hotel.refreshEntitiesRestaurantVente();
            Hotel.refreshEntitiesServeur();
            Hotel.refreshEntitiesSituationChambre();
            Hotel.refreshEntitiesStockBoisson();
            Hotel.refreshEntitiesTableHotel();
            Hotel.refreshEntitiesTypeChambre();
            Hotel.refreshEntitiesUtilisateur();
            Hotel.refreshEntitiesVenteAccesPiscine();

            Hotel hotel = new Hotel();
            Object[][] tableau = new Object[hotel.listerBoissons().size()][4];
            List<CategorieBoisson> listCategorieBoissons = hotel.listerCategoriesBoisson();
            int i = 0;
            for (CategorieBoisson categorieBoisson : listCategorieBoissons) {
                List<Boisson> listBoissons = hotel.listerBoissonsParCategorieBoisson(categorieBoisson);
                for (Boisson boisson : listBoissons) {
                    BoissonSeuil boissonSeuil = hotel.listerBoissonSeuilParBoisson(boisson);
                    int seuil = 0;
                    try {
                        if (boissonSeuil != null) {
                            try {
                                seuil = (int) Integer.parseInt(String.valueOf(boissonSeuil.getSeuil()));
                            } catch (NumberFormatException numberFormatException) {
                            }
                            int stockRestant = hotel.getStockRestantBoisson(boisson);
                            if (stockRestant < seuil) {
                                tableau[i][0] = categorieBoisson.getLibelle();
                                tableau[i][1] = boisson.getLibelle();
                                tableau[i][2] = stockRestant;
                                tableau[i][3] = boissonSeuil.getSeuil();
                                i++;
                            }
                        }
                    } catch (Exception e) {
                    }
                }
            }
            if (i > 0) {
//                try {
//                    gui.getAudioClip().stop();
//                } catch (Exception e) {
//                }
//                
//                AudioClip audioClip = null;
//                try {
//                    audioClip = new AppletAudioClip(getClass().getResource("/hotelpro/resources/sons/alerte_stock.wav"));
//                } catch (Exception e) {
//                }
//                
//                try {
//                    gui.setAudioClip(audioClip);
//                    gui.getAudioClip().play();
//                } catch (Exception e) {
//                }
                int consulter = JOptionPane.showConfirmDialog(gui, "Le stock de certaines boissons s'épuise. "
                        + "Voulez-vous consulter leur liste?");
                if (consulter == JOptionPane.YES_OPTION) {
                    new AlerteStock(gui, Boolean.TRUE, tableau).setVisible(Boolean.TRUE);
                }
            }

        } catch (InterruptedException ex) {
            Logger.getLogger(RefreshClassEntities.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
