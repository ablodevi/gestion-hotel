<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
define("dsn", "mysql:host=localhost;dbname=");
define("username", "");
define("passwd", "");
?>
