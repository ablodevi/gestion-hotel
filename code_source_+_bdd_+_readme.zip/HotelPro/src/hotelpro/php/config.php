<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

include_once 'db_info.php';

$bdd = new PDO(dsn, username, passwd);

//Config StockBoisson
$j = 63; // 62 boissons pour l'instant
$variation = '300';
$date_heure = '2013-06-01 15:23:00.0'; // Heure fixée
$provenance = 'Fournisseur X';
$login = 'admin';
for ($i = 1; $i < $j; $i++) {
   $statement = "insert into stock_boisson (variation, date_heure, boisson, provenance, login) 
    values ('$variation','$date_heure',$i,'$provenance','$login')";
   echo "$statement <br/>";
   $bdd->exec($statement);
}


?>
