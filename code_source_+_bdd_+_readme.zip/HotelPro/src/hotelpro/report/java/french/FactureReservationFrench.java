package hotelpro.report.java.french;

import com.mysql.jdbc.Driver;
import hotelpro.entities.BarVente;
import hotelpro.entities.CaracteristiqueChambre;
import hotelpro.entities.Chambre;
import hotelpro.entities.Client;
import hotelpro.entities.Penalite;
import hotelpro.entities.Reservation;
import hotelpro.entities.RestaurantVente;
import hotelpro.entities.SituationChambre;
import hotelpro.entities.TypeChambre;
import hotelpro.entities.VenteAccesPiscine;
import hotelpro.security.ParametresConnexion;
import hotelpro.utils.Hotel;
import hotelpro.utils.Paths;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;

public class FactureReservationFrench {

    Hotel hotel = new Hotel();
    Paths paths = new Paths();
    ParametresConnexion parametresConnexion = new ParametresConnexion();
    int idFacture;
    int idReservation;
    Reservation reservation;
    Client client;
    Chambre chambre;

    public FactureReservationFrench() {
    }

    public FactureReservationFrench(int idFacture, int idReservation) throws JRException, SQLException {
        this.idFacture = idFacture;
        this.idReservation = idReservation;

        reservation = hotel.listerReservationParId(idReservation);
        client = hotel.listerClientParId(reservation.getClient());
        chambre = hotel.listerChambreParId(reservation.getChambre());
        config();
    }

    private void config() throws JRException, SQLException {
        List<Penalite> listPenalites = hotel.listerPenalitesParReservation(reservation);
        float coutPenalites = 0;
        try {
            if (listPenalites != null) {
                for (Penalite penalite : listPenalites) {
                    try {
                        coutPenalites += (float) Float.parseFloat(String.valueOf(penalite.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }
                }
            }
        } catch (Exception e) {
        }

        float coutChambre = 0;
        try {
            TypeChambre typeChambre = hotel.listerTypeChambreParChambre(chambre);
            CaracteristiqueChambre caracteristiqueChambre = hotel.listerCaracteristiqueChambreParChambre(chambre);
            SituationChambre situationChambre = hotel.listerSituationChambreParChambre(chambre);
            try {
                coutChambre = (float) Float.parseFloat(String.valueOf(typeChambre.getCout()))
                        + (float) Float.parseFloat(String.valueOf(caracteristiqueChambre.getCout()))
                        + (float) Float.parseFloat(String.valueOf(situationChambre.getCout()));
            } catch (NumberFormatException numberFormatException) {
            }
        } catch (Exception e) {
        }

        float coutBarVente = 0;
        try {
            List<BarVente> listBarVentes = hotel.listerBarVentesParReservation(reservation);
            if (listBarVentes != null) {
                for (BarVente barVente : listBarVentes) {
                    try {
                        coutBarVente += (float) Float.parseFloat(String.valueOf(barVente.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }
                }
            }
        } catch (Exception e) {
        }

        float coutRestoVente = 0;
        try {
            List<RestaurantVente> listRestaurantVentes = hotel.listerRestaurantVentesParReservation(reservation);
            if (listRestaurantVentes != null) {
                for (RestaurantVente restaurantVente : listRestaurantVentes) {
                    try {
                        coutRestoVente += (float) Float.parseFloat(String.valueOf(restaurantVente.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }
                }
            }
        } catch (Exception e) {
        }

        float coutAccesPiscine = 0;
        try {
            List<VenteAccesPiscine> listVenteAccesPiscines = hotel.listerVenteAccesPiscinesParReservation(reservation);
            if (listVenteAccesPiscines != null) {
                for (VenteAccesPiscine venteAccesPiscine : listVenteAccesPiscines) {
                    try {
                        coutAccesPiscine += (float) Float.parseFloat(String.valueOf(venteAccesPiscine.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }
                }
            }
        } catch (Exception e) {
        }

        float coutBarRestoPiscine = coutBarVente + coutRestoVente + coutAccesPiscine;

        // - Connexion à la base
        Driver monDriver = new com.mysql.jdbc.Driver();
        DriverManager.registerDriver(monDriver);
        Connection connection = DriverManager.getConnection(parametresConnexion.recupererUrl() + parametresConnexion.recupererDbName(),
                parametresConnexion.recupererDbUserName(), parametresConnexion.recupererDbPassword());

        // - Paramètres à envoyer au rapport
        Map parameters = new HashMap<>();
        parameters.put("idFacture", idFacture);
        parameters.put("idReservation", idReservation);
        parameters.put("logo", getClass().getResource("/hotelpro/resources/report_logo.jpg"));
        parameters.put("coutPenalites", String.valueOf(coutPenalites));
        parameters.put("coutChambre", String.valueOf(coutChambre));
        parameters.put("barRestoPiscine", String.valueOf(coutBarRestoPiscine));
        parameters.put("netApayer", String.valueOf(coutChambre + coutBarRestoPiscine + coutPenalites));

        //Remplissage du rapport
        JasperPrint jasperPrint = JasperFillManager.fillReport(
                getClass().getResource("/hotelpro/report/jrxml/french/Reservation.jasper").getPath(), parameters, connection);

        // export en pdf
        JRPdfExporter pdfExporter = new JRPdfExporter();
        pdfExporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
        String repertoireCli = paths.recupererScansPath() + client.getNom() + " " + client.getPrenoms();
        new File(repertoireCli).mkdir();
        repertoireCli += File.separator + new StringTokenizer(reservation.getDateArrivee(), " ").nextToken();
        new File(repertoireCli).mkdir();
        repertoireCli += File.separator + client.getNom() + " " + client.getPrenoms()
                + " Reservation N° " + reservation.getId() + " Facture.pdf";
        File file = new File(repertoireCli);
        pdfExporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, file);
        pdfExporter.exportReport();

        JOptionPane.showMessageDialog(null, "Génération de la facture terminée.");
        try {
            String command = "explorer.exe " + file.getPath();
            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec(command);
            process.waitFor();
        } catch (IOException | InterruptedException e) {
        }
    }

    public static void main(String[] args) throws JRException, SQLException {
        FactureReservationFrench reservation_Report_French = new FactureReservationFrench();
    }
}
