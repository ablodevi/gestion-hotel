/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Gui.java
 *
 * Created on Jan 21, 2013, 7:26:07 PM
 */
package hotelpro.gui;

import hotelpro.dynamics.RefreshClassEntities;
import hotelpro.entities.Utilisateur;
import hotelpro.gui.views.ClientView;
import hotelpro.gui.views.InfoView;
import hotelpro.gui.views.LogView;
import hotelpro.gui.views.PerteView;
import hotelpro.gui.views.UtilisateurView;
import hotelpro.utils.Hotel;
import hotelpro.utils.Paths;
import java.applet.AudioClip;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import sun.applet.AppletAudioClip;

/**
 *
 * @author Serge
 */
public class Gui extends javax.swing.JFrame {

    Hotel hotel = new Hotel();
    Paths paths = new Paths();
    CardLayout cardLayout = new CardLayout();
    Utilisateur utilisateur = new Utilisateur();
    Accueil accueil = new Accueil();
    String accueilString = "Accueil";
//    RechercherPanel rechercherPanel;
//    String rechercherPanelString = "rechercherPanel";
    RechercheClients rechercheClients;
    String rechercheClientsString = "rechercheClients";
    InfoView infoView = new InfoView(Boolean.FALSE, null, null, null, null);
    String infoViewString = "InfoViewFALSE";
    UtilisateurView utilisateurView;
    String utilisateurViewString = "UtilisateurView";
    Administration administration;
    String administrationString = "Administration";
    String fenetre = "";
    Apropos apropos = new Apropos();
    String aproposString = "Apropos";
    Documentation documentation = new Documentation();
    String documentationString = "Documentation";
    Configuration configuration;
    String configurationString = "Configuration";
    ClientView clientView;
    String clientViewString = "Enregistrement Client";
    GestionReservations gestionReservations;
    String gestionReservationsString = "Gestion globale des reservations";
    GestionBarResto gestionBarResto;
    String gestionBarRestoString = "Gestion des bars";
    GestionPiscines gestionPiscines;
    String gestionPiscinesString = "Gestion des piscines";
    GestionFacturation gestionFacturation;
    String gestionFacturationString = "Gestion Facturation";
    GestionPersonnel gestionPersonnel;
    String gestionPersonnelString = "Gestion Personnel";
    LogView logView = new LogView();
    String logViewString = "LogView";
    PerteView perteView;
    String perteViewString = "PerteView";
    FluxPrix fluxPrix;
    String fluxPrixString = "FluxPrix";
    //AudioClip audioClip;
    int sonInactif = 0;
    RefreshClassEntities refreshClassEntities;

    /**
     * Creates new form Gui
     */
    public Gui(Utilisateur utilisateur) {
        initComponents();
        setTitle("GESTION HÔTELLIERE PROFESSIONNELLE - HÔTEL PRO");
        Dimension dimension = new Dimension();
        dimension.width = 1160;
        dimension.height = 710;
        setMinimumSize(dimension);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(this.getParent());

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Bienvenue!"));

        try {
            this.utilisateur = utilisateur;
        } catch (Exception e) {
        }

        try {
            jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Bienvenue " + utilisateur.getLogin() + " !"));
        } catch (Exception e) {
        }
        
        refreshPhotoButtonActionPerformed(null);

        jPanel3.setLayout(cardLayout);

        jPanel3.add(accueil, accueilString);

        jPanel3.add(documentation, documentationString);

        jPanel3.add(logView, logViewString);

        jPanel3.add(infoView, infoViewString);

        utilisateurView = new UtilisateurView(utilisateur.getLogin());
        jPanel3.add(utilisateurView, utilisateurViewString);

        jPanel3.add(apropos, aproposString);

        configuration = new Configuration(utilisateur.getLogin());
        jPanel3.add(configuration, configurationString);

//        clientView = new ClientView(this, cardLayout, clientViewString, rechercherPanel, rechercherPanelString);
        clientView = new ClientView(this, cardLayout, clientViewString, rechercheClients, rechercheClientsString);
        jPanel3.add(clientView, clientViewString);

        gestionReservations = new GestionReservations(this, utilisateur.getLogin());
        jPanel3.add(gestionReservations, gestionReservationsString);

        gestionBarResto = new GestionBarResto(utilisateur.getLogin());
        jPanel3.add(gestionBarResto, gestionBarRestoString);

        gestionPiscines = new GestionPiscines(utilisateur.getLogin());
        jPanel3.add(gestionPiscines, gestionPiscinesString);

        gestionFacturation = new GestionFacturation(utilisateur.getLogin());
        jPanel3.add(gestionFacturation, gestionFacturationString);
        
        perteView = new PerteView(utilisateur.getLogin());
        jPanel3.add(perteView, perteViewString);
        
        fluxPrix = new FluxPrix();
        jPanel3.add(fluxPrix, fluxPrixString);

        gestionPersonnel = new GestionPersonnel(utilisateur.getLogin());
        jPanel3.add(gestionPersonnel, gestionPersonnelString);
        //audioClip = new AppletAudioClip(getClass().getResource("/hotelpro/resources/sons/nom_fichier_2.wav"));
        //audioClip.play();

        startRefreshClassEntities();
    }

//    public AudioClip getAudioClip() {
//        return audioClip;
//    }

//    public void setAudioClip(AudioClip audioClip) {
//        this.audioClip = audioClip;
//    }

    public JPanel getjPanel3() {
        return jPanel3;
    }

    public JButton getGestionBarRestoButton() {
        return gestionBarRestoButton;
    }

    public void setGestionBarRestoButton(JButton gestionBarRestoButton) {
        this.gestionBarRestoButton = gestionBarRestoButton;
    }

    public JButton getVerrouillerLogiciel_button() {
        return verrouillerLogiciel_button;
    }

    public void setVerrouillerLogiciel_button(JButton verrouillerLogiciel_button) {
        this.verrouillerLogiciel_button = verrouillerLogiciel_button;
    }

    public JButton getGestionClientsButton() {
        return gestionClientsButton;
    }

    public void setGestionClientsButton(JButton gestionClientsButton) {
        this.gestionClientsButton = gestionClientsButton;
    }

    public JButton getGestionReservationsButton() {
        return gestionReservationsButton;
    }

    public void setGestionReservationsButton(JButton gestionReservationsButton) {
        this.gestionReservationsButton = gestionReservationsButton;
    }

    public JButton getGestionFacturationButton() {
        return gestionFacturationButton;
    }

    public void setGestionFacturationButton(JButton gestionFacturationButton) {
        this.gestionFacturationButton = gestionFacturationButton;
    }

    public JButton getGestionPiscinesButton() {
        return gestionPiscinesButton;
    }

    public void setGestionPiscinesButton(JButton gestionPiscinesButton) {
        this.gestionPiscinesButton = gestionPiscinesButton;
    }

    public JButton getRefreshPhotoButton() {
        return refreshPhotoButton;
    }

    public void setRefreshPhotoButton(JButton refreshPhotoButton) {
        this.refreshPhotoButton = refreshPhotoButton;
    }

    public JButton getAccueilButton() {
        return accueilButton;
    }

    public void setAccueilButton(JButton accueilButton) {
        this.accueilButton = accueilButton;
    }

    public JMenu getAccueilMenu() {
        return accueilMenu;
    }

    public void setAccueilMenu(JMenu accueilMenu) {
        this.accueilMenu = accueilMenu;
    }

    public JMenu getPlusMenu() {
        return plusMenu;
    }

    public void setPlusMenu(JMenu plusMenu) {
        this.plusMenu = plusMenu;
    }

    public JMenu getAideMenu() {
        return aideMenu;
    }

    public void setAideMenu(JMenu aideMenu) {
        this.aideMenu = aideMenu;
    }

    public JMenu getEditerMenu() {
        return editerMenu;
    }

    public void setEditerMenu(JMenu editerMenu) {
        this.editerMenu = editerMenu;
    }

    public JMenu getOutilsMenu() {
        return outilsMenu;
    }

    public void setOutilsMenu(JMenu outilsMenu) {
        this.outilsMenu = outilsMenu;
    }

    public JButton getDeconnecter_button() {
        return deconnecter_button;
    }

    public void setDeconnecter_button(JButton deconnecter_button) {
        this.deconnecter_button = deconnecter_button;
    }

    public JLabel getConnectedLabel() {
        return connectedLabel;
    }

    public void setConnectedLabel(JLabel connectedLabel) {
        this.connectedLabel = connectedLabel;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        accueilButton = new javax.swing.JButton();
        verrouillerLogiciel_button = new javax.swing.JButton();
        deconnecter_button = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        photoLab = new javax.swing.JLabel();
        connectedLabel = new javax.swing.JLabel();
        refreshPhotoButton = new javax.swing.JButton();
        gestionClientsButton = new javax.swing.JButton();
        gestionReservationsButton = new javax.swing.JButton();
        gestionBarRestoButton = new javax.swing.JButton();
        gestionPiscinesButton = new javax.swing.JButton();
        gestionFacturationButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        accueilMenu = new javax.swing.JMenu();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        fluxPrixMenuItem = new javax.swing.JMenuItem();
        jSeparator21 = new javax.swing.JPopupMenu.Separator();
        logsMenuItem = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JPopupMenu.Separator();
        jSeparator30 = new javax.swing.JPopupMenu.Separator();
        accueilMenuItem = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        verrouillerLogicielMenuItem = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        jSeparator13 = new javax.swing.JPopupMenu.Separator();
        quitterMenuItem = new javax.swing.JMenuItem();
        jSeparator20 = new javax.swing.JPopupMenu.Separator();
        editerMenu = new javax.swing.JMenu();
        jSeparator22 = new javax.swing.JPopupMenu.Separator();
        clientsMenuItem = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        reservationMenuItem = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        jSeparator14 = new javax.swing.JPopupMenu.Separator();
        perteMenuItem = new javax.swing.JMenuItem();
        jSeparator31 = new javax.swing.JPopupMenu.Separator();
        penalitesMenuItem = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JPopupMenu.Separator();
        facturesMenuItem = new javax.swing.JMenuItem();
        jSeparator12 = new javax.swing.JPopupMenu.Separator();
        jSeparator15 = new javax.swing.JPopupMenu.Separator();
        utilisateursMenuItem = new javax.swing.JMenuItem();
        jSeparator10 = new javax.swing.JPopupMenu.Separator();
        outilsMenu = new javax.swing.JMenu();
        jSeparator23 = new javax.swing.JPopupMenu.Separator();
        jCheckBoxActiverSonMenuItem = new javax.swing.JCheckBoxMenuItem();
        jSeparator16 = new javax.swing.JPopupMenu.Separator();
        audioMenuItem = new javax.swing.JMenuItem();
        jSeparator17 = new javax.swing.JPopupMenu.Separator();
        jSeparator18 = new javax.swing.JPopupMenu.Separator();
        systemPropertiesMenuItem = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        configurationMenuItem = new javax.swing.JMenuItem();
        plusMenu = new javax.swing.JMenu();
        jSeparator26 = new javax.swing.JPopupMenu.Separator();
        gestionArchivesMenuItem = new javax.swing.JMenuItem();
        jSeparator27 = new javax.swing.JPopupMenu.Separator();
        gestionPersonnelMenuItem = new javax.swing.JMenuItem();
        jSeparator28 = new javax.swing.JPopupMenu.Separator();
        encorePlusMenuItem = new javax.swing.JMenuItem();
        jSeparator29 = new javax.swing.JPopupMenu.Separator();
        aideMenu = new javax.swing.JMenu();
        jSeparator25 = new javax.swing.JPopupMenu.Separator();
        documentationMenuItem = new javax.swing.JMenuItem();
        jSeparator11 = new javax.swing.JPopupMenu.Separator();
        vueCritiqueMenuItem = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        suggestionProblemeMenuItem = new javax.swing.JMenuItem();
        jSeparator19 = new javax.swing.JPopupMenu.Separator();
        aboutMenuItem = new javax.swing.JMenuItem();
        jSeparator24 = new javax.swing.JPopupMenu.Separator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        accueilButton.setText("Accueil");
        accueilButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accueilButtonActionPerformed(evt);
            }
        });

        verrouillerLogiciel_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/logiciel verrouille.png"))); // NOI18N
        verrouillerLogiciel_button.setText("Verrouiller la session courante");
        verrouillerLogiciel_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verrouillerLogiciel_buttonActionPerformed(evt);
            }
        });

        deconnecter_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/deconnecter.png"))); // NOI18N
        deconnecter_button.setText("Déconnexion");
        deconnecter_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deconnecter_buttonActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(0, 153, 153));
        jLabel1.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("GESTION HÔTELLIERE PROFESSIONNELLE");
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "HÔTEL PRO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, new java.awt.Color(0, 51, 51)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(accueilButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(verrouillerLogiciel_button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 621, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(deconnecter_button)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(verrouillerLogiciel_button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(accueilButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deconnecter_button, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_START);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        photoLab.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        photoLab.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        connectedLabel.setForeground(new java.awt.Color(0, 102, 102));
        connectedLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        connectedLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/statut-en-ligne.png"))); // NOI18N
        connectedLabel.setText("Statut : Connecté");

        refreshPhotoButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tinyRefresh.png"))); // NOI18N
        refreshPhotoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshPhotoButtonActionPerformed(evt);
            }
        });

        gestionClientsButton.setForeground(new java.awt.Color(0, 51, 51));
        gestionClientsButton.setText("Gestion des clients");
        gestionClientsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionClientsButtonActionPerformed(evt);
            }
        });

        gestionReservationsButton.setForeground(new java.awt.Color(0, 51, 51));
        gestionReservationsButton.setText("Gestion des réservations");
        gestionReservationsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionReservationsButtonActionPerformed(evt);
            }
        });

        gestionBarRestoButton.setForeground(new java.awt.Color(0, 51, 51));
        gestionBarRestoButton.setText("Gestion des bars - restaurants");
        gestionBarRestoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionBarRestoButtonActionPerformed(evt);
            }
        });

        gestionPiscinesButton.setText("Gestion des piscines");
        gestionPiscinesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionPiscinesButtonActionPerformed(evt);
            }
        });

        gestionFacturationButton.setText("Facturation");
        gestionFacturationButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionFacturationButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(connectedLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gestionClientsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gestionReservationsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gestionBarRestoButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gestionPiscinesButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gestionFacturationButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(refreshPhotoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(photoLab, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(connectedLabel)
                .addGap(8, 8, 8)
                .addComponent(photoLab, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(refreshPhotoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gestionClientsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gestionReservationsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gestionBarRestoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gestionPiscinesButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gestionFacturationButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(139, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.LINE_START);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 921, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 548, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel3);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        accueilMenu.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        accueilMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/home.png"))); // NOI18N
        accueilMenu.add(jSeparator1);

        fluxPrixMenuItem.setText("Visualiser les fluctuations des prix");
        fluxPrixMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fluxPrixMenuItemActionPerformed(evt);
            }
        });
        accueilMenu.add(fluxPrixMenuItem);
        accueilMenu.add(jSeparator21);

        logsMenuItem.setText("Visualiser les logs");
        logsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logsMenuItemActionPerformed(evt);
            }
        });
        accueilMenu.add(logsMenuItem);
        accueilMenu.add(jSeparator9);
        accueilMenu.add(jSeparator30);

        accueilMenuItem.setText("Retourner à l'accueil");
        accueilMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accueilMenuItemActionPerformed(evt);
            }
        });
        accueilMenu.add(accueilMenuItem);
        accueilMenu.add(jSeparator2);

        verrouillerLogicielMenuItem.setText("Verrouiller la session courante");
        verrouillerLogicielMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verrouillerLogicielMenuItemActionPerformed(evt);
            }
        });
        accueilMenu.add(verrouillerLogicielMenuItem);
        accueilMenu.add(jSeparator4);
        accueilMenu.add(jSeparator13);

        quitterMenuItem.setText("Quitter");
        quitterMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitterMenuItemActionPerformed(evt);
            }
        });
        accueilMenu.add(quitterMenuItem);
        accueilMenu.add(jSeparator20);

        jMenuBar1.add(accueilMenu);

        editerMenu.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        editerMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/edit.png"))); // NOI18N
        editerMenu.setText("Editer");
        editerMenu.add(jSeparator22);

        clientsMenuItem.setText("Clients");
        clientsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientsMenuItemActionPerformed(evt);
            }
        });
        editerMenu.add(clientsMenuItem);
        editerMenu.add(jSeparator5);

        reservationMenuItem.setText("Réservations");
        reservationMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reservationMenuItemActionPerformed(evt);
            }
        });
        editerMenu.add(reservationMenuItem);
        editerMenu.add(jSeparator6);
        editerMenu.add(jSeparator14);

        perteMenuItem.setText("Nouvelle perte");
        perteMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                perteMenuItemActionPerformed(evt);
            }
        });
        editerMenu.add(perteMenuItem);
        editerMenu.add(jSeparator31);

        penalitesMenuItem.setText("Pénalités");
        penalitesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                penalitesMenuItemActionPerformed(evt);
            }
        });
        editerMenu.add(penalitesMenuItem);
        editerMenu.add(jSeparator8);

        facturesMenuItem.setText("Factures");
        facturesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facturesMenuItemActionPerformed(evt);
            }
        });
        editerMenu.add(facturesMenuItem);
        editerMenu.add(jSeparator12);
        editerMenu.add(jSeparator15);

        utilisateursMenuItem.setText("Utilisateurs du logiciel");
        utilisateursMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                utilisateursMenuItemActionPerformed(evt);
            }
        });
        editerMenu.add(utilisateursMenuItem);
        editerMenu.add(jSeparator10);

        jMenuBar1.add(editerMenu);

        outilsMenu.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        outilsMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tools.png"))); // NOI18N
        outilsMenu.setText("Outils");
        outilsMenu.add(jSeparator23);

        jCheckBoxActiverSonMenuItem.setSelected(true);
        jCheckBoxActiverSonMenuItem.setText("Activer les sons systèmes");
        jCheckBoxActiverSonMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxActiverSonMenuItemActionPerformed(evt);
            }
        });
        outilsMenu.add(jCheckBoxActiverSonMenuItem);
        outilsMenu.add(jSeparator16);

        audioMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/audio.png"))); // NOI18N
        audioMenuItem.setText("Audio");
        audioMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                audioMenuItemActionPerformed(evt);
            }
        });
        outilsMenu.add(audioMenuItem);
        outilsMenu.add(jSeparator17);
        outilsMenu.add(jSeparator18);

        systemPropertiesMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/systemProperties.png"))); // NOI18N
        systemPropertiesMenuItem.setText("Propriétés systeme");
        systemPropertiesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                systemPropertiesMenuItemActionPerformed(evt);
            }
        });
        outilsMenu.add(systemPropertiesMenuItem);
        outilsMenu.add(jSeparator3);

        configurationMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/configuration.PNG"))); // NOI18N
        configurationMenuItem.setText("Configuration - Contrôle");
        configurationMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                configurationMenuItemActionPerformed(evt);
            }
        });
        outilsMenu.add(configurationMenuItem);

        jMenuBar1.add(outilsMenu);

        plusMenu.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        plusMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/plusBleu.png"))); // NOI18N
        plusMenu.setText("Autres modules");
        plusMenu.add(jSeparator26);

        gestionArchivesMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/archive.jpg"))); // NOI18N
        gestionArchivesMenuItem.setText("Gestion des archives");
        gestionArchivesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionArchivesMenuItemActionPerformed(evt);
            }
        });
        plusMenu.add(gestionArchivesMenuItem);
        plusMenu.add(jSeparator27);

        gestionPersonnelMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/personnel.png"))); // NOI18N
        gestionPersonnelMenuItem.setText("Gestion du personnel");
        gestionPersonnelMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionPersonnelMenuItemActionPerformed(evt);
            }
        });
        plusMenu.add(gestionPersonnelMenuItem);
        plusMenu.add(jSeparator28);

        encorePlusMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/plus.PNG"))); // NOI18N
        encorePlusMenuItem.setText("Encore plus !");
        encorePlusMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                encorePlusMenuItemActionPerformed(evt);
            }
        });
        plusMenu.add(encorePlusMenuItem);
        plusMenu.add(jSeparator29);

        jMenuBar1.add(plusMenu);

        aideMenu.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        aideMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/aide.png"))); // NOI18N
        aideMenu.setText("Aide");
        aideMenu.add(jSeparator25);

        documentationMenuItem.setText("Premiers pas avec HÔTEL PRO");
        documentationMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                documentationMenuItemActionPerformed(evt);
            }
        });
        aideMenu.add(documentationMenuItem);
        aideMenu.add(jSeparator11);

        vueCritiqueMenuItem.setText("Vue critique sur HÔTEL PRO");
        vueCritiqueMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vueCritiqueMenuItemActionPerformed(evt);
            }
        });
        aideMenu.add(vueCritiqueMenuItem);
        aideMenu.add(jSeparator7);

        suggestionProblemeMenuItem.setText("Suggestions / Problèmes");
        suggestionProblemeMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                suggestionProblemeMenuItemActionPerformed(evt);
            }
        });
        aideMenu.add(suggestionProblemeMenuItem);
        aideMenu.add(jSeparator19);

        aboutMenuItem.setText("Conception et développement");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutMenuItemActionPerformed(evt);
            }
        });
        aideMenu.add(aboutMenuItem);
        aideMenu.add(jSeparator24);

        jMenuBar1.add(aideMenu);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

	private void refreshPhotoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshPhotoButtonActionPerformed
            // TODO add your handling code here:
            try {
                List<Utilisateur> listUtilisateurs = hotel.listerUtilisateurs();
                for (Utilisateur u : listUtilisateurs) {
                    if ((int) u.getId() == (int) utilisateur.getId()) {
                        if (u.getPhoto() != null) {
                            String phot = paths.recupererUsersPhotosPassportPath() + u.getPhoto();
                            String img = "<html><img alt=\"\" src=\"file:\\\\\\" + phot.toString() + "\"height='" + photoLab.getHeight() + "'" + " width='" + photoLab.getWidth() + "'/></html>";
                            photoLab.setText(img);
//                            photoLab.setIcon(new ImageIcon(Paths.USERS_PHOTOS_PASSPORT_PATH + u.getPhoto()));
                        } else {
                            photoLab.setIcon(null);
                        }
                    }
                }
            } catch (Exception e) {
                photoLab.setIcon(null);
            }
	}//GEN-LAST:event_refreshPhotoButtonActionPerformed

	private void quitterMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitterMenuItemActionPerformed
            // TODO add your handling code here:
            try {
                //audioClip.stop();
            } catch (Exception e) {
            }
            try {
                //apropos.getAudioClip().stop();
            } catch (Exception e) {
            }

            int ok = JOptionPane.showConfirmDialog(this, "Vous avez demandé la fermeture de l'application. Continuer?");
            if (ok == JOptionPane.YES_OPTION) {
                dispose();
            }   
	}//GEN-LAST:event_quitterMenuItemActionPerformed

	private void deconnecter_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deconnecter_buttonActionPerformed
            // TODO add your handling code here:
            quitterMenuItemActionPerformed(evt);
	}//GEN-LAST:event_deconnecter_buttonActionPerformed

	private void gestionClientsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionClientsButtonActionPerformed
            // TODO add your handling code here:
            try {
                //audioClip.stop();
            } catch (Exception e) {
            }
            cardLayout.show(jPanel3, clientViewString);
	}//GEN-LAST:event_gestionClientsButtonActionPerformed

	private void gestionReservationsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionReservationsButtonActionPerformed
            // TODO add your handling code here:
            try {
                //audioClip.stop();
            } catch (Exception e) {
            }
            cardLayout.show(jPanel3, gestionReservationsString);
	}//GEN-LAST:event_gestionReservationsButtonActionPerformed

	private void gestionBarRestoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionBarRestoButtonActionPerformed
            // TODO add your handling code here:
            try {
                //audioClip.stop();
            } catch (Exception e) {
            }

//            JOptionPane.showMessageDialog(this, "Ce module n'est pas encore activé.");

            cardLayout.show(jPanel3, gestionBarRestoString);
	}//GEN-LAST:event_gestionBarRestoButtonActionPerformed

	private void clientsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientsMenuItemActionPerformed
            // TODO add your handling code here:
            gestionClientsButtonActionPerformed(evt);
	}//GEN-LAST:event_clientsMenuItemActionPerformed

	private void reservationMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reservationMenuItemActionPerformed
            // TODO add your handling code here:
            gestionReservations.getjTabbedPane1().setSelectedIndex(1);
            gestionReservationsButtonActionPerformed(evt);
	}//GEN-LAST:event_reservationMenuItemActionPerformed

	private void accueilButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accueilButtonActionPerformed
            // TODO add your handling code here:
            accueilMenuItemActionPerformed(evt);
	}//GEN-LAST:event_accueilButtonActionPerformed

	private void verrouillerLogicielMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verrouillerLogicielMenuItemActionPerformed
            // TODO add your handling code here:

            cardLayout.show(jPanel3, accueilString);

            //Desactivation
            connectedLabel.setIcon(new ImageIcon(getClass().getResource("/hotelpro/resources/statut-busy.png")));
            connectedLabel.setText("Statut: Indisponible");

            refreshPhotoButton.setEnabled(Boolean.FALSE);

            gestionClientsButton.setEnabled(Boolean.FALSE);

            gestionReservationsButton.setEnabled(Boolean.FALSE);

            gestionBarRestoButton.setEnabled(Boolean.FALSE);

            gestionPiscinesButton.setEnabled(Boolean.FALSE);

            gestionFacturationButton.setEnabled(Boolean.FALSE);

            accueilButton.setEnabled(Boolean.FALSE);

            verrouillerLogiciel_button.setText("Déverrouiller la session");

            accueilMenu.setEnabled(Boolean.FALSE);

            editerMenu.setEnabled(Boolean.FALSE);

            outilsMenu.setEnabled(Boolean.FALSE);

            plusMenu.setEnabled(Boolean.FALSE);

            aideMenu.setEnabled(Boolean.FALSE);

            new VerrouLogiciel(this, Boolean.TRUE, utilisateur.getLogin()).setVisible(Boolean.TRUE);
	}//GEN-LAST:event_verrouillerLogicielMenuItemActionPerformed

	private void verrouillerLogiciel_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verrouillerLogiciel_buttonActionPerformed
            // TODO add your handling code here:
            try {
                //ip.stop();
            } catch (Exception e) {
            }
            verrouillerLogicielMenuItemActionPerformed(evt);
	}//GEN-LAST:event_verrouillerLogiciel_buttonActionPerformed

	private void accueilMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accueilMenuItemActionPerformed
            // TODO add your handling code here:
            try {
                //audioClip.stop();
            } catch (Exception e) {
            }
            if (sonInactif == 0) {
//                audioClip = new AppletAudioClip(getClass().getResource("/hotelpro/resources/sons/nom_fichier_2.wav"));
//                audioClip.play();
            }
            cardLayout.show(jPanel3, accueilString);
	}//GEN-LAST:event_accueilMenuItemActionPerformed

	private void utilisateursMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_utilisateursMenuItemActionPerformed
            // TODO add your handling code here:
            fenetre = utilisateurViewString;

            administration = new Administration(this, cardLayout, accueilString, fenetre, utilisateurViewString, configurationString, logViewString);
            jPanel3.add(administration, administrationString);

            cardLayout.show(jPanel3, administrationString);
	}//GEN-LAST:event_utilisateursMenuItemActionPerformed

	private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
            // TODO add your handling code here:
            cardLayout.show(jPanel3, aproposString);
	}//GEN-LAST:event_aboutMenuItemActionPerformed

	private void systemPropertiesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_systemPropertiesMenuItemActionPerformed
            // TODO add your handling code here:
            JOptionPane.showMessageDialog(this, "Utilisateur " + System.getProperty("user.name") + " : votre machine tourne sous " + System.getProperty("os.name") + "  " + System.getProperty("os.arch"));
	}//GEN-LAST:event_systemPropertiesMenuItemActionPerformed

	private void vueCritiqueMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vueCritiqueMenuItemActionPerformed
            // TODO add your handling code here:
            cardLayout.show(jPanel3, infoViewString);
	}//GEN-LAST:event_vueCritiqueMenuItemActionPerformed

	private void documentationMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_documentationMenuItemActionPerformed
            // TODO add your handling code here:
            cardLayout.show(jPanel3, documentationString);
	}//GEN-LAST:event_documentationMenuItemActionPerformed

    private void configurationMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_configurationMenuItemActionPerformed
        // TODO add your handling code here:
        fenetre = configurationString;

        administration = new Administration(this, cardLayout, accueilString, fenetre, utilisateurViewString, configurationString, logViewString);
        jPanel3.add(administration, administrationString);

        cardLayout.show(jPanel3, administrationString);
    }//GEN-LAST:event_configurationMenuItemActionPerformed

    private void facturesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_facturesMenuItemActionPerformed
        // TODO add your handling code here:
        gestionFacturationButtonActionPerformed(evt);
    }//GEN-LAST:event_facturesMenuItemActionPerformed

    private void penalitesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_penalitesMenuItemActionPerformed
        // TODO add your handling code here:
        gestionReservations.getjTabbedPane1().setSelectedIndex(2);
        cardLayout.show(jPanel3, gestionReservationsString);
    }//GEN-LAST:event_penalitesMenuItemActionPerformed

    private void gestionPiscinesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionPiscinesButtonActionPerformed
        // TODO add your handling code here:
        try {
            //audioClip.stop();
        } catch (Exception e) {
        }
        cardLayout.show(jPanel3, gestionPiscinesString);
    }//GEN-LAST:event_gestionPiscinesButtonActionPerformed

    private void gestionFacturationButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionFacturationButtonActionPerformed
        // TODO add your handling code here:
        try {
            //audioClip.stop();
        } catch (Exception e) {
        }
        
        cardLayout.show(jPanel3, gestionFacturationString);
    }//GEN-LAST:event_gestionFacturationButtonActionPerformed

    private void jCheckBoxActiverSonMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxActiverSonMenuItemActionPerformed
        // TODO add your handling code here:
        if (jCheckBoxActiverSonMenuItem.isSelected()) {
            sonInactif = 0;
        } else {
            try {
                //audioClip.stop();
            } catch (Exception e) {
            }
            sonInactif = 1;
        }
    }//GEN-LAST:event_jCheckBoxActiverSonMenuItemActionPerformed

    private void audioMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_audioMenuItemActionPerformed
        // TODO add your handling code here:
        cardLayout.show(jPanel3, aproposString);
    }//GEN-LAST:event_audioMenuItemActionPerformed

    private void suggestionProblemeMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_suggestionProblemeMenuItemActionPerformed
        // TODO add your handling code here:
        accueilMenuItemActionPerformed(evt);
    }//GEN-LAST:event_suggestionProblemeMenuItemActionPerformed

    private void logsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logsMenuItemActionPerformed
        // TODO add your handling code here:
        fenetre = logViewString;

        administration = new Administration(this, cardLayout, accueilString, fenetre, utilisateurViewString, configurationString, logViewString);
        jPanel3.add(administration, administrationString);

        cardLayout.show(jPanel3, administrationString);
    }//GEN-LAST:event_logsMenuItemActionPerformed

    private void encorePlusMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_encorePlusMenuItemActionPerformed
        // TODO add your handling code here:
        cardLayout.show(jPanel3, aproposString);
    }//GEN-LAST:event_encorePlusMenuItemActionPerformed

    private void gestionPersonnelMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionPersonnelMenuItemActionPerformed
        // TODO add your handling code here:
        try {
            //audioClip.stop();
        } catch (Exception e) {
        }
        JOptionPane.showMessageDialog(this, "Ce module n'est pas encore activé.");
//        cardLayout.show(jPanel3, gestionPersonnelString);
    }//GEN-LAST:event_gestionPersonnelMenuItemActionPerformed

    private void gestionArchivesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gestionArchivesMenuItemActionPerformed
        // TODO add your handling code here:
        try {
            //audioClip.stop();
        } catch (Exception e) {
        }
        JOptionPane.showMessageDialog(this, "Ce module n'est pas encore activé.");
    }//GEN-LAST:event_gestionArchivesMenuItemActionPerformed

    private void perteMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_perteMenuItemActionPerformed
        // TODO add your handling code here:
        cardLayout.show(jPanel3, perteViewString);
    }//GEN-LAST:event_perteMenuItemActionPerformed

    private void fluxPrixMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fluxPrixMenuItemActionPerformed
        // TODO add your handling code here:
        cardLayout.show(jPanel3, fluxPrixString);
    }//GEN-LAST:event_fluxPrixMenuItemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gui.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Gui(null).setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JButton accueilButton;
    private javax.swing.JMenu accueilMenu;
    private javax.swing.JMenuItem accueilMenuItem;
    private javax.swing.JMenu aideMenu;
    private javax.swing.JMenuItem audioMenuItem;
    private javax.swing.JMenuItem clientsMenuItem;
    private javax.swing.JMenuItem configurationMenuItem;
    private javax.swing.JLabel connectedLabel;
    private javax.swing.JButton deconnecter_button;
    private javax.swing.JMenuItem documentationMenuItem;
    private javax.swing.JMenu editerMenu;
    private javax.swing.JMenuItem encorePlusMenuItem;
    private javax.swing.JMenuItem facturesMenuItem;
    private javax.swing.JMenuItem fluxPrixMenuItem;
    private javax.swing.JMenuItem gestionArchivesMenuItem;
    private javax.swing.JButton gestionBarRestoButton;
    private javax.swing.JButton gestionClientsButton;
    private javax.swing.JButton gestionFacturationButton;
    private javax.swing.JMenuItem gestionPersonnelMenuItem;
    private javax.swing.JButton gestionPiscinesButton;
    private javax.swing.JButton gestionReservationsButton;
    private javax.swing.JCheckBoxMenuItem jCheckBoxActiverSonMenuItem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator10;
    private javax.swing.JPopupMenu.Separator jSeparator11;
    private javax.swing.JPopupMenu.Separator jSeparator12;
    private javax.swing.JPopupMenu.Separator jSeparator13;
    private javax.swing.JPopupMenu.Separator jSeparator14;
    private javax.swing.JPopupMenu.Separator jSeparator15;
    private javax.swing.JPopupMenu.Separator jSeparator16;
    private javax.swing.JPopupMenu.Separator jSeparator17;
    private javax.swing.JPopupMenu.Separator jSeparator18;
    private javax.swing.JPopupMenu.Separator jSeparator19;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator20;
    private javax.swing.JPopupMenu.Separator jSeparator21;
    private javax.swing.JPopupMenu.Separator jSeparator22;
    private javax.swing.JPopupMenu.Separator jSeparator23;
    private javax.swing.JPopupMenu.Separator jSeparator24;
    private javax.swing.JPopupMenu.Separator jSeparator25;
    private javax.swing.JPopupMenu.Separator jSeparator26;
    private javax.swing.JPopupMenu.Separator jSeparator27;
    private javax.swing.JPopupMenu.Separator jSeparator28;
    private javax.swing.JPopupMenu.Separator jSeparator29;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator30;
    private javax.swing.JPopupMenu.Separator jSeparator31;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JPopupMenu.Separator jSeparator8;
    private javax.swing.JPopupMenu.Separator jSeparator9;
    private javax.swing.JMenuItem logsMenuItem;
    private javax.swing.JMenu outilsMenu;
    private javax.swing.JMenuItem penalitesMenuItem;
    private javax.swing.JMenuItem perteMenuItem;
    private javax.swing.JLabel photoLab;
    private javax.swing.JMenu plusMenu;
    private javax.swing.JMenuItem quitterMenuItem;
    private javax.swing.JButton refreshPhotoButton;
    private javax.swing.JMenuItem reservationMenuItem;
    private javax.swing.JMenuItem suggestionProblemeMenuItem;
    private javax.swing.JMenuItem systemPropertiesMenuItem;
    private javax.swing.JMenuItem utilisateursMenuItem;
    private javax.swing.JMenuItem verrouillerLogicielMenuItem;
    private javax.swing.JButton verrouillerLogiciel_button;
    private javax.swing.JMenuItem vueCritiqueMenuItem;
    // End of variables declaration//GEN-END:variables

    private void startRefreshClassEntities() {
        refreshClassEntities = new RefreshClassEntities(this);
        refreshClassEntities.start();
    }
}
