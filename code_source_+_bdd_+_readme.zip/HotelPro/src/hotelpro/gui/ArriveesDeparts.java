/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ArriveesDeparts.java
 *
 * Created on Aug 14, 2012, 4:12:41 PM
 */
package hotelpro.gui;

import hotelpro.entities.Client;
import hotelpro.entities.Reservation;
import hotelpro.gui.views.ReservationView;
import hotelpro.utils.Hotel;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Serge
 */
public class ArriveesDeparts extends javax.swing.JPanel {

    Hotel hotel = new Hotel();
    List<Reservation> listReservantsPartants = new LinkedList<>();
    List<Reservation> listReservantsArrivants = new LinkedList<>();
    private Object[][] tableau;
    String tableauTitres[];
    int defaultArrivants = 0;
    int defaultPartants = 0;
    JPanel jPanelArriveesDeparts;
    CardLayout cardLayoutArriveesDeparts;
    String arriveesDepartsString;
    ReservationView reservationView;
    String reservationViewString;
    String login = "";
    JPopupMenu jPopupMenu = new JPopupMenu();
    JMenuItem jMenuItemEditerReservation = new JMenuItem("Editer cette réservation");

    /**
     * Creates new form ArriveesDeparts
     */
    public ArriveesDeparts(JPanel jPanelArriveesDeparts, CardLayout cardLayoutArriveesDeparts,
            String arriveesDepartsString, ReservationView reservationView,
            String reservationViewString, String login) {
        initComponents();

        this.jPanelArriveesDeparts = jPanelArriveesDeparts;
        this.cardLayoutArriveesDeparts = cardLayoutArriveesDeparts;
        this.arriveesDepartsString = arriveesDepartsString;
        this.reservationView = reservationView;
        this.reservationViewString = reservationViewString;
        this.login = login;

        try {
            listReservantsArrivants = hotel.listerReservantsArrivants();
            cmbClients1.removeAllItems();
            for (Iterator<Reservation> it = listReservantsArrivants.iterator(); it.hasNext();) {
                Reservation reservation = it.next();
                try {
                    Client client = hotel.listerClientParId(reservation.getClient());
                    cmbClients1.addItem(client.getNom() + " " + client.getPrenoms());
                } catch (Exception e) {
                }
            }
            tableauTitres = new String[]{"Code Réservation", "Nom", "Prénom(s)", "Date Arrivée"};
            remplirTable(jTable1, listReservantsArrivants);
        } catch (Exception e) {
        }

        try {
            listReservantsPartants = hotel.listerReservantsPartants();
            cmbClients2.removeAllItems();
            for (Iterator<Reservation> it = listReservantsPartants.iterator(); it.hasNext();) {
                Reservation reservation = it.next();
                try {
                    Client client = hotel.listerClientParId(reservation.getClient());
                    cmbClients2.addItem(client.getNom() + " " + client.getPrenoms());
                } catch (Exception e) {
                }
            }
            tableauTitres = new String[]{"Code Réservation", "Nom", "Prénom(s)", "Date Depart"};
            remplirTable(jTable2, listReservantsPartants);
        } catch (Exception e) {
        }

        editerReservationButton1.setEnabled(Boolean.FALSE);
        editerReservationButton2.setEnabled(Boolean.FALSE);
        printButton1.setVisible(Boolean.FALSE);
        printButton2.setVisible(Boolean.FALSE);
    }

    private void remplirTable(JTable jTable, List<Reservation> list) {
        tableau = new Object[list.size()][4];
        int i = 0;
        for (Iterator<Reservation> it = list.iterator(); it.hasNext();) {
            Reservation reservation = it.next();
            Client client = hotel.listerClientParId(reservation.getClient());
            tableau[i][0] = reservation.getId();
            try {
                tableau[i][1] = client.getNom();
            } catch (Exception e) {
            }
            try {
                tableau[i][2] = client.getPrenoms();
            } catch (Exception e) {
            }
            tableau[i][3] = reservation.getDateArrivee();
            i++;
        }
        jTable.setModel(new DefaultTableModel(tableau, tableauTitres));
    }

    public static void main(String[] args) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ArriveesDeparts.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame();
                frame.setContentPane(new ArriveesDeparts(null, null, null, null, null, null));
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cmbClients1 = new javax.swing.JComboBox();
        jDateChooser1Date = new com.toedter.calendar.JDateChooser();
        okButton1 = new javax.swing.JButton();
        printButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        editerReservationButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cmbClients2 = new javax.swing.JComboBox();
        jDateChooser2Date = new com.toedter.calendar.JDateChooser();
        okButton2 = new javax.swing.JButton();
        printButton2 = new javax.swing.JButton();
        editerReservationButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Arrivées Clients"));

        jLabel1.setText("Clients arrivant aujourd'hui:");

        cmbClients1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbClients1ActionPerformed(evt);
            }
        });

        jDateChooser1Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jDateChooser1DateMouseClicked(evt);
            }
        });

        okButton1.setText("Afficher la liste des clients");
        okButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton1ActionPerformed(evt);
            }
        });

        printButton1.setText("Imprimer la liste");
        printButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Choisissez la date voulue:");

        editerReservationButton1.setText("Editer la réservation sélectionnée");
        editerReservationButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editerReservationButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jDateChooser1Date, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbClients1, javax.swing.GroupLayout.Alignment.LEADING, 0, 299, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addComponent(okButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editerReservationButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(cmbClients1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jDateChooser1Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addComponent(okButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(printButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(editerReservationButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Code Réservation", "Nom", "Prénom(s)", "Date Arrivée"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1037, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 62, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel1, java.awt.BorderLayout.PAGE_START);

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Départs Clients"));

        jLabel2.setText("Clients partant aujourd'hui:");

        cmbClients2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbClients2ActionPerformed(evt);
            }
        });

        jDateChooser2Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jDateChooser2DateMouseClicked(evt);
            }
        });

        okButton2.setText("Afficher la liste des clients");
        okButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okButton2ActionPerformed(evt);
            }
        });

        printButton2.setText("Imprimer la liste");
        printButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButton2ActionPerformed(evt);
            }
        });

        editerReservationButton2.setText("Editer la réservation sélectionnée");
        editerReservationButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editerReservationButton2ActionPerformed(evt);
            }
        });

        jLabel4.setText("Choisissez la date voulue:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jDateChooser2Date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmbClients2, 0, 304, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addComponent(okButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editerReservationButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(okButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cmbClients2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jDateChooser2Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)))
                    .addComponent(printButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(editerReservationButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane2.setBackground(new java.awt.Color(255, 255, 255));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Code Réservation", "Nom", "Prénom(s)", "Date Départ"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable2MouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1037, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 66, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        add(jPanel2, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void cmbClients2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbClients2ActionPerformed
        // TODO add your handling code here:
        String nom_complet = cmbClients2.getSelectedItem().toString();
        if (!nom_complet.equals("")) {
            Client client = hotel.listerClientParNomComplet(nom_complet);
            if (jTable2.getRowCount() != 0) {
                editerReservationButton2.setEnabled(Boolean.TRUE);
                for (int i = 0; i < jTable2.getRowCount(); i++) {
                    String nom = String.valueOf(jTable2.getValueAt(i, 1));
                    String prenom = String.valueOf(jTable2.getValueAt(i, 2));
                    if (client.getNom().equals(nom) && client.getPrenoms().equals(prenom)) {
                        jTable2.setRowSelectionInterval(i, i);
                    }
                }
            } else {
                editerReservationButton2.setEnabled(Boolean.FALSE);
            }
        }
    }//GEN-LAST:event_cmbClients2ActionPerformed

    private void jDateChooser1DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jDateChooser1DateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jDateChooser1DateMouseClicked

    private void jDateChooser2DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jDateChooser2DateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jDateChooser2DateMouseClicked

    private void okButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton1ActionPerformed
        // TODO add your handling code here:
        tableauTitres = new String[]{"Code Réservation", "Nom", "Prénom(s)", "Date Arrivée"};
        try {
            if (jDateChooser1Date.getDate() == null) {
                listReservantsArrivants = hotel.listerReservantsArrivants(new Date());
            } else {
                listReservantsArrivants = hotel.listerReservantsArrivants(jDateChooser1Date.getDate());
            }
            cmbClients1.removeAllItems();
            for (Iterator<Reservation> it = listReservantsArrivants.iterator(); it.hasNext();) {
                Reservation reservation = it.next();
                try {
                    Client client = hotel.listerClientParId(reservation.getClient());
                    cmbClients1.addItem(client.getNom() + " " + client.getPrenoms());
                } catch (Exception e) {
                }
            }
            remplirTable(jTable1, listReservantsArrivants);
            defaultArrivants = 1;
        } catch (Exception e) {
        }
    }//GEN-LAST:event_okButton1ActionPerformed

    private void printButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButton1ActionPerformed
        // TODO add your handling code here:
        if (defaultArrivants == 0) {
//		    aRRIVAL_Form_List_Report = new ARRIVAL_Form_List_Report(
//			    scoan.RecupererDateFormatSQL(new Date()).toString());
        } else {
//		    aRRIVAL_Form_List_Report = new ARRIVAL_Form_List_Report(
//			    scoan.RecupererDateFormatSQL(jDateChooser1Date.getDate()).toString());
        }
    }//GEN-LAST:event_printButton1ActionPerformed

    private void okButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okButton2ActionPerformed
        // TODO add your handling code here:
        tableauTitres = new String[]{"Code Réservation", "Nom", "Prénom(s)", "Date Départ"};
        try {
            if (jDateChooser2Date.getDate() == null) {
                listReservantsPartants = hotel.listerReservantsPartants(new Date());
            } else {
                listReservantsPartants = hotel.listerReservantsPartants(jDateChooser2Date.getDate());
            }

            cmbClients2.removeAllItems();
            for (Iterator<Reservation> it = listReservantsPartants.iterator(); it.hasNext();) {
                Reservation reservation = it.next();
                try {
                    Client client = hotel.listerClientParId(reservation.getClient());
                    cmbClients2.addItem(client.getNom() + " " + client.getPrenoms());
                } catch (Exception e) {
                }
            }
            remplirTable(jTable2, listReservantsPartants);
            defaultPartants = 1;
        } catch (Exception e) {
        }
    }//GEN-LAST:event_okButton2ActionPerformed

    private void printButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButton2ActionPerformed
        // TODO add your handling code here:
        if (defaultPartants == 0) {
//		    dEPARTURE_Form_List_Report = new DEPARTURE_Form_List_Report(
//			    scoan.RecupererDateFormatSQL(new Date()).toString());
        } else {
//		    dEPARTURE_Form_List_Report = new DEPARTURE_Form_List_Report(
//			    scoan.RecupererDateFormatSQL(jDateChooser2Date.getDate()).toString());
        }

    }//GEN-LAST:event_printButton2ActionPerformed

	private void editerReservationButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editerReservationButton2ActionPerformed
            // TODO add your handling code here:
            if (jTable2.getSelectedRow() == (-1)) {
                JOptionPane.showMessageDialog(this, "Veuillez choisir le client dans la table ou utiliser le menu déroulant.");
            } else {
                try {
                    Reservation reservation = hotel.listerReservationParId(
                            Integer.parseInt(String.valueOf(jTable2.getValueAt(jTable2.getSelectedRow(), 0))));
                    reservationView = new ReservationView(jPanelArriveesDeparts, cardLayoutArriveesDeparts, arriveesDepartsString, reservation, login);
                    jPanelArriveesDeparts.add(reservationView, reservationViewString);
                    cardLayoutArriveesDeparts.show(jPanelArriveesDeparts, reservationViewString);
                } catch (NumberFormatException numberFormatException) {
                } catch (Exception e) {
                }
            }
	}//GEN-LAST:event_editerReservationButton2ActionPerformed

	private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
            // TODO add your handling code here:
            editerReservationButton2.setEnabled(Boolean.TRUE);
	}//GEN-LAST:event_jTable2MouseClicked

	private void jTable2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseReleased
            // TODO add your handling code here:
            if (evt.isPopupTrigger()) {
                jPopupMenu.removeAll();
                jMenuItemEditerReservation.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        editerReservationButton2ActionPerformed(ae);
                    }
                });

                jPopupMenu.add(jMenuItemEditerReservation);

                add(jPopupMenu);

                jPopupMenu.show(jTable2, evt.getX(), evt.getY());
            }
	}//GEN-LAST:event_jTable2MouseReleased

	private void cmbClients1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbClients1ActionPerformed
            // TODO add your handling code here:
            String nom_complet = cmbClients1.getSelectedItem().toString();
            if (!nom_complet.equals("")) {
                Client client = hotel.listerClientParNomComplet(nom_complet);
                if (jTable1.getRowCount() != 0) {
                    editerReservationButton1.setEnabled(Boolean.TRUE);
                    for (int i = 0; i < jTable1.getRowCount(); i++) {
                        String nom = String.valueOf(jTable1.getValueAt(i, 1));
                        String prenom = String.valueOf(jTable1.getValueAt(i, 2));
                        if (client.getNom().equals(nom) && client.getPrenoms().equals(prenom)) {
                            jTable1.setRowSelectionInterval(i, i);
                        }
                    }
                } else {
                    editerReservationButton1.setEnabled(Boolean.FALSE);
                }
            }
	}//GEN-LAST:event_cmbClients1ActionPerformed

    private void editerReservationButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editerReservationButton1ActionPerformed
        // TODO add your handling code here:
        if (jTable1.getSelectedRow() == (-1)) {
            JOptionPane.showMessageDialog(this, "Veuillez choisir le client dans la table ou utiliser le menu déroulant.");
        } else {
            try {
                Reservation reservation = hotel.listerReservationParId(
                        Integer.parseInt(String.valueOf(jTable1.getValueAt(jTable1.getSelectedRow(), 0))));
                reservationView = new ReservationView(jPanelArriveesDeparts, cardLayoutArriveesDeparts, arriveesDepartsString, reservation, login);
                jPanelArriveesDeparts.add(reservationView, reservationViewString);
                cardLayoutArriveesDeparts.show(jPanelArriveesDeparts, reservationViewString);
            } catch (NumberFormatException numberFormatException) {
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_editerReservationButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        editerReservationButton1.setEnabled(Boolean.TRUE);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        // TODO add your handling code here:
        if (evt.isPopupTrigger()) {
            jPopupMenu.removeAll();
            jMenuItemEditerReservation.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    editerReservationButton1ActionPerformed(ae);
                }
            });

            jPopupMenu.add(jMenuItemEditerReservation);

            add(jPopupMenu);

            jPopupMenu.show(jTable1, evt.getX(), evt.getY());
        }
    }//GEN-LAST:event_jTable1MouseReleased
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cmbClients1;
    private javax.swing.JComboBox cmbClients2;
    private javax.swing.JButton editerReservationButton1;
    private javax.swing.JButton editerReservationButton2;
    private com.toedter.calendar.JDateChooser jDateChooser1Date;
    private com.toedter.calendar.JDateChooser jDateChooser2Date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JButton okButton1;
    private javax.swing.JButton okButton2;
    private javax.swing.JButton printButton1;
    private javax.swing.JButton printButton2;
    // End of variables declaration//GEN-END:variables
}
