/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ReservationChambre.java
 *
 * Created on Aug 15, 2012, 4:35:56 AM
 */
package hotelpro.gui;

import hotelpro.entities.Bloc;
import hotelpro.entities.CaracteristiqueChambre;
import hotelpro.entities.Chambre;
import hotelpro.entities.Client;
import hotelpro.entities.Etage;
import hotelpro.entities.Lit;
import hotelpro.entities.SituationChambre;
import hotelpro.entities.TypeChambre;
import hotelpro.gui.views.ReservationView;
import hotelpro.utils.Hotel;
import java.awt.CardLayout;
import java.awt.HeadlessException;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Serge
 */
public class ReservationChambre extends javax.swing.JPanel {

    Hotel hotel = new Hotel();
    List<Lit> listLits = new LinkedList<>();
    List<Etage> listEtages = new LinkedList<>();
    List<Bloc> listBlocs = new LinkedList<>();
    String tableauTitres[] = new String[]{"Lit", "Catégorie Lit"};
    Object tableauLitsParChambre[][];
    ReservationView reservationView;
    CardLayout cardLayoutChambresReserv;
    JPanel jPanelChambresReservations;
    String reservationViewString;
    ReservationChambre reservationChambre;
    String reservationChambreString;
    Client client;
    List<Chambre> listChambres = new LinkedList<>();
    String login = "";

    /**
     * Creates new form ReservationChambre
     */
    public ReservationChambre() {
        initComponents();

//        Hotel.termReservation();

        remplirCmbBlocs();

        listLits = hotel.listerLits();

        jLabel5.setText("Choisissez parmi les " + hotel.listerNbreBlocs() + " blocs:");
    }

//    public ReservationChambre(JPanel jPanel3, CardLayout cardLayout, String clientViewString) {
//        initComponents();
//
//        this.jPanelChambresReservations = jPanel3;
//        this.cardLayoutChambresReserv = cardLayout;
//
//        jTable1.setEnabled(Boolean.FALSE);
//
//        forwardButton.setVisible(Boolean.FALSE);
//
//        hotel.termReservation();
//
//        remplirCmbBlocs();
//
//        listLits = hotel.listerLits();
//
//        jLabel5.setText("Choisissez parmi les " + String.valueOf(hotel.listerNbreBlocs()) + " blocs:");
//    }
    public ReservationChambre(JPanel jPanelChambresReservations, CardLayout cardLayoutChambresReserv,
            ReservationChambre reservationChambre, String reservationChambreString,
            ReservationView reservationView, String reservationViewString, String login) {

        initComponents();

        this.jPanelChambresReservations = jPanelChambresReservations;
        this.cardLayoutChambresReserv = cardLayoutChambresReserv;
        this.reservationChambre = reservationChambre;
        this.reservationChambreString = reservationChambreString;
        this.reservationView = reservationView;
        this.reservationViewString = reservationViewString;
        this.login = login;

//        Hotel.termReservation();

        remplirCmbBlocs();

        listLits = hotel.listerLits();

        jLabel5.setText("Choisissez parmi les " + String.valueOf(hotel.listerNbreBlocs()) + " blocs:");

        cmbBlocs.setToolTipText("Cliquez et choisissez le bloc sur lequel se trouve la chambre.");
        cmbEtage.setToolTipText("Cliquez et choisissez l'étage sur lequel se trouve la chambre.");
        cmbChambre.setToolTipText("Cliquez et choisissez une chambre.");
        forwardButton.setToolTipText("Cliquez ici pour enregistrer une nouvelle réservation");
    }

    private void remplirTable(List<Lit> list) {
        tableauLitsParChambre = new Object[list.size()][2];
        int i = 0;
        for (Lit lit : list) {
            tableauLitsParChambre[i][0] = lit.getDesignation();
            tableauLitsParChambre[i][1] = hotel.listerCategorieLitById(lit.getCategorieLit()).getDesignation();
            i++;
        }
        jTable1.setModel(new DefaultTableModel(tableauLitsParChambre, tableauTitres));
    }

    private void remplirCmbBlocs() {
        cmbBlocs.removeAllItems();
        cmbBlocs.addItem("-----Choisissez le bloc ici-----");
        try {
            listBlocs = hotel.listerBlocsOrderByDesignationASC();
            for (Bloc bloc : listBlocs) {
                if (bloc.getDisponibilite() == Boolean.TRUE) {
                    cmbBlocs.addItem(bloc.getId() + "/          " + bloc.getDesignation());
                } else {
                    cmbBlocs.addItem(bloc.getId() + "/          " + bloc.getDesignation() + " (Non disponible)");
                }
            }
        } catch (Exception e) {
        }
    }

    private void remplirCmbEtage(Bloc bloc) {
        try {
            if (cmbBlocs.getSelectedIndex() != 0) {
                listEtages = hotel.listerEtagesByBloc(bloc);
                cmbEtage.removeAllItems();
                cmbEtage.addItem("-----Choisissez l'étage ici-----");
                for (Etage etage : listEtages) {
                    if (etage.getDisponibilite() == true) {
                        cmbEtage.addItem(etage.getId() + "/          " + etage.getDesignation());
                    } else {
                        cmbEtage.addItem(etage.getId() + "/          " + etage.getDesignation() + " (Non disponible)");
                    }
                }
                cmbEtage.setSelectedIndex(0);
            } else {
            }
            nbreEtageLabel.setText("(" + String.valueOf(hotel.listerNbreEtagesParBloc(bloc)) + " étage(s) sur ce bloc)");
            nbreChambresLabel.setText(" ");
            nbreChambreDispoLabel.setText(" ");
            nbreChambreFullLabel.setText(" ");
            nbreBedsAvailable.setText(" ");
        } catch (Exception e) {
        }
    }

    private void remplirCmbChambre(Bloc bloc) {
        try {
            if (cmbEtage.getSelectedIndex() == 0) {
                List<Chambre> listChambresByBloc = hotel.listerChambresByBloc(bloc);
                cmbChambre.removeAllItems();
                cmbChambre.addItem("-----Choisissez la chambre ici-----");
                for (Chambre chambre : listChambresByBloc) {
                    if (chambre.getDisponibilite() == Boolean.TRUE) {
                        cmbChambre.addItem(chambre.getId() + "/          " + chambre.getDesignation() + " (" + chambre.getStatut() + ")");
                    }
                }
            }
        } catch (Exception e) {
        }
    }

    private void remplirCmbChambre(Etage etage) {
        try {
            if (cmbEtage.getSelectedIndex() != 0) {
                listChambres = hotel.listerChambresByEtage(etage);
                cmbChambre.removeAllItems();
                cmbChambre.addItem("-----Choisissez la chambre ici-----");
                for (Chambre chambre : listChambres) {
                    if (chambre.getDisponibilite() == Boolean.TRUE) {
                        cmbChambre.addItem(chambre.getId() + "/          " + chambre.getDesignation() + " (" + chambre.getStatut() + ")");
                    }
                }
                long l1 = hotel.listerNbreChambresParEtage(etage);
                try {
                    nbreChambresLabel.setText("(" + String.valueOf(l1) + " chambre(s) sur cet étage)");
                } catch (Exception e) {
                }
                long l2 = hotel.listerNbreChambresDispoParEtage(etage);
                try {
                    nbreChambreDispoLabel.setText("(" + String.valueOf(l2) + " chambre(s) disponible(s) sur cet étage)");
                } catch (Exception e) {
                }
                try {
                    nbreChambreFullLabel.setText("(" + String.valueOf(Integer.parseInt(
                            String.valueOf(l1)) - Integer.parseInt(String.valueOf(l2))) + " chambre(s) occupée(s) sur cet étage)");
                } catch (NumberFormatException numberFormatException) {
                }
                nbreBedsAvailable.setText(" ");
            } else {
                cmbChambre.removeAllItems();
            }
        } catch (Exception e) {
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        forwardButton = new javax.swing.JButton();
        cmbChambre = new javax.swing.JComboBox();
        cmbEtage = new javax.swing.JComboBox();
        cmbBlocs = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        nbreChambreDispoLabel = new javax.swing.JLabel();
        nbreChambresLabel = new javax.swing.JLabel();
        nbreEtageLabel = new javax.swing.JLabel();
        nbreChambreFullLabel = new javax.swing.JLabel();
        nbreBedsAvailable = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        categorieChambreField = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        typeChambreField = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        caractChambreField = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        situationChambreField = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        coutField = new javax.swing.JLabel();
        statutChambreLabel = new javax.swing.JLabel();

        setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Situation actuelle des infrastructures hôtellières");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 859, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                .addContainerGap())
        );

        add(jPanel1, java.awt.BorderLayout.PAGE_START);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Lit", "Catégorie Lit"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setText("Choisisez la chambre:");

        forwardButton.setText("Réserver une chambre");
        forwardButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forwardButtonActionPerformed(evt);
            }
        });

        cmbChambre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbChambreMouseClicked(evt);
            }
        });
        cmbChambre.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbChambreItemStateChanged(evt);
            }
        });
        cmbChambre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbChambreActionPerformed(evt);
            }
        });

        cmbEtage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbEtageActionPerformed(evt);
            }
        });

        cmbBlocs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbBlocsActionPerformed(evt);
            }
        });

        jLabel3.setText("Choisissez l'étage:");

        jLabel5.setText("Choisissez le bloc:");

        nbreChambreDispoLabel.setText(" ");
        nbreChambreDispoLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        nbreChambresLabel.setText(" ");
        nbreChambresLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        nbreEtageLabel.setText(" ");
        nbreEtageLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        nbreChambreFullLabel.setText(" ");
        nbreChambreFullLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        nbreBedsAvailable.setText(" ");
        nbreBedsAvailable.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setText("Lits se trouvant dans la chambre sélectionnée:");

        jLabel4.setText("Catégorie Chambre:");

        categorieChambreField.setText(" ");

        jLabel7.setText("Type Chambre:");

        typeChambreField.setText(" ");

        jLabel8.setText("Caractéristique Chambre:");

        caractChambreField.setText(" ");

        jLabel9.setText("Situation Chambre:");

        situationChambreField.setText(" ");

        jLabel10.setText("Coût:");

        coutField.setText(" ");

        statutChambreLabel.setForeground(new java.awt.Color(255, 0, 0));
        statutChambreLabel.setText(" ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(291, 291, 291)
                        .addComponent(forwardButton))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(cmbBlocs, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cmbEtage, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cmbChambre, javax.swing.GroupLayout.Alignment.LEADING, 0, 537, Short.MAX_VALUE)
                                    .addComponent(categorieChambreField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(typeChambreField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(caractChambreField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(situationChambreField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(coutField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(statutChambreLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(nbreBedsAvailable, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nbreChambreFullLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nbreChambreDispoLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nbreChambresLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nbreEtageLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbBlocs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(nbreEtageLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbEtage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(nbreChambresLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbChambre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nbreChambreDispoLabel))
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nbreChambreFullLabel)
                    .addComponent(statutChambreLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nbreBedsAvailable)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(categorieChambreField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(typeChambreField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(caractChambreField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(situationChambreField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(coutField))
                .addGap(11, 11, 11)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(forwardButton)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        add(jPanel2, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void forwardButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forwardButtonActionPerformed
        // TODO add your handling code here:
        Hotel.refreshEntitiesBloc();
        Hotel.refreshEntitiesEtage();
        Hotel.refreshEntitiesChambre();
        try {
            if (cmbChambre.getSelectedIndex() == 0) {
                statutChambreLabel.setText("Veuillez choisir une chambre à partir du menu déroulant.");
            } else {
                String selection = cmbChambre.getSelectedItem().toString();
                Chambre chambre;
                int idChbre = 0;
                try {
                    idChbre = (int) Integer.parseInt(String.valueOf(
                            new StringTokenizer(selection, "/").nextToken()));
                } catch (NumberFormatException numberFormatException) {
                }

                chambre = hotel.listerChambreParId(idChbre);

                if ("DISPONIBLE".equals(chambre.getStatut())) {
                    reservationView = new ReservationView(jPanelChambresReservations, cardLayoutChambresReserv, this, reservationChambreString, chambre, login);
                    jPanelChambresReservations.add(reservationView, reservationViewString);
                    cardLayoutChambresReserv.show(jPanelChambresReservations, reservationViewString);
                } else {
                    statutChambreLabel.setText("Cette chambre n'est pas disponible pour le moment. "
                            + "Veuillez en choisir une autre.");
                }
            }
        } catch (NullPointerException exception) {
            try {
                JOptionPane.showMessageDialog(null, "Veuillez choisir une chambre d'abord.");
            } catch (HeadlessException headlessException) {
            }
            remplirCmbBlocs();
            cmbChambre.showPopup();
        }
    }//GEN-LAST:event_forwardButtonActionPerformed

    private void cmbChambreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbChambreActionPerformed
        // TODO add your handling code here:  
        verificationStatutChambre();
        try {
            String selection = cmbChambre.getSelectedItem().toString();
            if (!selection.equals("-----Choisissez la chambre ici-----") || !selection.equals("")) {
                Chambre chambre = hotel.listerChambreParId(
                        Integer.parseInt(
                        String.valueOf(
                        new StringTokenizer(selection, "/").nextToken())));
                List<Lit> listLitsByChambre = hotel.listerLitsByChambre(listLits, chambre);
                List<Lit> listLitsDispoByListLits = hotel.listerLitsDispoByListLits(listLitsByChambre);
                remplirTable(listLitsDispoByListLits);
                nbreBedsAvailable.setText("(" + String.valueOf(
                        hotel.listerNbreLitsParChambre(chambre)) + " lit(s) dans cette chambre)");

                try {
                    categorieChambreField.setText(hotel.listerCategorieChambreParChambre(chambre).getLibelle());
                    TypeChambre typeChambre = hotel.listerTypeChambreParChambre(chambre);
                    typeChambreField.setText(typeChambre.getLibelle());
                    CaracteristiqueChambre caracteristiqueChambre = hotel.listerCaracteristiqueChambreParChambre(chambre);
                    caractChambreField.setText(caracteristiqueChambre.getLibelle());
                    SituationChambre situationChambre = hotel.listerSituationChambreParChambre(chambre);
                    situationChambreField.setText(situationChambre.getLibelle());
                    float cout = 0;
                    try {
                        cout += (float) Float.parseFloat(String.valueOf(typeChambre.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }
                    try {
                        cout += (float) Float.parseFloat(String.valueOf(caracteristiqueChambre.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }
                    try {
                        cout += (float) Float.parseFloat(String.valueOf(situationChambre.getCout()));
                    } catch (NumberFormatException numberFormatException) {
                    }

                    coutField.setText(String.valueOf(cout));
                } catch (Exception e) {
                }
            } else {
                List<Lit> list = new LinkedList<>();
                remplirTable(list);
                categorieChambreField.setText(" ");
                typeChambreField.setText(" ");
                caractChambreField.setText(" ");
                situationChambreField.setText(" ");
                coutField.setText(" ");
                nbreBedsAvailable.setText(" ");
            }
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception ex) {
            List<Lit> list = new LinkedList<>();
            remplirTable(list);
            categorieChambreField.setText(" ");
            typeChambreField.setText(" ");
            caractChambreField.setText(" ");
            situationChambreField.setText(" ");
            coutField.setText(" ");
            nbreBedsAvailable.setText(" ");
        }
    }//GEN-LAST:event_cmbChambreActionPerformed

    private void cmbChambreItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbChambreItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbChambreItemStateChanged

    private void cmbChambreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbChambreMouseClicked
        // TODO add your handling code here: 
    }//GEN-LAST:event_cmbChambreMouseClicked

	private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
            // TODO add your handling code here:
            String recherche = hotel.entreeKeyTyped(evt);
            if (recherche.equals("Enter") || recherche.equals("Entrée")) {
                forwardButtonActionPerformed(null);
            }
	}//GEN-LAST:event_jTable1KeyTyped

	private void cmbBlocsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbBlocsActionPerformed
            // TODO add your handling code here:
            Bloc bloc = new Bloc();
            try {
                if (cmbBlocs.getSelectedIndex() != 0) {
                    bloc = hotel.listerBlocParId(
                            (int) Integer.parseInt(
                            String.valueOf(
                            new StringTokenizer(cmbBlocs.getSelectedItem().toString(), "/").nextToken())));
                } else {
                    cmbEtage.removeAllItems();
                    cmbChambre.removeAllItems();
                    remplirTable(new LinkedList<Lit>());
                }
            } catch (NumberFormatException numberFormatException) {
            } catch (Exception exception) {
            }

            remplirCmbEtage(bloc);
            remplirCmbChambre(bloc);

	}//GEN-LAST:event_cmbBlocsActionPerformed

    @SuppressWarnings("empty-statement")
	private void cmbEtageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbEtageActionPerformed
        // TODO add your handling code here:
        try {
            if (cmbEtage.getSelectedIndex() != 0) {
                String selection = cmbEtage.getSelectedItem().toString();
                Etage etage = hotel.listerEtageParId(
                        (int) Integer.parseInt(
                        String.valueOf(
                        new StringTokenizer(selection, "/").nextToken())));
                remplirCmbChambre(etage);
            } else if (cmbEtage.getSelectedIndex() == 0) {
                if (cmbBlocs.getSelectedIndex() != 0) {
                    try {
                        Bloc bloc = hotel.listerBlocParId(
                                (int) Integer.parseInt(
                                String.valueOf(
                                new StringTokenizer(cmbBlocs.getSelectedItem().toString(), "/").nextToken())));
                        remplirCmbChambre(bloc);
                    } catch (NumberFormatException numberFormatException) {
                    }
                }
            } else {
                cmbChambre.removeAllItems();
                remplirTable(new LinkedList<Lit>());
            }

        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
	}//GEN-LAST:event_cmbEtageActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel caractChambreField;
    private javax.swing.JLabel categorieChambreField;
    private javax.swing.JComboBox cmbBlocs;
    private javax.swing.JComboBox cmbChambre;
    private javax.swing.JComboBox cmbEtage;
    private javax.swing.JLabel coutField;
    private javax.swing.JButton forwardButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel nbreBedsAvailable;
    private javax.swing.JLabel nbreChambreDispoLabel;
    private javax.swing.JLabel nbreChambreFullLabel;
    private javax.swing.JLabel nbreChambresLabel;
    private javax.swing.JLabel nbreEtageLabel;
    private javax.swing.JLabel situationChambreField;
    private javax.swing.JLabel statutChambreLabel;
    private javax.swing.JLabel typeChambreField;
    // End of variables declaration//GEN-END:variables

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setContentPane(new ReservationChambre());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private void verificationStatutChambre() {
        Hotel.refreshEntitiesChambre();
        try {
            if (cmbChambre.getSelectedIndex() == 0) {
                statutChambreLabel.setText("Veuillez choisir une chambre à partir du menu déroulant.");
            } else {
                String selection = cmbChambre.getSelectedItem().toString();
                Chambre chambre;
                int idChbre = 0;
                try {
                    idChbre = (int) Integer.parseInt(String.valueOf(
                            new StringTokenizer(selection, "/").nextToken()));
                } catch (NumberFormatException numberFormatException) {
                }

                chambre = hotel.listerChambreParId(idChbre);

                if ("DISPONIBLE".equals(chambre.getStatut())) {
                    statutChambreLabel.setText("Cette chambre est disponible.");
                } else {
                    statutChambreLabel.setText("Cette chambre n'est pas disponible pour le moment. "
                            + "Veuillez en choisir une autre.");
                }
            }
        } catch (Exception exception) {
            statutChambreLabel.setText("");
        }
    }
}
