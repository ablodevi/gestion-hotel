/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.gui.views;

import hotelpro.entities.Chambre;
import hotelpro.entities.Client;
import hotelpro.entities.Log;
import hotelpro.entities.Reservation;
import hotelpro.gui.ReservationChambre;
import hotelpro.utils.Hotel;
import hotelpro.utils.Paths;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.beans.Beans;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.RollbackException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Serge
 */
public class ReservationView extends JPanel {

    Hotel hotel = new Hotel();
    Paths paths = new Paths();
    ReservationChambre reservationChambre;
    Chambre chambre;
    String login;
    Reservation res;
    JPanel jPanel;
    CardLayout cardLayout;
    String fenetreString;
    hotelpro.entities.Reservation reservation;
    int newReservation = 0;
    String fichier_log_du_jour = paths.recupererLogsPath() + String.valueOf(new java.sql.Date(new java.util.Date().getTime())) + ".txt";

    public ReservationView() {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        setBorder(javax.swing.BorderFactory.createTitledBorder("Enregistrer / Editer une réservation"));

        remplirCmbClients();
    }

    public ReservationView(String login) {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        setBorder(javax.swing.BorderFactory.createTitledBorder("Enregistrer / Editer une réservation"));

        this.login = login;

        remplirCmbClients();

        masterScrollPane.setVisible(Boolean.FALSE);

        chambreLabel.setVisible(Boolean.FALSE);
        chambreField.setVisible(Boolean.FALSE);

        backButton.setVisible(Boolean.FALSE);
    }

    public ReservationView(JPanel jPanelArriveesDeparts, CardLayout cardLayoutArriveesDeparts,
            String arriveesDepartsString, Reservation res, String login) {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        setBorder(javax.swing.BorderFactory.createTitledBorder("Editer une réservation"));

        this.jPanel = jPanelArriveesDeparts;
        this.cardLayout = cardLayoutArriveesDeparts;
//        this.arriveesDepartsString = arriveesDepartsString;
        this.fenetreString = arriveesDepartsString;
        this.res = res;
        this.login = login;

        masterScrollPane.setVisible(Boolean.FALSE);

        chambreLabel.setVisible(Boolean.FALSE);
        chambreField.setVisible(Boolean.FALSE);

        chambre = hotel.listerChambreParId(res.getChambre());
        designationChambre.setText(chambre.getDesignation());

        clientLabel.setVisible(Boolean.FALSE);
        clientField.setVisible(Boolean.FALSE);
        remplirCmbClients();
        cmbClients.setEnabled(Boolean.FALSE);
        Client client = hotel.listerClientParId(res.getClient());
        cmbClients.setSelectedItem(client.getNom() + " " + client.getPrenoms());

        for (int i = 0; i < masterTable.getRowCount(); i++) {
            int code = 0;
            try {
                code = (int) Integer.parseInt(String.valueOf(masterTable.getValueAt(i, 0)));
            } catch (NumberFormatException numberFormatException) {
            }

            if (code == (int) res.getId()) {
                masterTable.setRowSelectionInterval(i, i);
                try {
                    cmbEtatReservation.setSelectedItem(res.getEtatReservation());
                } catch (Exception e) {
                    cmbEtatReservation.setSelectedIndex(2);
                }
                dateReservationField.setEditable(Boolean.FALSE);
                dateArriveeField.setEditable(Boolean.FALSE);
                dateDepartField.setEditable(Boolean.FALSE);
                etatReservationField.setEditable(Boolean.FALSE);
            }
        }

        newButton.setVisible(Boolean.FALSE);
        deleteButton.setVisible(Boolean.FALSE);
        refreshButton.setVisible(Boolean.FALSE);
    }

    public ReservationView(JPanel jPanelChambresReservations, CardLayout cardLayoutChambresReserv,
            ReservationChambre reservationChambre, String reservationChambreString, Chambre chambre, String login) {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        setBorder(javax.swing.BorderFactory.createTitledBorder("Enregistrer une réservation"));

        this.jPanel = jPanelChambresReservations;
        this.cardLayout = cardLayoutChambresReserv;
        this.reservationChambre = reservationChambre;
//        this.reservationChambreString = reservationChambreString;
        this.fenetreString = reservationChambreString;
        this.chambre = chambre;
        this.login = login;

        jPanel.add(reservationChambre, fenetreString);

        masterScrollPane.setVisible(Boolean.FALSE);

        chambreLabel.setVisible(Boolean.FALSE);
        chambreField.setVisible(Boolean.FALSE);
        designationChambre.setText(chambre.getDesignation());

        clientLabel.setVisible(Boolean.FALSE);
        clientField.setVisible(Boolean.FALSE);
        remplirCmbClients();

        newButton.setVisible(Boolean.FALSE);
        deleteButton.setVisible(Boolean.FALSE);
        refreshButton.setVisible(Boolean.FALSE);

        newButtonActionPerformed(null);

        chambreField.setText(String.valueOf(chambre.getId()));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT r FROM Reservation r");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        masterScrollPane = new javax.swing.JScrollPane();
        masterTable = new javax.swing.JTable();
        chambreLabel = new javax.swing.JLabel();
        clientLabel = new javax.swing.JLabel();
        dateReservationLabel = new javax.swing.JLabel();
        dateArriveeLabel = new javax.swing.JLabel();
        dateDepartLabel = new javax.swing.JLabel();
        etatReservationLabel = new javax.swing.JLabel();
        chambreField = new javax.swing.JTextField();
        clientField = new javax.swing.JTextField();
        dateReservationField = new javax.swing.JTextField();
        dateArriveeField = new javax.swing.JTextField();
        dateDepartField = new javax.swing.JTextField();
        etatReservationField = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        newButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cmbClients = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        cmbEtatReservation = new javax.swing.JComboBox();
        designationChambre = new javax.swing.JLabel();
        jDateChooserArrivee = new com.toedter.calendar.JDateChooser();
        jDateChooserDepart = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cmbHeureArrivee = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        cmbMinuteArrivee = new javax.swing.JComboBox();
        cmbHeureDepart = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        cmbMinuteDepart = new javax.swing.JComboBox();
        refreshCmbClients = new javax.swing.JButton();

        FormListener formListener = new FormListener();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder("Enregistrer / Editer une réservation"));

        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, list, masterTable);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${id}"));
        columnBinding.setColumnName("Code");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${etatReservation}"));
        columnBinding.setColumnName("Etat Réservation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        masterScrollPane.setViewportView(masterTable);

        chambreLabel.setText("Chambre:");

        clientLabel.setText("Client:");

        dateReservationLabel.setText("Date Reservation:");

        dateArriveeLabel.setText("Date - Heure Arrivée:");

        dateDepartLabel.setText("Date Depart:");

        etatReservationLabel.setText("Etat Réservation:");

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.chambre}"), chambreField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), chambreField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.client}"), clientField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), clientField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.dateReservation}"), dateReservationField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), dateReservationField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.dateArrivee}"), dateArriveeField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), dateArriveeField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.dateDepart}"), dateDepartField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), dateDepartField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.etatReservation}"), etatReservationField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), etatReservationField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        saveButton.setText("Save");
        saveButton.addActionListener(formListener);

        refreshButton.setText("Refresh");
        refreshButton.addActionListener(formListener);

        newButton.setText("New");
        newButton.addActionListener(formListener);

        deleteButton.setText("Delete");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), deleteButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        deleteButton.addActionListener(formListener);

        backButton.setText("Back");
        backButton.addActionListener(formListener);

        jLabel1.setText("Chambre:");

        jLabel2.setText("Client:");

        cmbClients.addActionListener(formListener);

        jLabel3.setText("Etat Réservation:");

        cmbEtatReservation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "----- Choisissez le statut de la réservation -----", "RESERVE", "CONFIRME", "ANNULE" }));
        cmbEtatReservation.addActionListener(formListener);

        designationChambre.setText(" ");

        jLabel4.setText("Modifier l'arrivée:");

        jLabel5.setText("Modifier le départ:");

        cmbHeureArrivee.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Choisissez l'heure", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));
        cmbHeureArrivee.addActionListener(formListener);

        jLabel6.setText(":");

        cmbMinuteArrivee.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Choisissez la minute", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44;45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        cmbHeureDepart.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Choisissez l'heure", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));

        jLabel7.setText(":");

        cmbMinuteDepart.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Choisissez la minute", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44;45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));

        refreshCmbClients.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tinyRefresh.png"))); // NOI18N
        refreshCmbClients.addActionListener(formListener);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(masterScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(chambreLabel)
                                .addComponent(clientLabel)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2))
                            .addGap(63, 63, 63)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(chambreField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(designationChambre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(clientField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(cmbClients, 0, 420, Short.MAX_VALUE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(refreshCmbClients, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(backButton)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(newButton)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(deleteButton)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(refreshButton)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(saveButton))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dateReservationLabel)
                                .addComponent(dateArriveeLabel)
                                .addComponent(dateDepartLabel)
                                .addComponent(etatReservationLabel)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(etatReservationField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dateDepartField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dateReservationField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dateArriveeField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jDateChooserArrivee, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cmbHeureArrivee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cmbMinuteArrivee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jDateChooserDepart, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cmbHeureDepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cmbMinuteDepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(cmbEtatReservation, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(105, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {deleteButton, newButton, refreshButton, saveButton});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(masterScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chambreLabel)
                    .addComponent(chambreField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(designationChambre))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clientLabel)
                    .addComponent(clientField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(refreshCmbClients, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(cmbClients, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateReservationLabel)
                    .addComponent(dateReservationField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateArriveeLabel)
                    .addComponent(dateArriveeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jDateChooserArrivee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cmbHeureArrivee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)
                        .addComponent(cmbMinuteArrivee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateDepartLabel)
                    .addComponent(dateDepartField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jDateChooserDepart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cmbHeureDepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)
                        .addComponent(cmbMinuteDepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etatReservationLabel)
                    .addComponent(etatReservationField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbEtatReservation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(saveButton)
                    .addComponent(refreshButton)
                    .addComponent(deleteButton)
                    .addComponent(newButton)
                    .addComponent(backButton))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        bindingGroup.bind();
    }

    // Code for dispatching events from components to event handlers.

    private class FormListener implements java.awt.event.ActionListener {
        FormListener() {}
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (evt.getSource() == saveButton) {
                ReservationView.this.saveButtonActionPerformed(evt);
            }
            else if (evt.getSource() == refreshButton) {
                ReservationView.this.refreshButtonActionPerformed(evt);
            }
            else if (evt.getSource() == newButton) {
                ReservationView.this.newButtonActionPerformed(evt);
            }
            else if (evt.getSource() == deleteButton) {
                ReservationView.this.deleteButtonActionPerformed(evt);
            }
            else if (evt.getSource() == backButton) {
                ReservationView.this.backButtonActionPerformed(evt);
            }
            else if (evt.getSource() == cmbClients) {
                ReservationView.this.cmbClientsActionPerformed(evt);
            }
            else if (evt.getSource() == cmbEtatReservation) {
                ReservationView.this.cmbEtatReservationActionPerformed(evt);
            }
            else if (evt.getSource() == cmbHeureArrivee) {
                ReservationView.this.cmbHeureArriveeActionPerformed(evt);
            }
            else if (evt.getSource() == refreshCmbClients) {
                ReservationView.this.refreshCmbClientsActionPerformed(evt);
            }
        }
    }// </editor-fold>//GEN-END:initComponents

    @SuppressWarnings("unchecked")
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        entityManager.getTransaction().rollback();
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);

        designationChambre.setText("");
        cmbClients.setSelectedItem(null);
        jDateChooserArrivee.setDate(null);
        cmbHeureArrivee.setSelectedIndex(0);
        cmbMinuteArrivee.setSelectedIndex(0);
        jDateChooserDepart.setDate(null);
        cmbHeureDepart.setSelectedIndex(0);
        cmbMinuteDepart.setSelectedIndex(0);
        cmbEtatReservation.setSelectedIndex(0);
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        int[] selected = masterTable.getSelectedRows();
        List<hotelpro.entities.Reservation> toRemove = new ArrayList<>(selected.length);
        for (int idx = 0; idx < selected.length; idx++) {
            hotelpro.entities.Reservation r = list.get(masterTable.convertRowIndexToModel(selected[idx]));
            toRemove.add(r);
            entityManager.remove(r);
        }
        list.removeAll(toRemove);
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void newButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newButtonActionPerformed
        newReservation = 1;
        reservation = new hotelpro.entities.Reservation();
        entityManager.persist(reservation);
        list.add(reservation);
        int row = list.size() - 1;
        masterTable.setRowSelectionInterval(row, row);
        masterTable.scrollRectToVisible(masterTable.getCellRect(row, 0, true));

        dateReservationField.setEditable(Boolean.FALSE);
        dateArriveeField.setEditable(Boolean.FALSE);
        dateDepartField.setEditable(Boolean.FALSE);
        etatReservationField.setEditable(Boolean.FALSE);
    }//GEN-LAST:event_newButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        Hotel.refreshEntitiesChambre();
        hotelpro.entities.Log log = new Log();
        String info = "";
        chambre = hotel.listerChambreParId(chambre.getId());
        if (!"DISPONIBLE".equals(chambre.getStatut())) {
            try {
                JOptionPane.showMessageDialog(null, "Désolé! Cette chambre n'est plus disponible! Veuillez en choisir une autre.");
            } catch (Exception e) {
            }
        } else if (cmbClients.getSelectedIndex() == 0) {
            try {
                JOptionPane.showMessageDialog(null, "Sélectionnez le client dans le menu déroulant prévu à cet effet.");
            } catch (HeadlessException headlessException) {
            }
        } else if (jDateChooserArrivee.getDate() == null || cmbHeureArrivee.getSelectedIndex() == 0
                || cmbMinuteArrivee.getSelectedIndex() == 0 || jDateChooserDepart.getDate() == null
                || cmbHeureDepart.getSelectedIndex() == 0 || cmbMinuteDepart.getSelectedIndex() == 0) {
            try {
                JOptionPane.showMessageDialog(null, "Choisissez les dates et heure d'arrivée et de départ.");
            } catch (HeadlessException headlessException) {
            }
        } else if (cmbEtatReservation.getSelectedIndex() == 0) {
            try {
                JOptionPane.showMessageDialog(null, "Choisissez le statut de la réservation.");
            } catch (HeadlessException headlessException) {
            }
        } else {
            try {
                cmbClientsActionPerformed(null);
                info += "Client: " + cmbClients.getSelectedItem().toString() + " \n ";

                if (dateReservationField.getText().equals("")) {
                    dateReservationField.setText(Hotel.returnNow());
                }
                info += "Date réservation: " + dateReservationField.getText() + " \n ";

                dateArriveeField.setText(new java.sql.Date(jDateChooserArrivee.getDate().getTime()).toString() + " "
                        + cmbHeureArrivee.getSelectedItem().toString() + ":"
                        + cmbMinuteArrivee.getSelectedItem().toString() + ":00");
                
                info += "Date arrivée:  " + dateArriveeField.getText() + " \n ";

                dateDepartField.setText(new java.sql.Date(jDateChooserDepart.getDate().getTime()).toString() + " "
                        + cmbHeureDepart.getSelectedItem().toString() + ":"
                        + cmbMinuteDepart.getSelectedItem().toString() + ":00");
                info += "Date départ:  " + dateDepartField.getText() + " \n ";

                if (!"DEPASSE".equals(etatReservationField.getText())) {
                    cmbEtatReservationActionPerformed(null);
                }
                
                info += "Statut de la réservation:  " + etatReservationField.getText() + " \n ";

                if (newReservation == 1) {
                    if (reservation.getId() == null) {
                        try {
                            reservation.setId((int) Integer.parseInt(String.valueOf(hotel.listerMaxIdReservation() + 1)));
                        } catch (NumberFormatException numberFormatException) {
                        }
                    }
                }
                
                info += "Réservation N° " + reservation.getId() + " \n ";
                
                info += "Identifiant du responsable de cette transaction: " + login + " \n ";

                reservation.setLogin(login);

                try {
                    entityManager.getTransaction().commit();
                    entityManager.getTransaction().begin();
                } catch (RollbackException rex) {
                    entityManager.getTransaction().begin();
                    List<hotelpro.entities.Reservation> merged = new ArrayList<>(list.size());
                    for (Iterator<Reservation> it = list.iterator(); it.hasNext();) {
                        hotelpro.entities.Reservation r = it.next();
                        merged.add(entityManager.merge(r));
                    }
                    list.clear();
                    list.addAll(merged);
                }
            } catch (Exception e) {
            }

            entityManager.getTransaction().commit();
            entityManager.getTransaction().begin();
            if (cmbEtatReservation.getSelectedIndex() == 3) {
                chambre.setStatut("DISPONIBLE");
            } else {
                chambre.setStatut("OCCUPEE");
            }
            entityManager.merge(chambre);
            entityManager.getTransaction().commit();

            info += "Id / Désignation de la chambre: " + chambre.getId() + " / " + chambre.getDesignation() + " \n ";
            
            info += "Statut de la chambre après coup: " + chambre.getStatut();
            
            log.setInfo(info);
            log.setLogin(login);
            log.setDateHeure(String.valueOf(new java.util.Date()));
            try {
                hotel.majLog(log);
            } catch (Exception e) {
            }

            try {
                /*Ecriture dans le fichier log du jour*/
                hotel.ecrireDansFichier(log.getDateHeure() + " : \n Utilisateur : " + log.getLogin() + " \n " + log.getInfo(), fichier_log_du_jour);
            } catch (IOException ex) {
                Logger.getLogger(ReservationView.class.getName()).log(Level.SEVERE, null, ex);
            }

            Hotel.refreshEntitiesChambre();

            JOptionPane.showMessageDialog(null, "Les modifications ont été enregistrées avec succès!");

            backButtonActionPerformed(null);
        }
    }//GEN-LAST:event_saveButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        cardLayout.show(jPanel, fenetreString);
    }//GEN-LAST:event_backButtonActionPerformed

    private void cmbClientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbClientsActionPerformed
        // TODO add your handling code here:
        try {
            clientField.setText(String.valueOf(
                    hotel.listerClientParNomComplet(cmbClients.getSelectedItem().toString()).getId()));
        } catch (Exception e) {
            clientField.setText("");
        }
    }//GEN-LAST:event_cmbClientsActionPerformed

    private void cmbEtatReservationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbEtatReservationActionPerformed
        // TODO add your handling code here:
        if (cmbEtatReservation.getSelectedIndex() != 0) {
            etatReservationField.setText(cmbEtatReservation.getSelectedItem().toString());
        }
    }//GEN-LAST:event_cmbEtatReservationActionPerformed

    private void cmbHeureArriveeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbHeureArriveeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbHeureArriveeActionPerformed

    private void refreshCmbClientsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshCmbClientsActionPerformed
        // TODO add your handling code here:
        Hotel.refreshEntitiesClient();
        remplirCmbClients();
    }//GEN-LAST:event_refreshCmbClientsActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JTextField chambreField;
    private javax.swing.JLabel chambreLabel;
    private javax.swing.JTextField clientField;
    private javax.swing.JLabel clientLabel;
    private javax.swing.JComboBox cmbClients;
    private javax.swing.JComboBox cmbEtatReservation;
    private javax.swing.JComboBox cmbHeureArrivee;
    private javax.swing.JComboBox cmbHeureDepart;
    private javax.swing.JComboBox cmbMinuteArrivee;
    private javax.swing.JComboBox cmbMinuteDepart;
    private javax.swing.JTextField dateArriveeField;
    private javax.swing.JLabel dateArriveeLabel;
    private javax.swing.JTextField dateDepartField;
    private javax.swing.JLabel dateDepartLabel;
    private javax.swing.JTextField dateReservationField;
    private javax.swing.JLabel dateReservationLabel;
    private javax.swing.JButton deleteButton;
    private javax.swing.JLabel designationChambre;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JTextField etatReservationField;
    private javax.swing.JLabel etatReservationLabel;
    private com.toedter.calendar.JDateChooser jDateChooserArrivee;
    private com.toedter.calendar.JDateChooser jDateChooserDepart;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private java.util.List<hotelpro.entities.Reservation> list;
    private javax.swing.JScrollPane masterScrollPane;
    private javax.swing.JTable masterTable;
    private javax.swing.JButton newButton;
    private javax.persistence.Query query;
    private javax.swing.JButton refreshButton;
    private javax.swing.JButton refreshCmbClients;
    private javax.swing.JButton saveButton;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

    public static void main(String[] args) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservationView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame();
                frame.setContentPane(new ReservationView());
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

    private void remplirCmbClients() {
        try {
            cmbClients.removeAllItems();
            cmbClients.addItem("-----Sélectionnez le client ici-----");
            List<Client> listClients = hotel.listerClientsOrderByNomAsc();
//            String autocomplete[] = new String[listClients.size()];
//            int i = 0;
            for (Iterator<Client> it = listClients.iterator(); it.hasNext();) {
                Client client = it.next();
                cmbClients.addItem(client.getNom() + " " + client.getPrenoms());
//                autocomplete[i] = client.getNom() + " " + client.getPrenoms();
//                i++;
            }
            cmbClients.setSelectedItem(null);
//            AutoCompleteSupport.install(cmbClients, GlazedLists.eventListOf(autocomplete));
        } catch (Exception e) {
        }
    }
}
