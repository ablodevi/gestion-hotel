/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.gui.views;

import hotelpro.entities.CategorieClient;
import hotelpro.entities.Client;
import hotelpro.entities.Pays;
import hotelpro.gui.Gui;
import hotelpro.gui.RechercheClients;
import hotelpro.gui.RechercherPanel;
import hotelpro.utils.Hotel;
import hotelpro.utils.Paths;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.Beans;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.RollbackException;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Serge
 */
public class ClientView extends JPanel {

    Hotel hotel = new Hotel();
    Paths paths = new Paths();
    JFileChooser jFileChooser = new JFileChooser();
    JDialog jDialog = new JDialog();
    Gui gui;
    CardLayout cardLayout;
    String clientViewString;
    RechercherPanel rechercherPanel;
    String rechercherPanelString;
    RechercheClients rechercheClients;
    String rechercheClientsString;
    String libelleIndex0CmbCat = "---Catégorie du client---";
    hotelpro.entities.Client client;
    int newClient = 0;

    public ClientView() {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        masterScrollPane.setVisible(Boolean.FALSE);

//        ageLabel.setVisible(Boolean.FALSE);
//        ageField.setVisible(Boolean.FALSE);
//        remplirCmbAge();

        sexeLabel.setVisible(Boolean.FALSE);
        sexeField.setVisible(Boolean.FALSE);

        cmbSexe.setEnabled(Boolean.FALSE);

        paysResidenceLabel.setVisible(Boolean.FALSE);
        paysResidenceField.setVisible(Boolean.FALSE);

        cmbPaysResidence.setEnabled(Boolean.FALSE);
        remplirCmbPaysResidence();

        nationaliteLabel.setVisible(Boolean.FALSE);
        nationaliteField.setVisible(Boolean.FALSE);

        cmbNationalite.setEnabled(Boolean.FALSE);
        remplirCmbNationalite();

        photoLabel.setVisible(Boolean.FALSE);
        photoField.setVisible(Boolean.FALSE);

        photoGrandFormatLabel.setVisible(Boolean.FALSE);
        photoGrandFormatField.setVisible(Boolean.FALSE);

        categorieClientLabel.setVisible(Boolean.FALSE);
        categorieClientField.setVisible(Boolean.FALSE);
        remplirCmbCatClient();
        remplirCmbRechercheCat();

        cmbCategorieClient.setEnabled(Boolean.FALSE);
        
        carteFideliteLabel.setVisible(Boolean.FALSE);
        carteFideliteField.setVisible(Boolean.FALSE);
        gererCarteFidelite.setVisible(Boolean.FALSE);
        cmbCarteFidelite.setEnabled(Boolean.FALSE);

        deleteButton.setVisible(Boolean.FALSE);
        
        plusChampsFalse();

        jDialog.setSize(600, 400);
        jDialog.setBackground(Color.WHITE);
        jDialog.setResizable(Boolean.FALSE);
        jDialog.setLocationRelativeTo(this.getParent());
        jDialog.setLayout(new BorderLayout());
        jDialog.add(jFileChooser, BorderLayout.CENTER);
        jDialog.setAlwaysOnTop(Boolean.TRUE);
    }

    public ClientView(Gui gui, CardLayout cardLayout, String clientViewString, RechercherPanel rechercherPanel, String rechercherPanelString) {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        this.gui = gui;
        this.cardLayout = cardLayout;
        this.clientViewString = clientViewString;
        this.rechercherPanel = rechercherPanel;
        this.rechercherPanelString = rechercherPanelString;

        masterScrollPane.setVisible(Boolean.FALSE);

//        ageLabel.setVisible(Boolean.FALSE);
//        ageField.setVisible(Boolean.FALSE);
//        remplirCmbAge();

        sexeLabel.setVisible(Boolean.FALSE);
        sexeField.setVisible(Boolean.FALSE);

        cmbSexe.setEnabled(Boolean.FALSE);

        paysResidenceLabel.setVisible(Boolean.FALSE);
        paysResidenceField.setVisible(Boolean.FALSE);

        cmbPaysResidence.setEnabled(Boolean.FALSE);
        remplirCmbPaysResidence();

        nationaliteLabel.setVisible(Boolean.FALSE);
        nationaliteField.setVisible(Boolean.FALSE);

        cmbNationalite.setEnabled(Boolean.FALSE);
        remplirCmbNationalite();

        photoLabel.setVisible(Boolean.FALSE);
        photoField.setVisible(Boolean.FALSE);

        photoGrandFormatLabel.setVisible(Boolean.FALSE);
        photoGrandFormatField.setVisible(Boolean.FALSE);

        categorieClientLabel.setVisible(Boolean.FALSE);
        categorieClientField.setVisible(Boolean.FALSE);
        remplirCmbCatClient();
        remplirCmbRechercheCat();

        cmbCategorieClient.setEnabled(Boolean.FALSE);
        
        carteFideliteLabel.setVisible(Boolean.FALSE);
        carteFideliteField.setVisible(Boolean.FALSE);
        gererCarteFidelite.setVisible(Boolean.FALSE);
        cmbCarteFidelite.setEnabled(Boolean.FALSE);

        deleteButton.setVisible(Boolean.FALSE);
        
        plusChampsFalse();

        jDialog.setSize(600, 400);
        jDialog.setBackground(Color.WHITE);
        jDialog.setResizable(Boolean.FALSE);
        jDialog.setLocationRelativeTo(this.getParent());
        jDialog.setLayout(new BorderLayout());
        jDialog.add(jFileChooser, BorderLayout.CENTER);
        jDialog.setAlwaysOnTop(Boolean.TRUE);
    }
    
    public ClientView(Gui gui, CardLayout cardLayout, String clientViewString, RechercheClients rechercheClients, String rechercheClientsString) {
        initComponents();
        if (!Beans.isDesignTime()) {
            entityManager.getTransaction().begin();
        }

        this.gui = gui;
        this.cardLayout = cardLayout;
        this.clientViewString = clientViewString;
        this.rechercheClients = rechercheClients;
        this.rechercheClientsString = rechercheClientsString;

        masterScrollPane.setVisible(Boolean.FALSE);

//        ageLabel.setVisible(Boolean.FALSE);
//        ageField.setVisible(Boolean.FALSE);
//        remplirCmbAge();

        sexeLabel.setVisible(Boolean.FALSE);
        sexeField.setVisible(Boolean.FALSE);

        cmbSexe.setEnabled(Boolean.FALSE);

        paysResidenceLabel.setVisible(Boolean.FALSE);
        paysResidenceField.setVisible(Boolean.FALSE);

        cmbPaysResidence.setEnabled(Boolean.FALSE);
        remplirCmbPaysResidence();

        nationaliteLabel.setVisible(Boolean.FALSE);
        nationaliteField.setVisible(Boolean.FALSE);

        cmbNationalite.setEnabled(Boolean.FALSE);
        remplirCmbNationalite();

        photoLabel.setVisible(Boolean.FALSE);
        photoField.setVisible(Boolean.FALSE);

        photoGrandFormatLabel.setVisible(Boolean.FALSE);
        photoGrandFormatField.setVisible(Boolean.FALSE);

        categorieClientLabel.setVisible(Boolean.FALSE);
        categorieClientField.setVisible(Boolean.FALSE);
        remplirCmbCatClient();
//        remplirCmbRechercheCat();
        setVisibleFalseRechercherPanel();

        cmbCategorieClient.setEnabled(Boolean.FALSE);
        
        carteFideliteLabel.setVisible(Boolean.FALSE);
        carteFideliteField.setVisible(Boolean.FALSE);
        gererCarteFidelite.setVisible(Boolean.FALSE);
        cmbCarteFidelite.setEnabled(Boolean.FALSE);

        deleteButton.setVisible(Boolean.FALSE);
        
        plusChampsFalse();

        jDialog.setSize(600, 400);
        jDialog.setBackground(Color.WHITE);
        jDialog.setResizable(Boolean.FALSE);
        jDialog.setLocationRelativeTo(this.getParent());
        jDialog.setLayout(new BorderLayout());
        jDialog.add(jFileChooser, BorderLayout.CENTER);
        jDialog.setAlwaysOnTop(Boolean.TRUE);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("HotelProPU").createEntityManager();
        query = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Client c");
        list = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : org.jdesktop.observablecollections.ObservableCollections.observableList(query.getResultList());
        masterScrollPane = new javax.swing.JScrollPane();
        masterTable = new javax.swing.JTable();
        nomLabel = new javax.swing.JLabel();
        prenomsLabel = new javax.swing.JLabel();
        surnomLabel = new javax.swing.JLabel();
        butVisiteLabel = new javax.swing.JLabel();
        ageLabel = new javax.swing.JLabel();
        sexeLabel = new javax.swing.JLabel();
        paysResidenceLabel = new javax.swing.JLabel();
        nationaliteLabel = new javax.swing.JLabel();
        religionLabel = new javax.swing.JLabel();
        adressePersoLabel = new javax.swing.JLabel();
        adresseProLabel = new javax.swing.JLabel();
        mobilePersoLabel = new javax.swing.JLabel();
        mobileProLabel = new javax.swing.JLabel();
        fixePersoLabel = new javax.swing.JLabel();
        fixeProLabel = new javax.swing.JLabel();
        faxLabel = new javax.swing.JLabel();
        idCardLabel = new javax.swing.JLabel();
        passeportLabel = new javax.swing.JLabel();
        emailLabel = new javax.swing.JLabel();
        websiteLabel = new javax.swing.JLabel();
        professionLabel = new javax.swing.JLabel();
        societeLabel = new javax.swing.JLabel();
        photoLabel = new javax.swing.JLabel();
        photoGrandFormatLabel = new javax.swing.JLabel();
        categorieClientLabel = new javax.swing.JLabel();
        carteFideliteLabel = new javax.swing.JLabel();
        nomField = new javax.swing.JTextField();
        prenomsField = new javax.swing.JTextField();
        surnomField = new javax.swing.JTextField();
        butVisiteField = new javax.swing.JTextField();
        ageField = new javax.swing.JTextField();
        sexeField = new javax.swing.JTextField();
        paysResidenceField = new javax.swing.JTextField();
        nationaliteField = new javax.swing.JTextField();
        religionField = new javax.swing.JTextField();
        adressePersoField = new javax.swing.JTextField();
        adresseProField = new javax.swing.JTextField();
        mobilePersoField = new javax.swing.JTextField();
        mobileProField = new javax.swing.JTextField();
        fixePersoField = new javax.swing.JTextField();
        fixeProField = new javax.swing.JTextField();
        faxField = new javax.swing.JTextField();
        idCardField = new javax.swing.JTextField();
        passeportField = new javax.swing.JTextField();
        emailField = new javax.swing.JTextField();
        websiteField = new javax.swing.JTextField();
        professionField = new javax.swing.JTextField();
        societeField = new javax.swing.JTextField();
        photoField = new javax.swing.JTextField();
        photoGrandFormatField = new javax.swing.JTextField();
        categorieClientField = new javax.swing.JTextField();
        carteFideliteField = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        refreshButton = new javax.swing.JButton();
        newButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cmbRechercheCat = new javax.swing.JComboBox();
        cmbRecherche = new javax.swing.JComboBox();
        cmbCritere = new javax.swing.JComboBox();
        actualiserCmbRechercheCatButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        rechercherButton = new javax.swing.JButton();
        cmbCategorieClient = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        actualiserCmbCatClient = new javax.swing.JButton();
        drapeauLab = new javax.swing.JLabel();
        photoLab = new javax.swing.JLabel();
        photoButton = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cmbPaysResidence = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        cmbNationalite = new javax.swing.JComboBox();
        cmbSexe = new javax.swing.JComboBox();
        gererCategorieClientButton = new javax.swing.JButton();
        gererCarteFidelite = new javax.swing.JButton();
        actualiserCmbPaysResidenceButton = new javax.swing.JButton();
        actualiserCmbNationaliteButton = new javax.swing.JButton();
        listeClientsButton = new javax.swing.JButton();
        cmbCarteFidelite = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        rechercheClientsButton = new javax.swing.JButton();
        plusChampsButton = new javax.swing.JButton();

        FormListener formListener = new FormListener();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder("Gestion Clients"));

        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, list, masterTable);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${id}"));
        columnBinding.setColumnName("Code");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${nom}"));
        columnBinding.setColumnName("Nom");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${prenoms}"));
        columnBinding.setColumnName("Prenoms");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        masterScrollPane.setViewportView(masterTable);

        nomLabel.setText("Nom:");

        prenomsLabel.setText("Prenoms:");

        surnomLabel.setText("Surnom:");

        butVisiteLabel.setText("But Visite:");

        ageLabel.setText("Age:");

        sexeLabel.setText("Sexe:");

        paysResidenceLabel.setText("Pays Residence:");

        nationaliteLabel.setText("Nationalite:");

        religionLabel.setText("Religion:");

        adressePersoLabel.setText("Adresse Perso:");

        adresseProLabel.setText("Adresse Pro:");

        mobilePersoLabel.setText("Mobile Perso:");

        mobileProLabel.setText("Mobile Pro:");

        fixePersoLabel.setText("Fixe Perso:");

        fixeProLabel.setText("Fixe Pro:");

        faxLabel.setText("Fax:");

        idCardLabel.setText("Id Card:");

        passeportLabel.setText("Passeport:");

        emailLabel.setText("Email:");

        websiteLabel.setText("Website:");

        professionLabel.setText("Profession:");

        societeLabel.setText("Societe:");

        photoLabel.setText("Photo:");

        photoGrandFormatLabel.setText("Photo GFormat:");

        categorieClientLabel.setText("Categorie Client:");

        carteFideliteLabel.setText("Carte Fidelite:");

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.nom}"), nomField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), nomField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.prenoms}"), prenomsField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), prenomsField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.surnom}"), surnomField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), surnomField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.butVisite}"), butVisiteField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), butVisiteField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.age}"), ageField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), ageField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.sexe}"), sexeField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), sexeField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.paysResidence}"), paysResidenceField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), paysResidenceField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.nationalite}"), nationaliteField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), nationaliteField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.religion}"), religionField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), religionField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.adressePerso}"), adressePersoField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), adressePersoField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.adressePro}"), adresseProField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), adresseProField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.mobilePerso}"), mobilePersoField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), mobilePersoField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.mobilePro}"), mobileProField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), mobileProField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.fixePerso}"), fixePersoField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), fixePersoField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.fixePro}"), fixeProField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), fixeProField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.fax}"), faxField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), faxField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.idCard}"), idCardField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), idCardField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.passeport}"), passeportField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), passeportField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.email}"), emailField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), emailField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.website}"), websiteField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), websiteField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.profession}"), professionField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), professionField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.societe}"), societeField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), societeField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.photo}"), photoField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), photoField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.photoGrandFormat}"), photoGrandFormatField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), photoGrandFormatField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.categorieClient}"), categorieClientField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), categorieClientField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement.carteFidelite}"), carteFideliteField, org.jdesktop.beansbinding.BeanProperty.create("text"));
        binding.setSourceUnreadableValue(null);
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), carteFideliteField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        saveButton.setText("Enregistrer");
        saveButton.addActionListener(formListener);

        refreshButton.setText("Actualiser");
        refreshButton.addActionListener(formListener);

        newButton.setText("Nouveau client");
        newButton.addActionListener(formListener);

        deleteButton.setText("Delete");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ, masterTable, org.jdesktop.beansbinding.ELProperty.create("${selectedElement != null}"), deleteButton, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        deleteButton.addActionListener(formListener);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/jumelles - tiny.jpg"))); // NOI18N
        jLabel1.setText("Recherche:");

        cmbRechercheCat.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "---Catégorie du client---" }));

        cmbRecherche.setEditable(true);
        cmbRecherche.addActionListener(formListener);

        cmbCritere.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "---- Choisissez le critère ici ----", "Nom", "Prenom(s)", "Surnom", "Téléphone", "Fax", "Site Web", "Société", "Profession", "Adresse", "Anniversaire", "E-mail" }));
        cmbCritere.addActionListener(formListener);

        actualiserCmbRechercheCatButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tinyRefresh.png"))); // NOI18N
        actualiserCmbRechercheCatButton.addActionListener(formListener);

        jLabel2.setText("Saisissez ci-dessous ce que vous cherchez.");

        rechercherButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/loupe-rechercher.png"))); // NOI18N
        rechercherButton.setText("Rechercher");
        rechercherButton.addActionListener(formListener);

        cmbCategorieClient.addActionListener(formListener);

        jLabel3.setText("Catégorie Client:");

        actualiserCmbCatClient.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tinyRefresh.png"))); // NOI18N
        actualiserCmbCatClient.addActionListener(formListener);

        drapeauLab.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        drapeauLab.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        photoLab.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        photoLab.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        photoButton.setText("Choisir une photo");
        photoButton.addActionListener(formListener);

        jLabel4.setText("Sexe:");

        jLabel5.setText("Pays Résidence:");

        cmbPaysResidence.addActionListener(formListener);

        jLabel6.setText("Nationalité:");

        cmbNationalite.addActionListener(formListener);

        cmbSexe.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Male", "Femelle" }));
        cmbSexe.addActionListener(formListener);

        gererCategorieClientButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/plus.PNG"))); // NOI18N
        gererCategorieClientButton.addActionListener(formListener);

        gererCarteFidelite.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/plus.PNG"))); // NOI18N
        gererCarteFidelite.addActionListener(formListener);

        actualiserCmbPaysResidenceButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tinyRefresh.png"))); // NOI18N
        actualiserCmbPaysResidenceButton.addActionListener(formListener);

        actualiserCmbNationaliteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotelpro/resources/tinyRefresh.png"))); // NOI18N
        actualiserCmbNationaliteButton.addActionListener(formListener);

        listeClientsButton.setText("Afficher la liste de tous les clients (classement par ordre alphabétique)");
        listeClientsButton.addActionListener(formListener);

        cmbCarteFidelite.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "NON", "OUI" }));
        cmbCarteFidelite.addActionListener(formListener);

        jLabel8.setText("Carte Fidélité:");

        rechercheClientsButton.setText("Rechercher un client (recherche avancée)");
        rechercheClientsButton.addActionListener(formListener);

        plusChampsButton.setText("Plus de champs");
        plusChampsButton.addActionListener(formListener);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cmbCritere, 0, 208, Short.MAX_VALUE)
                                    .addComponent(cmbRechercheCat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(actualiserCmbRechercheCatButton, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cmbRecherche, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(rechercherButton, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(masterScrollPane)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(107, 107, 107)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(newButton, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(refreshButton))
                                        .addComponent(photoButton, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(drapeauLab, javax.swing.GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)
                                            .addGap(27, 27, 27)
                                            .addComponent(photoLab, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(listeClientsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(rechercheClientsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(324, 324, 324)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(fixePersoLabel)
                                            .addComponent(fixeProLabel)
                                            .addComponent(faxLabel)
                                            .addComponent(idCardLabel)
                                            .addComponent(passeportLabel)
                                            .addComponent(emailLabel)
                                            .addComponent(websiteLabel)
                                            .addComponent(professionLabel)
                                            .addComponent(societeLabel)
                                            .addComponent(religionLabel)
                                            .addComponent(adressePersoLabel)
                                            .addComponent(adresseProLabel)
                                            .addComponent(mobilePersoLabel)
                                            .addComponent(mobileProLabel)
                                            .addComponent(surnomLabel)
                                            .addComponent(butVisiteLabel))
                                        .addGap(32, 32, 32)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(mobilePersoField)
                                            .addComponent(adresseProField)
                                            .addComponent(societeField)
                                            .addComponent(professionField)
                                            .addComponent(websiteField)
                                            .addComponent(emailField)
                                            .addComponent(passeportField)
                                            .addComponent(idCardField)
                                            .addComponent(faxField)
                                            .addComponent(fixeProField)
                                            .addComponent(fixePersoField)
                                            .addComponent(religionField)
                                            .addComponent(adressePersoField)
                                            .addComponent(mobileProField)
                                            .addComponent(surnomField)
                                            .addComponent(butVisiteField, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addGap(0, 67, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ageLabel)
                            .addComponent(nomLabel)
                            .addComponent(prenomsLabel))
                        .addGap(60, 60, 60)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(deleteButton)
                                .addGap(47, 47, 47)
                                .addComponent(saveButton)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(nomField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 229, Short.MAX_VALUE)
                                    .addComponent(prenomsField, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(ageField, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sexeLabel)
                            .addComponent(paysResidenceLabel)
                            .addComponent(nationaliteLabel)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(carteFideliteLabel)
                            .addComponent(jLabel8)
                            .addComponent(jLabel3)
                            .addComponent(categorieClientLabel)
                            .addComponent(photoGrandFormatLabel)
                            .addComponent(photoLabel)
                            .addComponent(jLabel6))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(photoGrandFormatField, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(photoField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(categorieClientField, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(cmbNationalite, 0, 229, Short.MAX_VALUE)
                                    .addComponent(nationaliteField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbPaysResidence, 0, 229, Short.MAX_VALUE)
                                    .addComponent(paysResidenceField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbSexe, javax.swing.GroupLayout.Alignment.LEADING, 0, 229, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(actualiserCmbNationaliteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(actualiserCmbPaysResidenceButton, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(sexeField, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(cmbCarteFidelite, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbCategorieClient, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(actualiserCmbCatClient, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(gererCarteFidelite, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(gererCategorieClientButton, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(plusChampsButton)
                                .addComponent(carteFideliteField, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {deleteButton, refreshButton, saveButton});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel1)
                                .addComponent(cmbRechercheCat)
                                .addComponent(actualiserCmbRechercheCatButton, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbCritere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbRecherche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(rechercherButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(masterScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(listeClientsButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rechercheClientsButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(refreshButton)
                    .addComponent(newButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(drapeauLab, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                    .addComponent(photoLab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(photoButton)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fixePersoLabel)
                            .addComponent(fixePersoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fixeProLabel)
                            .addComponent(fixeProField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(faxLabel)
                            .addComponent(faxField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idCardLabel)
                            .addComponent(idCardField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(passeportLabel)
                            .addComponent(passeportField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(emailLabel)
                            .addComponent(emailField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(websiteLabel)
                            .addComponent(websiteField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(professionLabel)
                            .addComponent(professionField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(societeLabel)
                            .addComponent(societeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(religionLabel)
                            .addComponent(religionField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adressePersoLabel)
                            .addComponent(adressePersoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adresseProLabel)
                            .addComponent(adresseProField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mobilePersoLabel)
                            .addComponent(mobilePersoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mobileProLabel)
                            .addComponent(mobileProField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(surnomLabel)
                            .addComponent(surnomField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(butVisiteLabel)
                            .addComponent(butVisiteField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nomLabel)
                            .addComponent(nomField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prenomsLabel)
                            .addComponent(prenomsField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ageLabel)
                            .addComponent(ageField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(sexeLabel)
                            .addComponent(sexeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cmbSexe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paysResidenceLabel)
                            .addComponent(paysResidenceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(actualiserCmbPaysResidenceButton, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(cmbPaysResidence, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nationaliteLabel)
                            .addComponent(nationaliteField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(actualiserCmbNationaliteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(cmbNationalite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(photoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(photoLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(photoGrandFormatField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(photoGrandFormatLabel))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(categorieClientField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(categorieClientLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(gererCategorieClientButton, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(gererCarteFidelite, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(actualiserCmbCatClient, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cmbCategorieClient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cmbCarteFidelite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(carteFideliteField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(carteFideliteLabel))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(plusChampsButton)))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(saveButton)
                    .addComponent(deleteButton))
                .addContainerGap(121, Short.MAX_VALUE))
        );

        bindingGroup.bind();
    }

    // Code for dispatching events from components to event handlers.

    private class FormListener implements java.awt.event.ActionListener {
        FormListener() {}
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (evt.getSource() == saveButton) {
                ClientView.this.saveButtonActionPerformed(evt);
            }
            else if (evt.getSource() == refreshButton) {
                ClientView.this.refreshButtonActionPerformed(evt);
            }
            else if (evt.getSource() == newButton) {
                ClientView.this.newButtonActionPerformed(evt);
            }
            else if (evt.getSource() == deleteButton) {
                ClientView.this.deleteButtonActionPerformed(evt);
            }
            else if (evt.getSource() == cmbRecherche) {
                ClientView.this.cmbRechercheActionPerformed(evt);
            }
            else if (evt.getSource() == cmbCritere) {
                ClientView.this.cmbCritereActionPerformed(evt);
            }
            else if (evt.getSource() == actualiserCmbRechercheCatButton) {
                ClientView.this.actualiserCmbRechercheCatButtonActionPerformed(evt);
            }
            else if (evt.getSource() == rechercherButton) {
                ClientView.this.rechercherButtonActionPerformed(evt);
            }
            else if (evt.getSource() == cmbCategorieClient) {
                ClientView.this.cmbCategorieClientActionPerformed(evt);
            }
            else if (evt.getSource() == actualiserCmbCatClient) {
                ClientView.this.actualiserCmbCatClientActionPerformed(evt);
            }
            else if (evt.getSource() == photoButton) {
                ClientView.this.photoButtonActionPerformed(evt);
            }
            else if (evt.getSource() == cmbPaysResidence) {
                ClientView.this.cmbPaysResidenceActionPerformed(evt);
            }
            else if (evt.getSource() == cmbNationalite) {
                ClientView.this.cmbNationaliteActionPerformed(evt);
            }
            else if (evt.getSource() == cmbSexe) {
                ClientView.this.cmbSexeActionPerformed(evt);
            }
            else if (evt.getSource() == gererCategorieClientButton) {
                ClientView.this.gererCategorieClientButtonActionPerformed(evt);
            }
            else if (evt.getSource() == gererCarteFidelite) {
                ClientView.this.gererCarteFideliteActionPerformed(evt);
            }
            else if (evt.getSource() == actualiserCmbPaysResidenceButton) {
                ClientView.this.actualiserCmbPaysResidenceButtonActionPerformed(evt);
            }
            else if (evt.getSource() == actualiserCmbNationaliteButton) {
                ClientView.this.actualiserCmbNationaliteButtonActionPerformed(evt);
            }
            else if (evt.getSource() == listeClientsButton) {
                ClientView.this.listeClientsButtonActionPerformed(evt);
            }
            else if (evt.getSource() == cmbCarteFidelite) {
                ClientView.this.cmbCarteFideliteActionPerformed(evt);
            }
            else if (evt.getSource() == rechercheClientsButton) {
                ClientView.this.rechercheClientsButtonActionPerformed(evt);
            }
            else if (evt.getSource() == plusChampsButton) {
                ClientView.this.plusChampsButtonActionPerformed(evt);
            }
        }
    }// </editor-fold>//GEN-END:initComponents

    @SuppressWarnings("unchecked")
    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        entityManager.getTransaction().rollback();
        entityManager.getTransaction().begin();
        java.util.Collection data = query.getResultList();
        for (Object entity : data) {
            entityManager.refresh(entity);
        }
        list.clear();
        list.addAll(data);

        cmbSexe.setSelectedIndex(0);
        cmbSexe.setEnabled(Boolean.FALSE);
        
//        remplirCmbAge();
//        cmbAge.setEnabled(Boolean.FALSE);
        
        remplirCmbPaysResidence();
        cmbPaysResidence.setEnabled(Boolean.FALSE);
        
        remplirCmbNationalite();
        cmbNationalite.setEnabled(Boolean.FALSE);
        
        remplirCmbCatClient();
        cmbCategorieClient.setEnabled(Boolean.FALSE);
        
        cmbCarteFidelite.setSelectedIndex(0);
        cmbCarteFidelite.setEnabled(Boolean.FALSE);

        newClient = 0;

        
        
        remplirCmbRechercheCat();
        
        
        photoLab.setText(null);
        
        plusChampsFalse();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        int[] selected = masterTable.getSelectedRows();
        List<hotelpro.entities.Client> toRemove = new ArrayList<>(selected.length);
        for (int idx = 0; idx < selected.length; idx++) {
            hotelpro.entities.Client c = list.get(masterTable.convertRowIndexToModel(selected[idx]));
            toRemove.add(c);
            entityManager.remove(c);
        }
        list.removeAll(toRemove);

        newClient = 0;

//        cmbAge.setEnabled(Boolean.FALSE);
        cmbSexe.setEnabled(Boolean.FALSE);
        cmbPaysResidence.setEnabled(Boolean.FALSE);
        cmbNationalite.setEnabled(Boolean.FALSE);
        cmbCategorieClient.setEnabled(Boolean.FALSE);
        cmbCarteFidelite.setEnabled(Boolean.FALSE);
        
        plusChampsFalse();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void newButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newButtonActionPerformed
        newClient = 1;
        client = new hotelpro.entities.Client();
        entityManager.persist(client);
        list.add(client);
        int row = list.size() - 1;
        masterTable.setRowSelectionInterval(row, row);
        masterTable.scrollRectToVisible(masterTable.getCellRect(row, 0, true));

//        cmbAge.setEnabled(Boolean.TRUE);
        cmbSexe.setEnabled(Boolean.TRUE);
        cmbPaysResidence.setEnabled(Boolean.TRUE);
        cmbNationalite.setEnabled(Boolean.TRUE);
        cmbCategorieClient.setEnabled(Boolean.TRUE);
        ageField.setEditable(Boolean.FALSE);
        carteFideliteField.setEditable(Boolean.FALSE);
        cmbCarteFidelite.setEnabled(Boolean.FALSE);
        
        plusChampsFalse();
    }//GEN-LAST:event_newButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        if ("".equals(nomField.getText().trim()) || "".equals(prenomsField.getText().trim())) {
            try {
                JOptionPane.showMessageDialog(null, "Veuillez saisir les nom et prenoms "
                        + "du client dans les zones de texte prévues à cet effet.");
            } catch (HeadlessException headlessException) {
            }
        } else if (!"".equals(ageField.getText().trim())) {
            int age = 0;
            try {
                age = (int) Integer.parseInt(String.valueOf(ageField.getText().trim()));
            } catch (NumberFormatException numberFormatException) {
            }
            
            if (age <= 0) {
                JOptionPane.showMessageDialog(null, "Veuillez saisir l'âge réel de la personne.");
            }
        } else {
            if (newClient == 1) {
                if (client.getId() == null) {
                    try {
                        client.setId(Integer.parseInt(String.valueOf(hotel.listerMaxIdClient() + 1)));
                    } catch (NumberFormatException numberFormatException) {
                    }
                }
            }
            
            try {
                paysResidenceField.setText(cmbPaysResidence.getSelectedItem().toString());
            } catch (Exception e) {
            }

            try {
                nationaliteField.setText(cmbNationalite.getSelectedItem().toString());
            } catch (Exception e) {
            }

            cmbSexeActionPerformed(null);

            try {
                entityManager.getTransaction().commit();
                entityManager.getTransaction().begin();
            } catch (RollbackException rex) {
                entityManager.getTransaction().begin();
                List<hotelpro.entities.Client> merged = new ArrayList<>(list.size());
                for (hotelpro.entities.Client c : list) {
                    merged.add(entityManager.merge(c));
                }
                list.clear();
                list.addAll(merged);
            }
            
            try {
                JOptionPane.showMessageDialog(null, "Opération effectuée.");
            } catch (HeadlessException headlessException) {
            }
            
            refreshButtonActionPerformed(null);
        }
        
        plusChampsFalse();
    }//GEN-LAST:event_saveButtonActionPerformed

    private void cmbRechercheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbRechercheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbRechercheActionPerformed

    private void actualiserCmbCatClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualiserCmbCatClientActionPerformed
        // TODO add your handling code here:
        remplirCmbCatClient();
    }//GEN-LAST:event_actualiserCmbCatClientActionPerformed

    private void actualiserCmbRechercheCatButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualiserCmbRechercheCatButtonActionPerformed
        // TODO add your handling code here:
        remplirCmbRechercheCat();
    }//GEN-LAST:event_actualiserCmbRechercheCatButtonActionPerformed

    private void rechercherButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rechercherButtonActionPerformed
        // TODO add your handling code here:
        String string = null;
        try {
            string = cmbRecherche.getSelectedItem().toString().trim();
        } catch (Exception e) {
        }
        List<Client> listClients = new LinkedList<>();
        if (cmbCritere.getSelectedIndex() != 0) {
            switch (cmbCritere.getSelectedItem().toString()) {
                case "Nom":
                    listClients = hotel.listerClientsParNomComme(string);
                    break;
                case "Prenom(s)":
                    listClients = hotel.listerClientsParPrenomComme(string);
                    break;
                case "Surnom":
                    listClients = hotel.listerClientsParSurnomComme(string);
                    break;
                case "Téléphone":
                    listClients = hotel.listerClientsParTelephoneComme(string);
                    break;
                case "Fax":
                    listClients = hotel.listerClientsParFaxComme(string);
                    break;
                case "Site Web":
                    listClients = hotel.listerClientsParSiteWebComme(string);
                    break;
                case "Société":
                    listClients = hotel.listerClientsParSocieteComme(string);
                    break;
                case "Profession":
                    listClients = hotel.listerClientsParProfessionComme(string);
                    break;
                case "Adresse":
                    listClients = hotel.listerClientsParAdresseComme(string);
                    break;
                case "Anniversaire":
                    listClients = hotel.listerClientsParAnniversaireComme(string);
                    break;
                case "E-mail":
                    listClients = hotel.listerClientsParEmailComme(string);
                    break;
            }
        }

        List<Client> listClientsFiltree = new LinkedList<>();
        if (cmbRechercheCat.getSelectedIndex() != 0) {
            CategorieClient categorieClient = hotel.listerCategorieClientParDesignation(cmbRechercheCat.getSelectedItem().toString());
            for (Iterator<Client> it = listClients.iterator(); it.hasNext();) {
                Client cli = it.next();
                if ((int) cli.getCategorieClient() == categorieClient.getId()) {
                    listClientsFiltree.add(cli);
                }
            }
        } else {
            listClientsFiltree = listClients;
        }

        rechercherPanel = new RechercherPanel(gui, cardLayout, this, clientViewString, listClientsFiltree);
        gui.getjPanel3().add(rechercherPanel, rechercherPanelString);
        cardLayout.show(gui.getjPanel3(), rechercherPanelString);
    }//GEN-LAST:event_rechercherButtonActionPerformed

    private void cmbCritereActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCritereActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbCritereActionPerformed

    private void photoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_photoButtonActionPerformed
        // TODO add your handling code here:
        jDialog.setVisible(Boolean.TRUE);
        jDialog.setAlwaysOnTop(Boolean.TRUE);
        jFileChooser.setCurrentDirectory(new File(paths.recupererClientsPhotosPassportDirectory()));
        jFileChooser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String chemin;
                try {
                    chemin = jFileChooser.getSelectedFile().getName();
                    photoField.setText(chemin);
                    String phot = paths.recupererClientsPhotosPassportPath() + chemin;
                    String img = "<html><img alt=\"\" src=\"file:\\\\\\" + phot.toString() + "\"height='" + photoLab.getHeight() + "'" + " width='" + photoLab.getWidth() + "'/></html>";
                    photoLab.setText(img);
//				    photoLab.setIcon(new ImageIcon(jFileChooser.getSelectedFile().getPath(), jFileChooser.getSelectedFile().getName()));
                } catch (Exception e) {
                    photoLab.setText(null);
                }

                jDialog.dispose();
            }
        });
    }//GEN-LAST:event_photoButtonActionPerformed

    private void gererCategorieClientButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gererCategorieClientButtonActionPerformed
        // TODO add your handling code here:
        JDialog jDialogCategorieClient = new JDialog(gui, true);
        jDialogCategorieClient.setSize(600, 400);
        jDialogCategorieClient.setBackground(Color.WHITE);
        jDialogCategorieClient.setResizable(Boolean.FALSE);
        jDialogCategorieClient.setLocationRelativeTo(gui);
        jDialogCategorieClient.setLayout(new BorderLayout());
        jDialogCategorieClient.add(new CategorieClientView(), BorderLayout.CENTER);
        jDialogCategorieClient.setVisible(Boolean.TRUE);
    }//GEN-LAST:event_gererCategorieClientButtonActionPerformed

    private void gererCarteFideliteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gererCarteFideliteActionPerformed
        // TODO add your handling code here:
        saveButtonActionPerformed(null);
        JDialog jDialogCarteFidelite = new JDialog(gui, true);
        jDialogCarteFidelite.setSize(600, 400);
        jDialogCarteFidelite.setBackground(Color.WHITE);
        jDialogCarteFidelite.setResizable(Boolean.FALSE);
        jDialogCarteFidelite.setLocationRelativeTo(gui);
        jDialogCarteFidelite.setLayout(new BorderLayout());
        jDialogCarteFidelite.add(new CarteFideliteView(), BorderLayout.CENTER);
        jDialogCarteFidelite.setVisible(Boolean.TRUE);
    }//GEN-LAST:event_gererCarteFideliteActionPerformed

    private void cmbPaysResidenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPaysResidenceActionPerformed
        // TODO add your handling code here:
        try {
            paysResidenceField.setText(cmbPaysResidence.getSelectedItem().toString());
            cmbNationalite.setSelectedItem(cmbPaysResidence.getSelectedItem());
        } catch (Exception e) {
            cmbNationalite.setSelectedItem(null);
        }
    }//GEN-LAST:event_cmbPaysResidenceActionPerformed

    private void actualiserCmbPaysResidenceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualiserCmbPaysResidenceButtonActionPerformed
        // TODO add your handling code here:
        remplirCmbPaysResidence();
    }//GEN-LAST:event_actualiserCmbPaysResidenceButtonActionPerformed

    private void actualiserCmbNationaliteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualiserCmbNationaliteButtonActionPerformed
        // TODO add your handling code here:
        remplirCmbNationalite();
    }//GEN-LAST:event_actualiserCmbNationaliteButtonActionPerformed

    private void cmbSexeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSexeActionPerformed
        // TODO add your handling code here:
        try {
            sexeField.setText(cmbSexe.getSelectedItem().toString());
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cmbSexeActionPerformed

    private void cmbNationaliteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbNationaliteActionPerformed
        // TODO add your handling code here:
        try {
            if (cmbNationalite.getSelectedIndex() != 0) {
                nationaliteField.setText(cmbNationalite.getSelectedItem().toString());
                Pays pays = hotel.listerPaysParNom(cmbNationalite.getSelectedItem().toString());
                drapeauLab.setIcon(new ImageIcon(getClass().getResource("/hotelpro/resources/flags/" + pays.getCheminDrapeau())));
                paysResidenceField.setText(cmbNationalite.getSelectedItem().toString());
            } else {
                drapeauLab.setIcon(null);
            }
        } catch (Exception e) {
            drapeauLab.setIcon(null);
        }
    }//GEN-LAST:event_cmbNationaliteActionPerformed

    private void cmbCategorieClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategorieClientActionPerformed
        // TODO add your handling code here:
        try {
            CategorieClient categorieClient = hotel.listerCategorieClientParDesignation(cmbCategorieClient.getSelectedItem().toString());
            categorieClientField.setText(String.valueOf(categorieClient.getId()));
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cmbCategorieClientActionPerformed

    private void listeClientsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listeClientsButtonActionPerformed
        // TODO add your handling code here:
        Hotel.refreshEntitiesClient();
        List<Client> listClients = hotel.listerClientsOrderByNomAsc();
        rechercherPanel = new RechercherPanel(gui, cardLayout, this, clientViewString, listClients);
        gui.getjPanel3().add(rechercherPanel, rechercherPanelString);
        cardLayout.show(gui.getjPanel3(), rechercherPanelString);
    }//GEN-LAST:event_listeClientsButtonActionPerformed

    private void cmbCarteFideliteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCarteFideliteActionPerformed
        // TODO add your handling code here:
        if (cmbCarteFidelite.getSelectedIndex() == 0) {
            carteFideliteField.setText("false"); 
       } else {
            carteFideliteField.setText("true"); 
        }
    }//GEN-LAST:event_cmbCarteFideliteActionPerformed

    private void rechercheClientsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rechercheClientsButtonActionPerformed
        // TODO add your handling code here:
        rechercheClients = new RechercheClients(gui, cardLayout, this, clientViewString);
        gui.getjPanel3().add(rechercheClients, rechercheClientsString);
        cardLayout.show(gui.getjPanel3(), rechercheClientsString);
    }//GEN-LAST:event_rechercheClientsButtonActionPerformed

    private void plusChampsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plusChampsButtonActionPerformed
        // TODO add your handling code here:
        fixePersoLabel.setVisible(Boolean.TRUE);
        fixePersoField.setVisible(Boolean.TRUE);
        fixeProLabel.setVisible(Boolean.TRUE);
        fixeProField.setVisible(Boolean.TRUE);
        faxLabel.setVisible(Boolean.TRUE);
        faxField.setVisible(Boolean.TRUE);
        idCardLabel.setVisible(Boolean.TRUE);
        idCardField.setVisible(Boolean.TRUE);
        passeportLabel.setVisible(Boolean.TRUE);
        passeportField.setVisible(Boolean.TRUE);
        emailLabel.setVisible(Boolean.TRUE);
        emailField.setVisible(Boolean.TRUE);
        websiteLabel.setVisible(Boolean.TRUE);
        websiteField.setVisible(Boolean.TRUE);
        professionLabel.setVisible(Boolean.TRUE);
        professionField.setVisible(Boolean.TRUE);
        societeLabel.setVisible(Boolean.TRUE);
        societeField.setVisible(Boolean.TRUE);
        religionLabel.setVisible(Boolean.TRUE);
        religionField.setVisible(Boolean.TRUE);
        adressePersoLabel.setVisible(Boolean.TRUE);
        adressePersoField.setVisible(Boolean.TRUE);
        adresseProLabel.setVisible(Boolean.TRUE);
        adresseProField.setVisible(Boolean.TRUE);
        mobilePersoLabel.setVisible(Boolean.TRUE);
        mobilePersoField.setVisible(Boolean.TRUE);
        mobileProLabel.setVisible(Boolean.TRUE);
        mobileProField.setVisible(Boolean.TRUE);
        surnomLabel.setVisible(Boolean.TRUE);
        surnomField.setVisible(Boolean.TRUE);
        butVisiteLabel.setVisible(Boolean.TRUE);
        butVisiteField.setVisible(Boolean.TRUE);
        
        plusChampsButton.setVisible(Boolean.FALSE);
    }//GEN-LAST:event_plusChampsButtonActionPerformed

    private void plusChampsFalse() {
        fixePersoLabel.setVisible(Boolean.FALSE);
        fixePersoField.setVisible(Boolean.FALSE);
        fixeProLabel.setVisible(Boolean.FALSE);
        fixeProField.setVisible(Boolean.FALSE);
        faxLabel.setVisible(Boolean.FALSE);
        faxField.setVisible(Boolean.FALSE);
        idCardLabel.setVisible(Boolean.FALSE);
        idCardField.setVisible(Boolean.FALSE);
        passeportLabel.setVisible(Boolean.FALSE);
        passeportField.setVisible(Boolean.FALSE);
        emailLabel.setVisible(Boolean.FALSE);
        emailField.setVisible(Boolean.FALSE);
        websiteLabel.setVisible(Boolean.FALSE);
        websiteField.setVisible(Boolean.FALSE);
        professionLabel.setVisible(Boolean.FALSE);
        professionField.setVisible(Boolean.FALSE);
        societeLabel.setVisible(Boolean.FALSE);
        societeField.setVisible(Boolean.FALSE);
        religionLabel.setVisible(Boolean.FALSE);
        religionField.setVisible(Boolean.FALSE);
        adressePersoLabel.setVisible(Boolean.FALSE);
        adressePersoField.setVisible(Boolean.FALSE);
        adresseProLabel.setVisible(Boolean.FALSE);
        adresseProField.setVisible(Boolean.FALSE);
        mobilePersoLabel.setVisible(Boolean.FALSE);
        mobilePersoField.setVisible(Boolean.FALSE);
        mobileProLabel.setVisible(Boolean.FALSE);
        mobileProField.setVisible(Boolean.FALSE);
        surnomLabel.setVisible(Boolean.FALSE);
        surnomField.setVisible(Boolean.FALSE);
        butVisiteLabel.setVisible(Boolean.FALSE);
        butVisiteField.setVisible(Boolean.FALSE);
        
        plusChampsButton.setVisible(Boolean.TRUE);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualiserCmbCatClient;
    private javax.swing.JButton actualiserCmbNationaliteButton;
    private javax.swing.JButton actualiserCmbPaysResidenceButton;
    private javax.swing.JButton actualiserCmbRechercheCatButton;
    private javax.swing.JTextField adressePersoField;
    private javax.swing.JLabel adressePersoLabel;
    private javax.swing.JTextField adresseProField;
    private javax.swing.JLabel adresseProLabel;
    private javax.swing.JTextField ageField;
    private javax.swing.JLabel ageLabel;
    private javax.swing.JTextField butVisiteField;
    private javax.swing.JLabel butVisiteLabel;
    private javax.swing.JTextField carteFideliteField;
    private javax.swing.JLabel carteFideliteLabel;
    private javax.swing.JTextField categorieClientField;
    private javax.swing.JLabel categorieClientLabel;
    private javax.swing.JComboBox cmbCarteFidelite;
    private javax.swing.JComboBox cmbCategorieClient;
    private javax.swing.JComboBox cmbCritere;
    private javax.swing.JComboBox cmbNationalite;
    private javax.swing.JComboBox cmbPaysResidence;
    private javax.swing.JComboBox cmbRecherche;
    private javax.swing.JComboBox cmbRechercheCat;
    private javax.swing.JComboBox cmbSexe;
    private javax.swing.JButton deleteButton;
    private javax.swing.JLabel drapeauLab;
    private javax.swing.JTextField emailField;
    private javax.swing.JLabel emailLabel;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JTextField faxField;
    private javax.swing.JLabel faxLabel;
    private javax.swing.JTextField fixePersoField;
    private javax.swing.JLabel fixePersoLabel;
    private javax.swing.JTextField fixeProField;
    private javax.swing.JLabel fixeProLabel;
    private javax.swing.JButton gererCarteFidelite;
    private javax.swing.JButton gererCategorieClientButton;
    private javax.swing.JTextField idCardField;
    private javax.swing.JLabel idCardLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private java.util.List<hotelpro.entities.Client> list;
    private javax.swing.JButton listeClientsButton;
    private javax.swing.JScrollPane masterScrollPane;
    private javax.swing.JTable masterTable;
    private javax.swing.JTextField mobilePersoField;
    private javax.swing.JLabel mobilePersoLabel;
    private javax.swing.JTextField mobileProField;
    private javax.swing.JLabel mobileProLabel;
    private javax.swing.JTextField nationaliteField;
    private javax.swing.JLabel nationaliteLabel;
    private javax.swing.JButton newButton;
    private javax.swing.JTextField nomField;
    private javax.swing.JLabel nomLabel;
    private javax.swing.JTextField passeportField;
    private javax.swing.JLabel passeportLabel;
    private javax.swing.JTextField paysResidenceField;
    private javax.swing.JLabel paysResidenceLabel;
    private javax.swing.JButton photoButton;
    private javax.swing.JTextField photoField;
    private javax.swing.JTextField photoGrandFormatField;
    private javax.swing.JLabel photoGrandFormatLabel;
    private javax.swing.JLabel photoLab;
    private javax.swing.JLabel photoLabel;
    private javax.swing.JButton plusChampsButton;
    private javax.swing.JTextField prenomsField;
    private javax.swing.JLabel prenomsLabel;
    private javax.swing.JTextField professionField;
    private javax.swing.JLabel professionLabel;
    private javax.persistence.Query query;
    private javax.swing.JButton rechercheClientsButton;
    private javax.swing.JButton rechercherButton;
    private javax.swing.JButton refreshButton;
    private javax.swing.JTextField religionField;
    private javax.swing.JLabel religionLabel;
    private javax.swing.JButton saveButton;
    private javax.swing.JTextField sexeField;
    private javax.swing.JLabel sexeLabel;
    private javax.swing.JTextField societeField;
    private javax.swing.JLabel societeLabel;
    private javax.swing.JTextField surnomField;
    private javax.swing.JLabel surnomLabel;
    private javax.swing.JTextField websiteField;
    private javax.swing.JLabel websiteLabel;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

    public static void main(String[] args) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame();
                frame.setContentPane(new ClientView());
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }
    
    private void setVisibleFalseRechercherPanel() {
        jLabel1.setVisible(Boolean.FALSE);
        cmbRechercheCat.setVisible(Boolean.FALSE);
        actualiserCmbRechercheCatButton.setVisible(Boolean.FALSE);
        cmbCritere.setVisible(Boolean.FALSE);
        jLabel2.setVisible(Boolean.FALSE);
        cmbRecherche.setVisible(Boolean.FALSE);
        rechercherButton.setVisible(Boolean.FALSE);
        listeClientsButton.setVisible(Boolean.FALSE);
    }
    
    
    private void remplirCmbCatClient() {
        List<CategorieClient> listCategoriesClient = hotel.listerCategoriesClientOrderByDesignationASC();
        cmbCategorieClient.removeAllItems();
        cmbCategorieClient.addItem(libelleIndex0CmbCat);
        for (Iterator<CategorieClient> it = listCategoriesClient.iterator(); it.hasNext();) {
            CategorieClient categorieClient = it.next();
            cmbCategorieClient.addItem(categorieClient.getDesignation());
        }
    }

    private void remplirCmbRechercheCat() {
        List<CategorieClient> listCategoriesClient = hotel.listerCategoriesClientOrderByDesignationASC();
        cmbRechercheCat.removeAllItems();
        cmbRechercheCat.addItem(libelleIndex0CmbCat);
        for (Iterator<CategorieClient> it = listCategoriesClient.iterator(); it.hasNext();) {
            CategorieClient categorieClient = it.next();
            cmbRechercheCat.addItem(categorieClient.getDesignation());
        }
    }

    private void remplirCmbNationalite() {
        List<Pays> listPays = hotel.listerPays();
        cmbNationalite.removeAllItems();
        cmbNationalite.addItem("---Choisissez le pays ici---");
        try {
            for (Pays p : listPays) {
                cmbNationalite.addItem(p.getNom());
            }
        } catch (Exception e) {
        }
        cmbNationalite.setSelectedItem(null);
    }

    private void remplirCmbPaysResidence() {
        List<Pays> listPays = hotel.listerPays();
        cmbPaysResidence.removeAllItems();
        cmbPaysResidence.addItem("---Choisissez le pays ici---");
        try {
            for (Pays p : listPays) {
                cmbPaysResidence.addItem(p.getNom());
            }
        } catch (Exception e) {
        }
        cmbPaysResidence.setSelectedItem(null);
    }

    public JComboBox getCmbNationalite() {
        return cmbNationalite;
    }

    public void setCmbNationalite(JComboBox cmbNationalite) {
        this.cmbNationalite = cmbNationalite;
    }

    public JComboBox getCmbPaysResidence() {
        return cmbPaysResidence;
    }

    public void setCmbPaysResidence(JComboBox cmbPaysResidence) {
        this.cmbPaysResidence = cmbPaysResidence;
    }

    public JComboBox getCmbSexe() {
        return cmbSexe;
    }

    public void setCmbSexe(JComboBox cmbSexe) {
        this.cmbSexe = cmbSexe;
    }

    public JComboBox getCmbCategorieClient() {
        return cmbCategorieClient;
    }

    public void setCmbCategorieClient(JComboBox cmbCategorieClient) {
        this.cmbCategorieClient = cmbCategorieClient;
    }

    public JTable getMasterTable() {
        return masterTable;
    }

    public void setMasterTable(JTable masterTable) {
        this.masterTable = masterTable;
    }

    public JComboBox getCmbCarteFidelite() {
        return cmbCarteFidelite;
    }

    public void setCmbCarteFidelite(JComboBox cmbCarteFidelite) {
        this.cmbCarteFidelite = cmbCarteFidelite;
    }

    public JLabel getDrapeauLab() {
        return drapeauLab;
    }

    public void setDrapeauLab(JLabel drapeauLab) {
        this.drapeauLab = drapeauLab;
    }

    public JLabel getPhotoLab() {
        return photoLab;
    }

    public void setPhotoLab(JLabel photoLab) {
        this.photoLab = photoLab;
    }

    public JTextField getCarteFideliteField() {
        return carteFideliteField;
    }

    public void setCarteFideliteField(JTextField carteFideliteField) {
        this.carteFideliteField = carteFideliteField;
    }
}
