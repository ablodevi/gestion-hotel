/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.mail;

import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Serge
 */
public class TestMail {

    private final static String MAILER_VERSION = "Java";

    public static boolean envoyerMailSMTP(String serveur, boolean debug) {

        boolean result = false;

        try {

            Properties prop = System.getProperties();

            prop.put("mail.smtp.host", serveur);

            Session session = Session.getDefaultInstance(prop, null);

            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress("serge.uchiha@gmail.com"));

            InternetAddress[] internetAddresses = new InternetAddress[1];

            internetAddresses[0] = new InternetAddress("serge.uchiha@gmail.com");

            message.setRecipients(Message.RecipientType.TO, internetAddresses);

            message.setSubject("Test");

            message.setText("test mail");

            message.setHeader("X-Mailer", MAILER_VERSION);

            message.setSentDate(new Date());

            session.setDebug(debug);

            Transport.send(message);

            result = true;

        } catch (AddressException e) {

            e.printStackTrace();

        } catch (MessagingException e) {

            e.printStackTrace();

        }

        return result;

    }

    public static void main(String[] args) {
        TestMail.envoyerMailSMTP("10.10.50.8", true);
    }
}
