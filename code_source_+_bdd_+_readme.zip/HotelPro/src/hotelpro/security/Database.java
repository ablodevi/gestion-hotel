/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.security;

import hotelpro.utils.Hotel;
import hotelpro.utils.Paths;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Serge
 */
public class Database {

    Paths paths = new Paths();
    ParametresConnexion parametresConnexion = new ParametresConnexion();
    
    public Database() {
    }

    public void createDB() {
        try {
            Connection conn = null;
            Statement stmt;

            // Ce constructeur crée la base de données MaBase et toutes ses tables dès la premiere connexion si elle n'existe pas
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
//            System.out.println("impossible de charger le pilote");
            }
            try {
                conn = DriverManager.getConnection(parametresConnexion.recupererUrl() + parametresConnexion.recupererDbName(),
                        parametresConnexion.recupererDbUserName(), parametresConnexion.recupererDbPassword());
            } catch (SQLException ek) {
//            System.out.println("base inexistante: création de la bd hotel");
                try {
                    try {
                        conn = DriverManager.getConnection(parametresConnexion.recupererUrl() + parametresConnexion.recupererMySqlDb(),
                                parametresConnexion.recupererDbUserName(), parametresConnexion.recupererDbPassword());
                    } catch (SQLException eh) {
                    }

                    stmt = conn.createStatement();
                    int nbre = stmt.executeUpdate("create database " + parametresConnexion.recupererDbName());
                    stmt.close();
                    conn.close();
                } catch (SQLException ed) {
//                System.out.println("impossible de creer hotel");
                }
                try {
                    conn = DriverManager.getConnection(parametresConnexion.recupererUrl() + parametresConnexion.recupererDbName(),
                            parametresConnexion.recupererDbUserName(), parametresConnexion.recupererDbPassword());
//                System.out.println(" connexion à hotel reussi");
                } catch (SQLException ef) {
//                System.out.println("impossible de se connecter à hotel");
                }

//            System.out.println("BASE DÉJÀ EXISTANTE");

//                Database database = new Database();
//                database.restoreDB(Database.dbUserName, Database.dbPassword, database.provideDefaultDatabasePath());

            }
            try {
                conn.close();
            } catch (SQLException v) {
            }
        } catch (Exception e) {
        }
    }

    public String providePath() {
        File file = new File(paths.recupererDataBaseFilesPath() + new java.sql.Date(new java.util.Date().getTime()).toString());
        file.mkdir();
        String path = file.getPath() + File.separator;
        path = "\"" + path.replace(File.separatorChar, '/') + "hotel_" + Hotel.returnNow().replace(':', '_') + ".sql" + "\"";
        return path;
    }

    public String pathToBackupPath(String directoryPath) {
        directoryPath += File.separator;
        directoryPath = "\"" + directoryPath.replace(File.separatorChar, '/') + "hotel_" + Hotel.returnNow().replace(':', '_') + ".sql" + "\"";
        return directoryPath;
    }

    public String provideDefaultDatabasePath() {
        String path = getClass().getResource("/hotelpro/resources/database/hotel.sql").getPath();
        return "\"" + (path.replaceFirst("/", "")).replace(File.separatorChar, '/') + "\"";
    }

    public boolean backupDB(String dbName, String dbUserName, String dbPassword, String path) {

        try {
            String executeCmd = "mysqldump -u " + dbUserName + " -p" + dbPassword + " --add-drop-database -B " + dbName + " -r " + path;
            Process runtimeProcess;
            try {

                runtimeProcess = Runtime.getRuntime().exec(executeCmd);
                int processComplete = runtimeProcess.waitFor();

                if (processComplete == 0) {
//                System.out.println("Backup created successfully");
                    return true;
                } else {
//                System.out.println("Could not create the backup");
                }
            } catch (IOException | InterruptedException ex) {
            }
        } catch (Exception e) {
        }
        return false;
    }

    public boolean restoreDB(String dbUserName, String dbPassword, String source) {
        try {
            String[] executeCmd = new String[]{"mysql", "--user=" + dbUserName, "--password=" + dbPassword, "-e", "source " + source};

            Process runtimeProcess;
            try {

                runtimeProcess = Runtime.getRuntime().exec(executeCmd);
                int processComplete = runtimeProcess.waitFor();

                if (processComplete == 0) {
//                System.out.println("Backup restored successfully");
                    return true;
                } else {
//                System.out.println("Could not restore the backup");
                }
            } catch (IOException | InterruptedException ex) {
            }
        } catch (Exception e) {
        }
        return false;
    }

    public void dropDB(String driverName, String url, String dbName, String dbUserName, String dbPassword) {
        // create Connection con, and Statement stmt 
        try {
            Connection con;
            Statement stmt;
            try {
                Class.forName(driverName).newInstance();
                con = DriverManager.getConnection(url + dbName, dbUserName, dbPassword);
                try {
                    stmt = con.createStatement();
                    String query = "DROP DATABASE hotel";
                    stmt.executeUpdate(query);
//                System.out.println("DATABASE deleted successfully...");
                } catch (SQLException s) {
//                System.out.println("Database not deleted ");
                }
                // close Connection
                con.close();
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException e) {
            }
        } catch (Exception e) {
        }
    }
}
