/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.security;

import hotelpro.entities.Mac;
import hotelpro.entities.MacOk;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.RollbackException;

/**
 *
 * @author Serge
 */
public class MacAddress {

    public MacAddress() {
    }
    
    public List<Mac> listerMacs() {
        List<Mac> list = null;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            Query query = em.createQuery("SELECT m FROM Mac m");
            list = query.getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }
    
    public List<MacOk> listerMacOk() {
        List<MacOk> list = null;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            Query query = em.createQuery("SELECT m FROM MacOk m");
            list = query.getResultList();
            em.close();
            emf.close();
        } catch (Exception e) {
        }
        return list;
    }
    
    public Mac listerMacParAdresse (String mac) {
        List<Mac> list = new MacAddress().listerMacs();
        try {
            for (Mac m : list) {
                if (m.getAddresse().equals(mac)) {
                    return m;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }
    
    public void majMac(Mac mac) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Mac> listMacs = new MacAddress().listerMacs();
        em.persist(mac);
        listMacs.add(mac);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<Mac> merged = new ArrayList<>(listMacs.size());
            for (Mac m : listMacs) {
                merged.add(em.merge(m));
            }
            listMacs.clear();
            listMacs.addAll(merged);
        }
    }
    
    public void majMacOk(MacOk macOk) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<MacOk> listMacOks = new MacAddress().listerMacOk();
        em.persist(macOk);
        listMacOks.add(macOk);
        try {
            em.getTransaction().commit();
            em.getTransaction().begin();
        } catch (RollbackException rollbackException) {
            em.getTransaction().begin();
            List<MacOk> merged = new ArrayList<>(listMacOks.size());
            for (MacOk m : listMacOks) {
                merged.add(em.merge(m));
            }
            listMacOks.clear();
            listMacOks.addAll(merged);
        }
    }
    
    public MacOk listerMacOkInDb(Mac mac) {
        MacAddress macAddress = new MacAddress();
        MacOk macOk = null;
        try {
            int maxIdMacOkParMac = 0;
            try {
                maxIdMacOkParMac = (int) Integer.parseInt(String.valueOf(macAddress.listerMaxIdMacOk(mac)));
            } catch (NumberFormatException numberFormatException) {
            }
            macOk = macAddress.listerMacOkParId(maxIdMacOkParMac);
        } catch (Exception e) {
        }
        return macOk;
    }
    
    public MacOk listerMacOkParId(int id) {
        try {
            List<MacOk> listMacOks = new MacAddress().listerMacOk();
            for (MacOk macOk : listMacOks) {
                if ((int) macOk.getId() == id) {
                    return macOk;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }
    
    public long listerMaxIdMacOk(Mac mac) {
        Long res = Long.MIN_VALUE;
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("HotelProPU");
            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            Query query = em.createNativeQuery("SELECT MAX(m.id) FROM mac_ok m WHERE m.mac = " + mac.getId());
            res = (Long) query.getSingleResult();
            em.getTransaction().commit();
            em.close();
            emf.close();
        } catch (NumberFormatException numberFormatException) {
        } catch (Exception exception) {
        }
        if (res == null || res <= 0) {
            return 0;
        }
        return res;
    }
    
    public String getLocalMacAddress() throws IOException {
        Process p = Runtime.getRuntime().exec("getmac /fo csv /nh");
        java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(p.getInputStream()));
        String line;
        line = in.readLine();
        String[] result = line.split(",");

        return (result[0].replace('"', ' ').trim());
    }
}
