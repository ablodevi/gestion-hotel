/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.security;

/**
 *
 * @author Serge
 */
public class ParametresConnexion {

    public ParametresConnexion() {
    }
    
    public String recupererDbName() {
        return "hotel";
    }
    
    public String recupererDbUserName() {
        return "root";
    }
    
    public String recupererDbPassword() {
        return "amaterasu";
    }
    
    public String recupererDriverName() {
        return "com.mysql.jdbc.Driver";
    }
    
    public String recupererUrl() {
        return "jdbc:mysql://localhost:3306/";
    }
    
    public String recupererMySqlDb() {
        return "mysql";
    }
}
