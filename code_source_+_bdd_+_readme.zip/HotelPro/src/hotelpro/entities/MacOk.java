/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "mac_ok")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MacOk.findAll", query = "SELECT m FROM MacOk m"),
    @NamedQuery(name = "MacOk.findById", query = "SELECT m FROM MacOk m WHERE m.id = :id"),
    @NamedQuery(name = "MacOk.findByMac", query = "SELECT m FROM MacOk m WHERE m.mac = :mac"),
    @NamedQuery(name = "MacOk.findByOk", query = "SELECT m FROM MacOk m WHERE m.ok = :ok"),
    @NamedQuery(name = "MacOk.findByNb", query = "SELECT m FROM MacOk m WHERE m.nb = :nb"),
    @NamedQuery(name = "MacOk.findByDateHeure", query = "SELECT m FROM MacOk m WHERE m.dateHeure = :dateHeure"),
    @NamedQuery(name = "MacOk.findByCle", query = "SELECT m FROM MacOk m WHERE m.cle = :cle")})
public class MacOk implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "mac")
    private int mac;
    @Basic(optional = false)
    @Column(name = "ok")
    private boolean ok;
    @Basic(optional = false)
    @Column(name = "nb")
    private int nb;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "cle")
    private String cle;

    public MacOk() {
    }

    public MacOk(Integer id) {
        this.id = id;
    }

    public MacOk(Integer id, int mac, boolean ok, int nb, String dateHeure, String cle) {
        this.id = id;
        this.mac = mac;
        this.ok = ok;
        this.nb = nb;
        this.dateHeure = dateHeure;
        this.cle = cle;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getMac() {
        return mac;
    }

    public void setMac(int mac) {
        this.mac = mac;
    }

    public boolean getOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public int getNb() {
        return nb;
    }

    public void setNb(int nb) {
        this.nb = nb;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getCle() {
        return cle;
    }

    public void setCle(String cle) {
        this.cle = cle;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MacOk)) {
            return false;
        }
        MacOk other = (MacOk) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.MacOk[ id=" + id + " ]";
    }
    
}
