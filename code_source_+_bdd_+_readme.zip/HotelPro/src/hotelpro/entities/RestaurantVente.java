/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "restaurant_vente")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "RestaurantVente.findAll", query = "SELECT r FROM RestaurantVente r"),
    @NamedQuery(name = "RestaurantVente.findById", query = "SELECT r FROM RestaurantVente r WHERE r.id = :id"),
    @NamedQuery(name = "RestaurantVente.findByMenu", query = "SELECT r FROM RestaurantVente r WHERE r.menu = :menu"),
    @NamedQuery(name = "RestaurantVente.findByNombre", query = "SELECT r FROM RestaurantVente r WHERE r.nombre = :nombre"),
    @NamedQuery(name = "RestaurantVente.findByCout", query = "SELECT r FROM RestaurantVente r WHERE r.cout = :cout"),
    @NamedQuery(name = "RestaurantVente.findByPaye", query = "SELECT r FROM RestaurantVente r WHERE r.paye = :paye"),
    @NamedQuery(name = "RestaurantVente.findByReservation", query = "SELECT r FROM RestaurantVente r WHERE r.reservation = :reservation"),
    @NamedQuery(name = "RestaurantVente.findByServeur", query = "SELECT r FROM RestaurantVente r WHERE r.serveur = :serveur"),
    @NamedQuery(name = "RestaurantVente.findByRestaurant", query = "SELECT r FROM RestaurantVente r WHERE r.restaurant = :restaurant"),
    @NamedQuery(name = "RestaurantVente.findByDateHeure", query = "SELECT r FROM RestaurantVente r WHERE r.dateHeure = :dateHeure"),
    @NamedQuery(name = "RestaurantVente.findByLogin", query = "SELECT r FROM RestaurantVente r WHERE r.login = :login"),
    @NamedQuery(name = "RestaurantVente.findByTableId", query = "SELECT r FROM RestaurantVente r WHERE r.tableId = :tableId"),
    @NamedQuery(name = "RestaurantVente.findByCloture", query = "SELECT r FROM RestaurantVente r WHERE r.cloture = :cloture"),
    @NamedQuery(name = "RestaurantVente.findByDateFacture", query = "SELECT r FROM RestaurantVente r WHERE r.dateFacture = :dateFacture"),
    @NamedQuery(name = "RestaurantVente.findByNumFacture", query = "SELECT r FROM RestaurantVente r WHERE r.numFacture = :numFacture")})
public class RestaurantVente implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "menu")
    private int menu;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "cout")
    private String cout;
    @Column(name = "paye")
    private Boolean paye;
    @Column(name = "reservation")
    private Integer reservation;
    @Column(name = "serveur")
    private Integer serveur;
    @Basic(optional = false)
    @Column(name = "restaurant")
    private int restaurant;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;
    @Column(name = "table_id")
    private Integer tableId;
    @Column(name = "cloture")
    private Boolean cloture;
    @Column(name = "date_facture")
    private String dateFacture;
    @Column(name = "num_facture")
    private String numFacture;

    public RestaurantVente() {
    }

    public RestaurantVente(Integer id) {
        this.id = id;
    }

    public RestaurantVente(Integer id, int menu, String nombre, String cout, int restaurant, String dateHeure, String login) {
        this.id = id;
        this.menu = menu;
        this.nombre = nombre;
        this.cout = cout;
        this.restaurant = restaurant;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getMenu() {
        return menu;
    }

    public void setMenu(int menu) {
        this.menu = menu;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    public Boolean getPaye() {
        return paye;
    }

    public void setPaye(Boolean paye) {
        this.paye = paye;
    }

    public Integer getReservation() {
        return reservation;
    }

    public void setReservation(Integer reservation) {
        this.reservation = reservation;
    }

    public Integer getServeur() {
        return serveur;
    }

    public void setServeur(Integer serveur) {
        this.serveur = serveur;
    }

    public int getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(int restaurant) {
        this.restaurant = restaurant;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Integer getTableId() {
        return tableId;
    }

    public void setTableId(Integer tableId) {
        this.tableId = tableId;
    }

    public Boolean getCloture() {
        return cloture;
    }

    public void setCloture(Boolean cloture) {
        this.cloture = cloture;
    }

    public String getDateFacture() {
        return dateFacture;
    }

    public void setDateFacture(String dateFacture) {
        this.dateFacture = dateFacture;
    }

    public String getNumFacture() {
        return numFacture;
    }

    public void setNumFacture(String numFacture) {
        this.numFacture = numFacture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RestaurantVente)) {
            return false;
        }
        RestaurantVente other = (RestaurantVente) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.RestaurantVente[ id=" + id + " ]";
    }
    
}
