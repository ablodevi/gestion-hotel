/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "penalite")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Penalite.findAll", query = "SELECT p FROM Penalite p"),
    @NamedQuery(name = "Penalite.findById", query = "SELECT p FROM Penalite p WHERE p.id = :id"),
    @NamedQuery(name = "Penalite.findByLibelle", query = "SELECT p FROM Penalite p WHERE p.libelle = :libelle"),
    @NamedQuery(name = "Penalite.findByCout", query = "SELECT p FROM Penalite p WHERE p.cout = :cout"),
    @NamedQuery(name = "Penalite.findByReservation", query = "SELECT p FROM Penalite p WHERE p.reservation = :reservation")})
public class Penalite implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "libelle")
    private String libelle;
    @Column(name = "cout")
    private String cout;
    @Column(name = "reservation")
    private Integer reservation;

    public Penalite() {
    }

    public Penalite(Integer id) {
        this.id = id;
    }

    public Penalite(Integer id, String libelle) {
        this.id = id;
        this.libelle = libelle;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    public Integer getReservation() {
        return reservation;
    }

    public void setReservation(Integer reservation) {
        this.reservation = reservation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Penalite)) {
            return false;
        }
        Penalite other = (Penalite) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Penalite[ id=" + id + " ]";
    }
    
}
