/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "bar_vente")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BarVente.findAll", query = "SELECT b FROM BarVente b"),
    @NamedQuery(name = "BarVente.findById", query = "SELECT b FROM BarVente b WHERE b.id = :id"),
    @NamedQuery(name = "BarVente.findByBoisson", query = "SELECT b FROM BarVente b WHERE b.boisson = :boisson"),
    @NamedQuery(name = "BarVente.findByNombre", query = "SELECT b FROM BarVente b WHERE b.nombre = :nombre"),
    @NamedQuery(name = "BarVente.findByCout", query = "SELECT b FROM BarVente b WHERE b.cout = :cout"),
    @NamedQuery(name = "BarVente.findByPaye", query = "SELECT b FROM BarVente b WHERE b.paye = :paye"),
    @NamedQuery(name = "BarVente.findByReservation", query = "SELECT b FROM BarVente b WHERE b.reservation = :reservation"),
    @NamedQuery(name = "BarVente.findByServeur", query = "SELECT b FROM BarVente b WHERE b.serveur = :serveur"),
    @NamedQuery(name = "BarVente.findByBar", query = "SELECT b FROM BarVente b WHERE b.bar = :bar"),
    @NamedQuery(name = "BarVente.findByDateHeure", query = "SELECT b FROM BarVente b WHERE b.dateHeure = :dateHeure"),
    @NamedQuery(name = "BarVente.findByLogin", query = "SELECT b FROM BarVente b WHERE b.login = :login"),
    @NamedQuery(name = "BarVente.findByTableId", query = "SELECT b FROM BarVente b WHERE b.tableId = :tableId"),
    @NamedQuery(name = "BarVente.findByCloture", query = "SELECT b FROM BarVente b WHERE b.cloture = :cloture"),
    @NamedQuery(name = "BarVente.findByDateFacture", query = "SELECT b FROM BarVente b WHERE b.dateFacture = :dateFacture"),
    @NamedQuery(name = "BarVente.findByNumFacture", query = "SELECT b FROM BarVente b WHERE b.numFacture = :numFacture")})
public class BarVente implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "boisson")
    private int boisson;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "cout")
    private String cout;
    @Column(name = "paye")
    private Boolean paye;
    @Column(name = "reservation")
    private Integer reservation;
    @Column(name = "serveur")
    private Integer serveur;
    @Basic(optional = false)
    @Column(name = "bar")
    private int bar;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;
    @Column(name = "table_id")
    private Integer tableId;
    @Column(name = "cloture")
    private Boolean cloture;
    @Column(name = "date_facture")
    private String dateFacture;
    @Column(name = "num_facture")
    private String numFacture;

    public BarVente() {
    }

    public BarVente(Integer id) {
        this.id = id;
    }

    public BarVente(Integer id, int boisson, String nombre, String cout, int bar, String dateHeure, String login) {
        this.id = id;
        this.boisson = boisson;
        this.nombre = nombre;
        this.cout = cout;
        this.bar = bar;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getBoisson() {
        return boisson;
    }

    public void setBoisson(int boisson) {
        this.boisson = boisson;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    public Boolean getPaye() {
        return paye;
    }

    public void setPaye(Boolean paye) {
        this.paye = paye;
    }

    public Integer getReservation() {
        return reservation;
    }

    public void setReservation(Integer reservation) {
        this.reservation = reservation;
    }

    public Integer getServeur() {
        return serveur;
    }

    public void setServeur(Integer serveur) {
        this.serveur = serveur;
    }

    public int getBar() {
        return bar;
    }

    public void setBar(int bar) {
        this.bar = bar;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Integer getTableId() {
        return tableId;
    }

    public void setTableId(Integer tableId) {
        this.tableId = tableId;
    }

    public Boolean getCloture() {
        return cloture;
    }

    public void setCloture(Boolean cloture) {
        this.cloture = cloture;
    }

    public String getDateFacture() {
        return dateFacture;
    }

    public void setDateFacture(String dateFacture) {
        this.dateFacture = dateFacture;
    }

    public String getNumFacture() {
        return numFacture;
    }

    public void setNumFacture(String numFacture) {
        this.numFacture = numFacture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BarVente)) {
            return false;
        }
        BarVente other = (BarVente) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.BarVente[ id=" + id + " ]";
    }
    
}
