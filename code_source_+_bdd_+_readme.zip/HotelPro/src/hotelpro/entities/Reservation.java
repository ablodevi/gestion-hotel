/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "reservation")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reservation.findAll", query = "SELECT r FROM Reservation r"),
    @NamedQuery(name = "Reservation.findById", query = "SELECT r FROM Reservation r WHERE r.id = :id"),
    @NamedQuery(name = "Reservation.findByChambre", query = "SELECT r FROM Reservation r WHERE r.chambre = :chambre"),
    @NamedQuery(name = "Reservation.findByDateReservation", query = "SELECT r FROM Reservation r WHERE r.dateReservation = :dateReservation"),
    @NamedQuery(name = "Reservation.findByDateArrivee", query = "SELECT r FROM Reservation r WHERE r.dateArrivee = :dateArrivee"),
    @NamedQuery(name = "Reservation.findByDateDepart", query = "SELECT r FROM Reservation r WHERE r.dateDepart = :dateDepart"),
    @NamedQuery(name = "Reservation.findByClient", query = "SELECT r FROM Reservation r WHERE r.client = :client"),
    @NamedQuery(name = "Reservation.findByEtatReservation", query = "SELECT r FROM Reservation r WHERE r.etatReservation = :etatReservation"),
    @NamedQuery(name = "Reservation.findByLogin", query = "SELECT r FROM Reservation r WHERE r.login = :login")})
public class Reservation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "chambre")
    private int chambre;
    @Basic(optional = false)
    @Column(name = "date_reservation")
    private String dateReservation;
    @Basic(optional = false)
    @Column(name = "date_arrivee")
    private String dateArrivee;
    @Basic(optional = false)
    @Column(name = "date_depart")
    private String dateDepart;
    @Column(name = "client")
    private Integer client;
    @Basic(optional = false)
    @Column(name = "etat_reservation")
    private String etatReservation;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public Reservation() {
    }

    public Reservation(Integer id) {
        this.id = id;
    }

    public Reservation(Integer id, int chambre, String dateReservation, String dateArrivee, String dateDepart, String etatReservation, String login) {
        this.id = id;
        this.chambre = chambre;
        this.dateReservation = dateReservation;
        this.dateArrivee = dateArrivee;
        this.dateDepart = dateDepart;
        this.etatReservation = etatReservation;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getChambre() {
        return chambre;
    }

    public void setChambre(int chambre) {
        this.chambre = chambre;
    }

    public String getDateReservation() {
        return dateReservation;
    }

    public void setDateReservation(String dateReservation) {
        this.dateReservation = dateReservation;
    }

    public String getDateArrivee() {
        return dateArrivee;
    }

    public void setDateArrivee(String dateArrivee) {
        this.dateArrivee = dateArrivee;
    }

    public String getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(String dateDepart) {
        this.dateDepart = dateDepart;
    }

    public Integer getClient() {
        return client;
    }

    public void setClient(Integer client) {
        this.client = client;
    }

    public String getEtatReservation() {
        return etatReservation;
    }

    public void setEtatReservation(String etatReservation) {
        this.etatReservation = etatReservation;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservation)) {
            return false;
        }
        Reservation other = (Reservation) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Reservation[ id=" + id + " ]";
    }
    
}
