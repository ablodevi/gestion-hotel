/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "etage")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Etage.findAll", query = "SELECT e FROM Etage e"),
    @NamedQuery(name = "Etage.findById", query = "SELECT e FROM Etage e WHERE e.id = :id"),
    @NamedQuery(name = "Etage.findByDesignation", query = "SELECT e FROM Etage e WHERE e.designation = :designation"),
    @NamedQuery(name = "Etage.findByBloc", query = "SELECT e FROM Etage e WHERE e.bloc = :bloc"),
    @NamedQuery(name = "Etage.findByDisponibilite", query = "SELECT e FROM Etage e WHERE e.disponibilite = :disponibilite")})
public class Etage implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "designation")
    private String designation;
    @Column(name = "bloc")
    private Integer bloc;
    @Column(name = "disponibilite")
    private Boolean disponibilite;

    public Etage() {
    }

    public Etage(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Integer getBloc() {
        return bloc;
    }

    public void setBloc(Integer bloc) {
        this.bloc = bloc;
    }

    public Boolean getDisponibilite() {
        return disponibilite;
    }

    public void setDisponibilite(Boolean disponibilite) {
        this.disponibilite = disponibilite;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Etage)) {
            return false;
        }
        Etage other = (Etage) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Etage[ id=" + id + " ]";
    }
    
}
