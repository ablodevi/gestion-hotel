/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "caracteristique_chambre")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CaracteristiqueChambre.findAll", query = "SELECT c FROM CaracteristiqueChambre c"),
    @NamedQuery(name = "CaracteristiqueChambre.findById", query = "SELECT c FROM CaracteristiqueChambre c WHERE c.id = :id"),
    @NamedQuery(name = "CaracteristiqueChambre.findByLibelle", query = "SELECT c FROM CaracteristiqueChambre c WHERE c.libelle = :libelle"),
    @NamedQuery(name = "CaracteristiqueChambre.findByCout", query = "SELECT c FROM CaracteristiqueChambre c WHERE c.cout = :cout")})
public class CaracteristiqueChambre implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "libelle")
    private String libelle;
    @Column(name = "cout")
    private String cout;

    public CaracteristiqueChambre() {
    }

    public CaracteristiqueChambre(Integer id) {
        this.id = id;
    }

    public CaracteristiqueChambre(Integer id, String libelle) {
        this.id = id;
        this.libelle = libelle;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaracteristiqueChambre)) {
            return false;
        }
        CaracteristiqueChambre other = (CaracteristiqueChambre) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CaracteristiqueChambre[ id=" + id + " ]";
    }
    
}
