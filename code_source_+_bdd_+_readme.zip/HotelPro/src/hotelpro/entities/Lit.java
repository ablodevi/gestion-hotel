/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "lit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Lit.findAll", query = "SELECT l FROM Lit l"),
    @NamedQuery(name = "Lit.findById", query = "SELECT l FROM Lit l WHERE l.id = :id"),
    @NamedQuery(name = "Lit.findByDesignation", query = "SELECT l FROM Lit l WHERE l.designation = :designation"),
    @NamedQuery(name = "Lit.findByChambre", query = "SELECT l FROM Lit l WHERE l.chambre = :chambre"),
    @NamedQuery(name = "Lit.findByDisponibilite", query = "SELECT l FROM Lit l WHERE l.disponibilite = :disponibilite"),
    @NamedQuery(name = "Lit.findByCategorieLit", query = "SELECT l FROM Lit l WHERE l.categorieLit = :categorieLit")})
public class Lit implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "designation")
    private String designation;
    @Basic(optional = false)
    @Column(name = "chambre")
    private int chambre;
    @Column(name = "disponibilite")
    private Boolean disponibilite;
    @Column(name = "categorie_lit")
    private Integer categorieLit;

    public Lit() {
    }

    public Lit(Integer id) {
        this.id = id;
    }

    public Lit(Integer id, String designation, int chambre) {
        this.id = id;
        this.designation = designation;
        this.chambre = chambre;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getChambre() {
        return chambre;
    }

    public void setChambre(int chambre) {
        this.chambre = chambre;
    }

    public Boolean getDisponibilite() {
        return disponibilite;
    }

    public void setDisponibilite(Boolean disponibilite) {
        this.disponibilite = disponibilite;
    }

    public Integer getCategorieLit() {
        return categorieLit;
    }

    public void setCategorieLit(Integer categorieLit) {
        this.categorieLit = categorieLit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Lit)) {
            return false;
        }
        Lit other = (Lit) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Lit[ id=" + id + " ]";
    }
    
}
