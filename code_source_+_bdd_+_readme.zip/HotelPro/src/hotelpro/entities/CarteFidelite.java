/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "carte_fidelite")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CarteFidelite.findAll", query = "SELECT c FROM CarteFidelite c"),
    @NamedQuery(name = "CarteFidelite.findById", query = "SELECT c FROM CarteFidelite c WHERE c.id = :id"),
    @NamedQuery(name = "CarteFidelite.findByClient", query = "SELECT c FROM CarteFidelite c WHERE c.client = :client"),
    @NamedQuery(name = "CarteFidelite.findByDesignation", query = "SELECT c FROM CarteFidelite c WHERE c.designation = :designation"),
    @NamedQuery(name = "CarteFidelite.findByDescription", query = "SELECT c FROM CarteFidelite c WHERE c.description = :description")})
public class CarteFidelite implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "client")
    private int client;
    @Column(name = "designation")
    private String designation;
    @Column(name = "description")
    private String description;

    public CarteFidelite() {
    }

    public CarteFidelite(Integer id) {
        this.id = id;
    }

    public CarteFidelite(Integer id, int client) {
        this.id = id;
        this.client = client;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getClient() {
        return client;
    }

    public void setClient(int client) {
        this.client = client;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CarteFidelite)) {
            return false;
        }
        CarteFidelite other = (CarteFidelite) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CarteFidelite[ id=" + id + " ]";
    }
    
}
