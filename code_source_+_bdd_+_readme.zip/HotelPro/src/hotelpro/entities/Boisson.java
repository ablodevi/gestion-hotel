/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "boisson")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Boisson.findAll", query = "SELECT b FROM Boisson b"),
    @NamedQuery(name = "Boisson.findById", query = "SELECT b FROM Boisson b WHERE b.id = :id"),
    @NamedQuery(name = "Boisson.findByLibelle", query = "SELECT b FROM Boisson b WHERE b.libelle = :libelle"),
    @NamedQuery(name = "Boisson.findByCout", query = "SELECT b FROM Boisson b WHERE b.cout = :cout"),
    @NamedQuery(name = "Boisson.findByCategorieBoisson", query = "SELECT b FROM Boisson b WHERE b.categorieBoisson = :categorieBoisson"),
    @NamedQuery(name = "Boisson.findByLogin", query = "SELECT b FROM Boisson b WHERE b.login = :login")})
public class Boisson implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "libelle")
    private String libelle;
    @Column(name = "cout")
    private String cout;
    @Column(name = "categorie_boisson")
    private Integer categorieBoisson;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public Boisson() {
    }

    public Boisson(Integer id) {
        this.id = id;
    }

    public Boisson(Integer id, String login) {
        this.id = id;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    public Integer getCategorieBoisson() {
        return categorieBoisson;
    }

    public void setCategorieBoisson(Integer categorieBoisson) {
        this.categorieBoisson = categorieBoisson;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Boisson)) {
            return false;
        }
        Boisson other = (Boisson) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Boisson[ id=" + id + " ]";
    }
    
}
