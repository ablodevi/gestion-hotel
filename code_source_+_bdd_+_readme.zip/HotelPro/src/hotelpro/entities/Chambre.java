/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "chambre")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Chambre.findAll", query = "SELECT c FROM Chambre c"),
    @NamedQuery(name = "Chambre.findById", query = "SELECT c FROM Chambre c WHERE c.id = :id"),
    @NamedQuery(name = "Chambre.findByDesignation", query = "SELECT c FROM Chambre c WHERE c.designation = :designation"),
    @NamedQuery(name = "Chambre.findByDescription", query = "SELECT c FROM Chambre c WHERE c.description = :description"),
    @NamedQuery(name = "Chambre.findByBloc", query = "SELECT c FROM Chambre c WHERE c.bloc = :bloc"),
    @NamedQuery(name = "Chambre.findByCategorie", query = "SELECT c FROM Chambre c WHERE c.categorie = :categorie"),
    @NamedQuery(name = "Chambre.findByDisponibilite", query = "SELECT c FROM Chambre c WHERE c.disponibilite = :disponibilite"),
    @NamedQuery(name = "Chambre.findByEtage", query = "SELECT c FROM Chambre c WHERE c.etage = :etage"),
    @NamedQuery(name = "Chambre.findByTypeChambre", query = "SELECT c FROM Chambre c WHERE c.typeChambre = :typeChambre"),
    @NamedQuery(name = "Chambre.findByCaracteristiqueChambre", query = "SELECT c FROM Chambre c WHERE c.caracteristiqueChambre = :caracteristiqueChambre"),
    @NamedQuery(name = "Chambre.findBySituationChambre", query = "SELECT c FROM Chambre c WHERE c.situationChambre = :situationChambre"),
    @NamedQuery(name = "Chambre.findByStatut", query = "SELECT c FROM Chambre c WHERE c.statut = :statut")})
public class Chambre implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "designation")
    private String designation;
    @Column(name = "description")
    private String description;
    @Column(name = "bloc")
    private Integer bloc;
    @Column(name = "categorie")
    private Integer categorie;
    @Column(name = "disponibilite")
    private Boolean disponibilite;
    @Column(name = "etage")
    private Integer etage;
    @Column(name = "type_chambre")
    private Integer typeChambre;
    @Column(name = "caracteristique_chambre")
    private Integer caracteristiqueChambre;
    @Column(name = "situation_chambre")
    private Integer situationChambre;
    @Column(name = "statut")
    private String statut;

    public Chambre() {
    }

    public Chambre(Integer id) {
        this.id = id;
    }

    public Chambre(Integer id, String designation) {
        this.id = id;
        this.designation = designation;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getBloc() {
        return bloc;
    }

    public void setBloc(Integer bloc) {
        this.bloc = bloc;
    }

    public Integer getCategorie() {
        return categorie;
    }

    public void setCategorie(Integer categorie) {
        this.categorie = categorie;
    }

    public Boolean getDisponibilite() {
        return disponibilite;
    }

    public void setDisponibilite(Boolean disponibilite) {
        this.disponibilite = disponibilite;
    }

    public Integer getEtage() {
        return etage;
    }

    public void setEtage(Integer etage) {
        this.etage = etage;
    }

    public Integer getTypeChambre() {
        return typeChambre;
    }

    public void setTypeChambre(Integer typeChambre) {
        this.typeChambre = typeChambre;
    }

    public Integer getCaracteristiqueChambre() {
        return caracteristiqueChambre;
    }

    public void setCaracteristiqueChambre(Integer caracteristiqueChambre) {
        this.caracteristiqueChambre = caracteristiqueChambre;
    }

    public Integer getSituationChambre() {
        return situationChambre;
    }

    public void setSituationChambre(Integer situationChambre) {
        this.situationChambre = situationChambre;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Chambre)) {
            return false;
        }
        Chambre other = (Chambre) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Chambre[ id=" + id + " ]";
    }
    
}
