/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "categorie_client")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CategorieClient.findAll", query = "SELECT c FROM CategorieClient c"),
    @NamedQuery(name = "CategorieClient.findById", query = "SELECT c FROM CategorieClient c WHERE c.id = :id"),
    @NamedQuery(name = "CategorieClient.findByDesignation", query = "SELECT c FROM CategorieClient c WHERE c.designation = :designation"),
    @NamedQuery(name = "CategorieClient.findByDescription", query = "SELECT c FROM CategorieClient c WHERE c.description = :description")})
public class CategorieClient implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "designation")
    private String designation;
    @Column(name = "description")
    private String description;

    public CategorieClient() {
    }

    public CategorieClient(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CategorieClient)) {
            return false;
        }
        CategorieClient other = (CategorieClient) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CategorieClient[ id=" + id + " ]";
    }
    
}
