/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "bloc")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bloc.findAll", query = "SELECT b FROM Bloc b"),
    @NamedQuery(name = "Bloc.findById", query = "SELECT b FROM Bloc b WHERE b.id = :id"),
    @NamedQuery(name = "Bloc.findByDesignation", query = "SELECT b FROM Bloc b WHERE b.designation = :designation"),
    @NamedQuery(name = "Bloc.findByDescription", query = "SELECT b FROM Bloc b WHERE b.description = :description"),
    @NamedQuery(name = "Bloc.findByDisponibilite", query = "SELECT b FROM Bloc b WHERE b.disponibilite = :disponibilite")})
public class Bloc implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "designation")
    private String designation;
    @Column(name = "description")
    private String description;
    @Column(name = "disponibilite")
    private Boolean disponibilite;

    public Bloc() {
    }

    public Bloc(Integer id) {
        this.id = id;
    }

    public Bloc(Integer id, String designation) {
        this.id = id;
        this.designation = designation;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getDisponibilite() {
        return disponibilite;
    }

    public void setDisponibilite(Boolean disponibilite) {
        this.disponibilite = disponibilite;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bloc)) {
            return false;
        }
        Bloc other = (Bloc) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Bloc[ id=" + id + " ]";
    }
    
}
