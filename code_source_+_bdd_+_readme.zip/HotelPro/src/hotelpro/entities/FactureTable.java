/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "facture_table")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FactureTable.findAll", query = "SELECT f FROM FactureTable f"),
    @NamedQuery(name = "FactureTable.findById", query = "SELECT f FROM FactureTable f WHERE f.id = :id"),
    @NamedQuery(name = "FactureTable.findByTableId", query = "SELECT f FROM FactureTable f WHERE f.tableId = :tableId"),
    @NamedQuery(name = "FactureTable.findByInfo", query = "SELECT f FROM FactureTable f WHERE f.info = :info"),
    @NamedQuery(name = "FactureTable.findByCout", query = "SELECT f FROM FactureTable f WHERE f.cout = :cout"),
    @NamedQuery(name = "FactureTable.findByDateHeure", query = "SELECT f FROM FactureTable f WHERE f.dateHeure = :dateHeure"),
    @NamedQuery(name = "FactureTable.findByLogin", query = "SELECT f FROM FactureTable f WHERE f.login = :login"),
    @NamedQuery(name = "FactureTable.findByDateFacture", query = "SELECT f FROM FactureTable f WHERE f.dateFacture = :dateFacture"),
    @NamedQuery(name = "FactureTable.findByNumFacture", query = "SELECT f FROM FactureTable f WHERE f.numFacture = :numFacture")})
public class FactureTable implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "table_id")
    private int tableId;
    @Basic(optional = false)
    @Column(name = "info")
    private String info;
    @Basic(optional = false)
    @Column(name = "cout")
    private String cout;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;
    @Column(name = "date_facture")
    private String dateFacture;
    @Column(name = "num_facture")
    private String numFacture;

    public FactureTable() {
    }

    public FactureTable(Integer id) {
        this.id = id;
    }

    public FactureTable(Integer id, int tableId, String info, String cout, String dateHeure, String login) {
        this.id = id;
        this.tableId = tableId;
        this.info = info;
        this.cout = cout;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getTableId() {
        return tableId;
    }

    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getDateFacture() {
        return dateFacture;
    }

    public void setDateFacture(String dateFacture) {
        this.dateFacture = dateFacture;
    }

    public String getNumFacture() {
        return numFacture;
    }

    public void setNumFacture(String numFacture) {
        this.numFacture = numFacture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FactureTable)) {
            return false;
        }
        FactureTable other = (FactureTable) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.FactureTable[ id=" + id + " ]";
    }
    
}
