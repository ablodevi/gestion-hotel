/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "caisse_divers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CaisseDivers.findAll", query = "SELECT c FROM CaisseDivers c"),
    @NamedQuery(name = "CaisseDivers.findById", query = "SELECT c FROM CaisseDivers c WHERE c.id = :id"),
    @NamedQuery(name = "CaisseDivers.findByMotif", query = "SELECT c FROM CaisseDivers c WHERE c.motif = :motif"),
    @NamedQuery(name = "CaisseDivers.findByVariation", query = "SELECT c FROM CaisseDivers c WHERE c.variation = :variation"),
    @NamedQuery(name = "CaisseDivers.findByDateHeure", query = "SELECT c FROM CaisseDivers c WHERE c.dateHeure = :dateHeure"),
    @NamedQuery(name = "CaisseDivers.findByLogin", query = "SELECT c FROM CaisseDivers c WHERE c.login = :login")})
public class CaisseDivers implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "motif")
    private String motif;
    @Basic(optional = false)
    @Column(name = "variation")
    private String variation;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public CaisseDivers() {
    }

    public CaisseDivers(Integer id) {
        this.id = id;
    }

    public CaisseDivers(Integer id, String motif, String variation, String dateHeure, String login) {
        this.id = id;
        this.motif = motif;
        this.variation = variation;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseDivers)) {
            return false;
        }
        CaisseDivers other = (CaisseDivers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CaisseDivers[ id=" + id + " ]";
    }
    
}
