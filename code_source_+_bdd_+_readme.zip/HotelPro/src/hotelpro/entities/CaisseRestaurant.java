/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "caisse_restaurant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CaisseRestaurant.findAll", query = "SELECT c FROM CaisseRestaurant c"),
    @NamedQuery(name = "CaisseRestaurant.findById", query = "SELECT c FROM CaisseRestaurant c WHERE c.id = :id"),
    @NamedQuery(name = "CaisseRestaurant.findByVariation", query = "SELECT c FROM CaisseRestaurant c WHERE c.variation = :variation"),
    @NamedQuery(name = "CaisseRestaurant.findByRestaurantVente", query = "SELECT c FROM CaisseRestaurant c WHERE c.restaurantVente = :restaurantVente"),
    @NamedQuery(name = "CaisseRestaurant.findByDateHeure", query = "SELECT c FROM CaisseRestaurant c WHERE c.dateHeure = :dateHeure"),
    @NamedQuery(name = "CaisseRestaurant.findByLogin", query = "SELECT c FROM CaisseRestaurant c WHERE c.login = :login")})
public class CaisseRestaurant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "variation")
    private String variation;
    @Basic(optional = false)
    @Column(name = "restaurant_vente")
    private int restaurantVente;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public CaisseRestaurant() {
    }

    public CaisseRestaurant(Integer id) {
        this.id = id;
    }

    public CaisseRestaurant(Integer id, String variation, int restaurantVente, String dateHeure, String login) {
        this.id = id;
        this.variation = variation;
        this.restaurantVente = restaurantVente;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public int getRestaurantVente() {
        return restaurantVente;
    }

    public void setRestaurantVente(int restaurantVente) {
        this.restaurantVente = restaurantVente;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseRestaurant)) {
            return false;
        }
        CaisseRestaurant other = (CaisseRestaurant) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CaisseRestaurant[ id=" + id + " ]";
    }
    
}
