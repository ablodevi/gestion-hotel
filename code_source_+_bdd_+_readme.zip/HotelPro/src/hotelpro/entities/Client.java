/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "client")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Client.findAll", query = "SELECT c FROM Client c"),
    @NamedQuery(name = "Client.findById", query = "SELECT c FROM Client c WHERE c.id = :id"),
    @NamedQuery(name = "Client.findByNom", query = "SELECT c FROM Client c WHERE c.nom = :nom"),
    @NamedQuery(name = "Client.findByPrenoms", query = "SELECT c FROM Client c WHERE c.prenoms = :prenoms"),
    @NamedQuery(name = "Client.findBySurnom", query = "SELECT c FROM Client c WHERE c.surnom = :surnom"),
    @NamedQuery(name = "Client.findByButVisite", query = "SELECT c FROM Client c WHERE c.butVisite = :butVisite"),
    @NamedQuery(name = "Client.findByAge", query = "SELECT c FROM Client c WHERE c.age = :age"),
    @NamedQuery(name = "Client.findBySexe", query = "SELECT c FROM Client c WHERE c.sexe = :sexe"),
    @NamedQuery(name = "Client.findByPaysResidence", query = "SELECT c FROM Client c WHERE c.paysResidence = :paysResidence"),
    @NamedQuery(name = "Client.findByNationalite", query = "SELECT c FROM Client c WHERE c.nationalite = :nationalite"),
    @NamedQuery(name = "Client.findByReligion", query = "SELECT c FROM Client c WHERE c.religion = :religion"),
    @NamedQuery(name = "Client.findByAdressePerso", query = "SELECT c FROM Client c WHERE c.adressePerso = :adressePerso"),
    @NamedQuery(name = "Client.findByAdressePro", query = "SELECT c FROM Client c WHERE c.adressePro = :adressePro"),
    @NamedQuery(name = "Client.findByMobilePerso", query = "SELECT c FROM Client c WHERE c.mobilePerso = :mobilePerso"),
    @NamedQuery(name = "Client.findByMobilePro", query = "SELECT c FROM Client c WHERE c.mobilePro = :mobilePro"),
    @NamedQuery(name = "Client.findByFixePerso", query = "SELECT c FROM Client c WHERE c.fixePerso = :fixePerso"),
    @NamedQuery(name = "Client.findByFixePro", query = "SELECT c FROM Client c WHERE c.fixePro = :fixePro"),
    @NamedQuery(name = "Client.findByFax", query = "SELECT c FROM Client c WHERE c.fax = :fax"),
    @NamedQuery(name = "Client.findByIdCard", query = "SELECT c FROM Client c WHERE c.idCard = :idCard"),
    @NamedQuery(name = "Client.findByPasseport", query = "SELECT c FROM Client c WHERE c.passeport = :passeport"),
    @NamedQuery(name = "Client.findByEmail", query = "SELECT c FROM Client c WHERE c.email = :email"),
    @NamedQuery(name = "Client.findByWebsite", query = "SELECT c FROM Client c WHERE c.website = :website"),
    @NamedQuery(name = "Client.findByProfession", query = "SELECT c FROM Client c WHERE c.profession = :profession"),
    @NamedQuery(name = "Client.findBySociete", query = "SELECT c FROM Client c WHERE c.societe = :societe"),
    @NamedQuery(name = "Client.findByPhoto", query = "SELECT c FROM Client c WHERE c.photo = :photo"),
    @NamedQuery(name = "Client.findByPhotoGrandFormat", query = "SELECT c FROM Client c WHERE c.photoGrandFormat = :photoGrandFormat"),
    @NamedQuery(name = "Client.findByCategorieClient", query = "SELECT c FROM Client c WHERE c.categorieClient = :categorieClient"),
    @NamedQuery(name = "Client.findByCarteFidelite", query = "SELECT c FROM Client c WHERE c.carteFidelite = :carteFidelite")})
public class Client implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "nom")
    private String nom;
    @Column(name = "prenoms")
    private String prenoms;
    @Column(name = "surnom")
    private String surnom;
    @Column(name = "but_visite")
    private String butVisite;
    @Column(name = "age")
    private String age;
    @Column(name = "sexe")
    private String sexe;
    @Column(name = "pays_residence")
    private String paysResidence;
    @Column(name = "nationalite")
    private String nationalite;
    @Column(name = "religion")
    private String religion;
    @Column(name = "adresse_perso")
    private String adressePerso;
    @Column(name = "adresse_pro")
    private String adressePro;
    @Column(name = "mobile_perso")
    private String mobilePerso;
    @Column(name = "mobile_pro")
    private String mobilePro;
    @Column(name = "fixe_perso")
    private String fixePerso;
    @Column(name = "fixe_pro")
    private String fixePro;
    @Column(name = "fax")
    private String fax;
    @Column(name = "id_card")
    private String idCard;
    @Column(name = "passeport")
    private String passeport;
    @Column(name = "email")
    private String email;
    @Column(name = "website")
    private String website;
    @Column(name = "profession")
    private String profession;
    @Column(name = "societe")
    private String societe;
    @Column(name = "photo")
    private String photo;
    @Column(name = "photo_grand_format")
    private String photoGrandFormat;
    @Column(name = "categorie_client")
    private Integer categorieClient;
    @Column(name = "carte_fidelite")
    private Boolean carteFidelite;

    public Client() {
    }

    public Client(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenoms() {
        return prenoms;
    }

    public void setPrenoms(String prenoms) {
        this.prenoms = prenoms;
    }

    public String getSurnom() {
        return surnom;
    }

    public void setSurnom(String surnom) {
        this.surnom = surnom;
    }

    public String getButVisite() {
        return butVisite;
    }

    public void setButVisite(String butVisite) {
        this.butVisite = butVisite;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public String getPaysResidence() {
        return paysResidence;
    }

    public void setPaysResidence(String paysResidence) {
        this.paysResidence = paysResidence;
    }

    public String getNationalite() {
        return nationalite;
    }

    public void setNationalite(String nationalite) {
        this.nationalite = nationalite;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getAdressePerso() {
        return adressePerso;
    }

    public void setAdressePerso(String adressePerso) {
        this.adressePerso = adressePerso;
    }

    public String getAdressePro() {
        return adressePro;
    }

    public void setAdressePro(String adressePro) {
        this.adressePro = adressePro;
    }

    public String getMobilePerso() {
        return mobilePerso;
    }

    public void setMobilePerso(String mobilePerso) {
        this.mobilePerso = mobilePerso;
    }

    public String getMobilePro() {
        return mobilePro;
    }

    public void setMobilePro(String mobilePro) {
        this.mobilePro = mobilePro;
    }

    public String getFixePerso() {
        return fixePerso;
    }

    public void setFixePerso(String fixePerso) {
        this.fixePerso = fixePerso;
    }

    public String getFixePro() {
        return fixePro;
    }

    public void setFixePro(String fixePro) {
        this.fixePro = fixePro;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPasseport() {
        return passeport;
    }

    public void setPasseport(String passeport) {
        this.passeport = passeport;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getSociete() {
        return societe;
    }

    public void setSociete(String societe) {
        this.societe = societe;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getPhotoGrandFormat() {
        return photoGrandFormat;
    }

    public void setPhotoGrandFormat(String photoGrandFormat) {
        this.photoGrandFormat = photoGrandFormat;
    }

    public Integer getCategorieClient() {
        return categorieClient;
    }

    public void setCategorieClient(Integer categorieClient) {
        this.categorieClient = categorieClient;
    }

    public Boolean getCarteFidelite() {
        return carteFidelite;
    }

    public void setCarteFidelite(Boolean carteFidelite) {
        this.carteFidelite = carteFidelite;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Client)) {
            return false;
        }
        Client other = (Client) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Client[ id=" + id + " ]";
    }
    
}
