/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "flux_prix_menu")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FluxPrixMenu.findAll", query = "SELECT f FROM FluxPrixMenu f"),
    @NamedQuery(name = "FluxPrixMenu.findById", query = "SELECT f FROM FluxPrixMenu f WHERE f.id = :id"),
    @NamedQuery(name = "FluxPrixMenu.findByMenu", query = "SELECT f FROM FluxPrixMenu f WHERE f.menu = :menu"),
    @NamedQuery(name = "FluxPrixMenu.findByPrix", query = "SELECT f FROM FluxPrixMenu f WHERE f.prix = :prix"),
    @NamedQuery(name = "FluxPrixMenu.findByDateHeure", query = "SELECT f FROM FluxPrixMenu f WHERE f.dateHeure = :dateHeure"),
    @NamedQuery(name = "FluxPrixMenu.findByLogin", query = "SELECT f FROM FluxPrixMenu f WHERE f.login = :login")})
public class FluxPrixMenu implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "menu")
    private int menu;
    @Basic(optional = false)
    @Column(name = "prix")
    private String prix;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public FluxPrixMenu() {
    }

    public FluxPrixMenu(Integer id) {
        this.id = id;
    }

    public FluxPrixMenu(Integer id, int menu, String prix, String dateHeure, String login) {
        this.id = id;
        this.menu = menu;
        this.prix = prix;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getMenu() {
        return menu;
    }

    public void setMenu(int menu) {
        this.menu = menu;
    }

    public String getPrix() {
        return prix;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FluxPrixMenu)) {
            return false;
        }
        FluxPrixMenu other = (FluxPrixMenu) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.FluxPrixMenu[ id=" + id + " ]";
    }
    
}
