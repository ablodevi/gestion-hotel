/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "serveur")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Serveur.findAll", query = "SELECT s FROM Serveur s"),
    @NamedQuery(name = "Serveur.findById", query = "SELECT s FROM Serveur s WHERE s.id = :id"),
    @NamedQuery(name = "Serveur.findByIdentifiant", query = "SELECT s FROM Serveur s WHERE s.identifiant = :identifiant"),
    @NamedQuery(name = "Serveur.findByMention", query = "SELECT s FROM Serveur s WHERE s.mention = :mention")})
public class Serveur implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "identifiant")
    private String identifiant;
    @Column(name = "mention")
    private String mention;

    public Serveur() {
    }

    public Serveur(Integer id) {
        this.id = id;
    }

    public Serveur(Integer id, String identifiant) {
        this.id = id;
        this.identifiant = identifiant;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIdentifiant() {
        return identifiant;
    }

    public void setIdentifiant(String identifiant) {
        this.identifiant = identifiant;
    }

    public String getMention() {
        return mention;
    }

    public void setMention(String mention) {
        this.mention = mention;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Serveur)) {
            return false;
        }
        Serveur other = (Serveur) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Serveur[ id=" + id + " ]";
    }
    
}
