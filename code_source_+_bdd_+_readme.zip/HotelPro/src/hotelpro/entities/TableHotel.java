/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "table_hotel")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TableHotel.findAll", query = "SELECT t FROM TableHotel t"),
    @NamedQuery(name = "TableHotel.findById", query = "SELECT t FROM TableHotel t WHERE t.id = :id"),
    @NamedQuery(name = "TableHotel.findByDesignation", query = "SELECT t FROM TableHotel t WHERE t.designation = :designation"),
    @NamedQuery(name = "TableHotel.findByCloture", query = "SELECT t FROM TableHotel t WHERE t.cloture = :cloture")})
public class TableHotel implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "designation")
    private String designation;
    @Column(name = "cloture")
    private Boolean cloture;

    public TableHotel() {
    }

    public TableHotel(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Boolean getCloture() {
        return cloture;
    }

    public void setCloture(Boolean cloture) {
        this.cloture = cloture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TableHotel)) {
            return false;
        }
        TableHotel other = (TableHotel) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.TableHotel[ id=" + id + " ]";
    }
    
}
