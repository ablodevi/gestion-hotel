/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "vente_acces_piscine")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "VenteAccesPiscine.findAll", query = "SELECT v FROM VenteAccesPiscine v"),
    @NamedQuery(name = "VenteAccesPiscine.findById", query = "SELECT v FROM VenteAccesPiscine v WHERE v.id = :id"),
    @NamedQuery(name = "VenteAccesPiscine.findByNombre", query = "SELECT v FROM VenteAccesPiscine v WHERE v.nombre = :nombre"),
    @NamedQuery(name = "VenteAccesPiscine.findByCout", query = "SELECT v FROM VenteAccesPiscine v WHERE v.cout = :cout"),
    @NamedQuery(name = "VenteAccesPiscine.findByPiscine", query = "SELECT v FROM VenteAccesPiscine v WHERE v.piscine = :piscine"),
    @NamedQuery(name = "VenteAccesPiscine.findByLogin", query = "SELECT v FROM VenteAccesPiscine v WHERE v.login = :login"),
    @NamedQuery(name = "VenteAccesPiscine.findByReservation", query = "SELECT v FROM VenteAccesPiscine v WHERE v.reservation = :reservation"),
    @NamedQuery(name = "VenteAccesPiscine.findByDateHeure", query = "SELECT v FROM VenteAccesPiscine v WHERE v.dateHeure = :dateHeure")})
public class VenteAccesPiscine implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "cout")
    private String cout;
    @Basic(optional = false)
    @Column(name = "piscine")
    private int piscine;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;
    @Column(name = "reservation")
    private Integer reservation;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;

    public VenteAccesPiscine() {
    }

    public VenteAccesPiscine(Integer id) {
        this.id = id;
    }

    public VenteAccesPiscine(Integer id, String nombre, String cout, int piscine, String login, String dateHeure) {
        this.id = id;
        this.nombre = nombre;
        this.cout = cout;
        this.piscine = piscine;
        this.login = login;
        this.dateHeure = dateHeure;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCout() {
        return cout;
    }

    public void setCout(String cout) {
        this.cout = cout;
    }

    public int getPiscine() {
        return piscine;
    }

    public void setPiscine(int piscine) {
        this.piscine = piscine;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Integer getReservation() {
        return reservation;
    }

    public void setReservation(Integer reservation) {
        this.reservation = reservation;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof VenteAccesPiscine)) {
            return false;
        }
        VenteAccesPiscine other = (VenteAccesPiscine) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.VenteAccesPiscine[ id=" + id + " ]";
    }
    
}
