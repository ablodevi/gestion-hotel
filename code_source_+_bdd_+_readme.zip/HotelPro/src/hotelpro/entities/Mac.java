/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "mac")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mac.findAll", query = "SELECT m FROM Mac m"),
    @NamedQuery(name = "Mac.findById", query = "SELECT m FROM Mac m WHERE m.id = :id"),
    @NamedQuery(name = "Mac.findByAddresse", query = "SELECT m FROM Mac m WHERE m.addresse = :addresse"),
    @NamedQuery(name = "Mac.findByDateHeure", query = "SELECT m FROM Mac m WHERE m.dateHeure = :dateHeure")})
public class Mac implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "addresse")
    private String addresse;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;

    public Mac() {
    }

    public Mac(Integer id) {
        this.id = id;
    }

    public Mac(Integer id, String addresse, String dateHeure) {
        this.id = id;
        this.addresse = addresse;
        this.dateHeure = dateHeure;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAddresse() {
        return addresse;
    }

    public void setAddresse(String addresse) {
        this.addresse = addresse;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mac)) {
            return false;
        }
        Mac other = (Mac) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Mac[ id=" + id + " ]";
    }
    
}
