/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "stock_boisson")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "StockBoisson.findAll", query = "SELECT s FROM StockBoisson s"),
    @NamedQuery(name = "StockBoisson.findById", query = "SELECT s FROM StockBoisson s WHERE s.id = :id"),
    @NamedQuery(name = "StockBoisson.findByVariation", query = "SELECT s FROM StockBoisson s WHERE s.variation = :variation"),
    @NamedQuery(name = "StockBoisson.findByDateHeure", query = "SELECT s FROM StockBoisson s WHERE s.dateHeure = :dateHeure"),
    @NamedQuery(name = "StockBoisson.findByBoisson", query = "SELECT s FROM StockBoisson s WHERE s.boisson = :boisson"),
    @NamedQuery(name = "StockBoisson.findByBarVente", query = "SELECT s FROM StockBoisson s WHERE s.barVente = :barVente"),
    @NamedQuery(name = "StockBoisson.findByProvenance", query = "SELECT s FROM StockBoisson s WHERE s.provenance = :provenance"),
    @NamedQuery(name = "StockBoisson.findByLogin", query = "SELECT s FROM StockBoisson s WHERE s.login = :login")})
public class StockBoisson implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "variation")
    private String variation;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "boisson")
    private int boisson;
    @Column(name = "bar_vente")
    private Integer barVente;
    @Column(name = "provenance")
    private String provenance;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public StockBoisson() {
    }

    public StockBoisson(Integer id) {
        this.id = id;
    }

    public StockBoisson(Integer id, String variation, String dateHeure, int boisson, String login) {
        this.id = id;
        this.variation = variation;
        this.dateHeure = dateHeure;
        this.boisson = boisson;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public int getBoisson() {
        return boisson;
    }

    public void setBoisson(int boisson) {
        this.boisson = boisson;
    }

    public Integer getBarVente() {
        return barVente;
    }

    public void setBarVente(Integer barVente) {
        this.barVente = barVente;
    }

    public String getProvenance() {
        return provenance;
    }

    public void setProvenance(String provenance) {
        this.provenance = provenance;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof StockBoisson)) {
            return false;
        }
        StockBoisson other = (StockBoisson) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.StockBoisson[ id=" + id + " ]";
    }
    
}
