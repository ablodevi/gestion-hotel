/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "caisse_reservation")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CaisseReservation.findAll", query = "SELECT c FROM CaisseReservation c"),
    @NamedQuery(name = "CaisseReservation.findById", query = "SELECT c FROM CaisseReservation c WHERE c.id = :id"),
    @NamedQuery(name = "CaisseReservation.findByMotif", query = "SELECT c FROM CaisseReservation c WHERE c.motif = :motif"),
    @NamedQuery(name = "CaisseReservation.findByVariation", query = "SELECT c FROM CaisseReservation c WHERE c.variation = :variation"),
    @NamedQuery(name = "CaisseReservation.findByReservation", query = "SELECT c FROM CaisseReservation c WHERE c.reservation = :reservation"),
    @NamedQuery(name = "CaisseReservation.findByDateHeure", query = "SELECT c FROM CaisseReservation c WHERE c.dateHeure = :dateHeure"),
    @NamedQuery(name = "CaisseReservation.findByLogin", query = "SELECT c FROM CaisseReservation c WHERE c.login = :login")})
public class CaisseReservation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "motif")
    private String motif;
    @Basic(optional = false)
    @Column(name = "variation")
    private String variation;
    @Column(name = "reservation")
    private Integer reservation;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public CaisseReservation() {
    }

    public CaisseReservation(Integer id) {
        this.id = id;
    }

    public CaisseReservation(Integer id, String variation, String dateHeure, String login) {
        this.id = id;
        this.variation = variation;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public Integer getReservation() {
        return reservation;
    }

    public void setReservation(Integer reservation) {
        this.reservation = reservation;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseReservation)) {
            return false;
        }
        CaisseReservation other = (CaisseReservation) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CaisseReservation[ id=" + id + " ]";
    }
    
}
