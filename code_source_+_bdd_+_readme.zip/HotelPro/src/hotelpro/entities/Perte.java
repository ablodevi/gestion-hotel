/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "perte")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Perte.findAll", query = "SELECT p FROM Perte p"),
    @NamedQuery(name = "Perte.findById", query = "SELECT p FROM Perte p WHERE p.id = :id"),
    @NamedQuery(name = "Perte.findByLibelle", query = "SELECT p FROM Perte p WHERE p.libelle = :libelle"),
    @NamedQuery(name = "Perte.findByCout", query = "SELECT p FROM Perte p WHERE p.cout = :cout"),
    @NamedQuery(name = "Perte.findByDateHeure", query = "SELECT p FROM Perte p WHERE p.dateHeure = :dateHeure"),
    @NamedQuery(name = "Perte.findByLogin", query = "SELECT p FROM Perte p WHERE p.login = :login")})
public class Perte implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "libelle")
    private String libelle;
    @Basic(optional = false)
    @Column(name = "cout")
    private int cout;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public Perte() {
    }

    public Perte(Integer id) {
        this.id = id;
    }

    public Perte(Integer id, String libelle, int cout, String dateHeure, String login) {
        this.id = id;
        this.libelle = libelle;
        this.cout = cout;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getCout() {
        return cout;
    }

    public void setCout(int cout) {
        this.cout = cout;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Perte)) {
            return false;
        }
        Perte other = (Perte) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Perte[ id=" + id + " ]";
    }
    
}
