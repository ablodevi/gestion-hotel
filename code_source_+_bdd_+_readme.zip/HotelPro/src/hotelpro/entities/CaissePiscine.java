/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "caisse_piscine")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CaissePiscine.findAll", query = "SELECT c FROM CaissePiscine c"),
    @NamedQuery(name = "CaissePiscine.findById", query = "SELECT c FROM CaissePiscine c WHERE c.id = :id"),
    @NamedQuery(name = "CaissePiscine.findByVariation", query = "SELECT c FROM CaissePiscine c WHERE c.variation = :variation"),
    @NamedQuery(name = "CaissePiscine.findByVenteAccesPiscine", query = "SELECT c FROM CaissePiscine c WHERE c.venteAccesPiscine = :venteAccesPiscine"),
    @NamedQuery(name = "CaissePiscine.findByDateHeure", query = "SELECT c FROM CaissePiscine c WHERE c.dateHeure = :dateHeure"),
    @NamedQuery(name = "CaissePiscine.findByLogin", query = "SELECT c FROM CaissePiscine c WHERE c.login = :login")})
public class CaissePiscine implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "variation")
    private String variation;
    @Basic(optional = false)
    @Column(name = "vente_acces_piscine")
    private int venteAccesPiscine;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public CaissePiscine() {
    }

    public CaissePiscine(Integer id) {
        this.id = id;
    }

    public CaissePiscine(Integer id, String variation, int venteAccesPiscine, String dateHeure, String login) {
        this.id = id;
        this.variation = variation;
        this.venteAccesPiscine = venteAccesPiscine;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public int getVenteAccesPiscine() {
        return venteAccesPiscine;
    }

    public void setVenteAccesPiscine(int venteAccesPiscine) {
        this.venteAccesPiscine = venteAccesPiscine;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaissePiscine)) {
            return false;
        }
        CaissePiscine other = (CaissePiscine) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CaissePiscine[ id=" + id + " ]";
    }
    
}
