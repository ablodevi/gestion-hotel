/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "boisson_seuil")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BoissonSeuil.findAll", query = "SELECT b FROM BoissonSeuil b"),
    @NamedQuery(name = "BoissonSeuil.findById", query = "SELECT b FROM BoissonSeuil b WHERE b.id = :id"),
    @NamedQuery(name = "BoissonSeuil.findByBoisson", query = "SELECT b FROM BoissonSeuil b WHERE b.boisson = :boisson"),
    @NamedQuery(name = "BoissonSeuil.findBySeuil", query = "SELECT b FROM BoissonSeuil b WHERE b.seuil = :seuil")})
public class BoissonSeuil implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "boisson")
    private Integer boisson;
    @Column(name = "seuil")
    private String seuil;

    public BoissonSeuil() {
    }

    public BoissonSeuil(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBoisson() {
        return boisson;
    }

    public void setBoisson(Integer boisson) {
        this.boisson = boisson;
    }

    public String getSeuil() {
        return seuil;
    }

    public void setSeuil(String seuil) {
        this.seuil = seuil;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BoissonSeuil)) {
            return false;
        }
        BoissonSeuil other = (BoissonSeuil) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.BoissonSeuil[ id=" + id + " ]";
    }
    
}
