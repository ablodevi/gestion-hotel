/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "caisse_bar")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CaisseBar.findAll", query = "SELECT c FROM CaisseBar c"),
    @NamedQuery(name = "CaisseBar.findById", query = "SELECT c FROM CaisseBar c WHERE c.id = :id"),
    @NamedQuery(name = "CaisseBar.findByVariation", query = "SELECT c FROM CaisseBar c WHERE c.variation = :variation"),
    @NamedQuery(name = "CaisseBar.findByBarVente", query = "SELECT c FROM CaisseBar c WHERE c.barVente = :barVente"),
    @NamedQuery(name = "CaisseBar.findByDateHeure", query = "SELECT c FROM CaisseBar c WHERE c.dateHeure = :dateHeure"),
    @NamedQuery(name = "CaisseBar.findByLogin", query = "SELECT c FROM CaisseBar c WHERE c.login = :login")})
public class CaisseBar implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "variation")
    private String variation;
    @Column(name = "bar_vente")
    private Integer barVente;
    @Basic(optional = false)
    @Column(name = "date_heure")
    private String dateHeure;
    @Basic(optional = false)
    @Column(name = "login")
    private String login;

    public CaisseBar() {
    }

    public CaisseBar(Integer id) {
        this.id = id;
    }

    public CaisseBar(Integer id, String variation, String dateHeure, String login) {
        this.id = id;
        this.variation = variation;
        this.dateHeure = dateHeure;
        this.login = login;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVariation() {
        return variation;
    }

    public void setVariation(String variation) {
        this.variation = variation;
    }

    public Integer getBarVente() {
        return barVente;
    }

    public void setBarVente(Integer barVente) {
        this.barVente = barVente;
    }

    public String getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(String dateHeure) {
        this.dateHeure = dateHeure;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseBar)) {
            return false;
        }
        CaisseBar other = (CaisseBar) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.CaisseBar[ id=" + id + " ]";
    }
    
}
