/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelpro.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Serge
 */
@Entity
@Table(name = "piscine")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Piscine.findAll", query = "SELECT p FROM Piscine p"),
    @NamedQuery(name = "Piscine.findById", query = "SELECT p FROM Piscine p WHERE p.id = :id"),
    @NamedQuery(name = "Piscine.findByLibelle", query = "SELECT p FROM Piscine p WHERE p.libelle = :libelle"),
    @NamedQuery(name = "Piscine.findByPrixUnitaire", query = "SELECT p FROM Piscine p WHERE p.prixUnitaire = :prixUnitaire"),
    @NamedQuery(name = "Piscine.findByPrixUnitaireEnfant", query = "SELECT p FROM Piscine p WHERE p.prixUnitaireEnfant = :prixUnitaireEnfant")})
public class Piscine implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "libelle")
    private String libelle;
    @Basic(optional = false)
    @Column(name = "prix_unitaire")
    private String prixUnitaire;
    @Basic(optional = false)
    @Column(name = "prix_unitaire_enfant")
    private String prixUnitaireEnfant;

    public Piscine() {
    }

    public Piscine(Integer id) {
        this.id = id;
    }

    public Piscine(Integer id, String libelle, String prixUnitaire, String prixUnitaireEnfant) {
        this.id = id;
        this.libelle = libelle;
        this.prixUnitaire = prixUnitaire;
        this.prixUnitaireEnfant = prixUnitaireEnfant;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getPrixUnitaire() {
        return prixUnitaire;
    }

    public void setPrixUnitaire(String prixUnitaire) {
        this.prixUnitaire = prixUnitaire;
    }

    public String getPrixUnitaireEnfant() {
        return prixUnitaireEnfant;
    }

    public void setPrixUnitaireEnfant(String prixUnitaireEnfant) {
        this.prixUnitaireEnfant = prixUnitaireEnfant;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Piscine)) {
            return false;
        }
        Piscine other = (Piscine) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hotelpro.entities.Piscine[ id=" + id + " ]";
    }
    
}
