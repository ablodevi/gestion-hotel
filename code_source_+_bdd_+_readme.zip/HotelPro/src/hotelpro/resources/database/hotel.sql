-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.32-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema hotel
--

CREATE DATABASE IF NOT EXISTS hotel;
USE hotel;

--
-- Definition of table `accreditation`
--
DROP TABLE IF EXISTS `accreditation`;
CREATE TABLE `accreditation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(45) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accreditation`
--

/*!40000 ALTER TABLE `accreditation` DISABLE KEYS */;
INSERT INTO `accreditation` (`id`,`libelle`,`description`) VALUES 
 (1,'Utilisateur',NULL),
 (2,'Administrateur',NULL);
/*!40000 ALTER TABLE `accreditation` ENABLE KEYS */;


--
-- Definition of table `bar`
--

CREATE TABLE IF NOT EXISTS `bar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bar`
--

/*!40000 ALTER TABLE `bar` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar` ENABLE KEYS */;


--
-- Definition of table `bar_vente`
--

CREATE TABLE IF NOT EXISTS `bar_vente` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boisson` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `paye` tinyint(1) unsigned DEFAULT '0',
  `reservation` int(10) unsigned DEFAULT NULL,
  `serveur` int(10) unsigned DEFAULT NULL,
  `bar` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `cloture` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bar_vente`
--

/*!40000 ALTER TABLE `bar_vente` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_vente` ENABLE KEYS */;


--
-- Definition of table `bloc`
--

CREATE TABLE IF NOT EXISTS `bloc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(45) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloc`
--

/*!40000 ALTER TABLE `bloc` DISABLE KEYS */;
/*!40000 ALTER TABLE `bloc` ENABLE KEYS */;


--
-- Definition of table `boisson`
--

CREATE TABLE IF NOT EXISTS `boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(45) DEFAULT NULL,
  `cout` varchar(45) DEFAULT NULL,
  `categorie_boisson` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boisson`
--

/*!40000 ALTER TABLE `boisson` DISABLE KEYS */;
/*!40000 ALTER TABLE `boisson` ENABLE KEYS */;

--
-- Definition of table `boisson_seuil`
--

CREATE TABLE IF NOT EXISTS `boisson_seuil` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boisson` int(10) DEFAULT NULL,
  `seuil` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boisson_seuil`
--

/*!40000 ALTER TABLE `boisson_seuil` DISABLE KEYS */;
/*!40000 ALTER TABLE `boisson_seuil` ENABLE KEYS */;


--
-- Definition of table `caisse_bar`
--

CREATE TABLE IF NOT EXISTS `caisse_bar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `bar_vente` int(10) unsigned DEFAULT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_bar`
--

/*!40000 ALTER TABLE `caisse_bar` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_bar` ENABLE KEYS */;


--
-- Definition of table `caisse_divers`
--

CREATE TABLE IF NOT EXISTS `caisse_divers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `motif` varchar(200) NOT NULL,
  `variation` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_divers`
--

/*!40000 ALTER TABLE `caisse_divers` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_divers` ENABLE KEYS */;


--
-- Definition of table `caisse_piscine`
--

CREATE TABLE IF NOT EXISTS `caisse_piscine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `vente_acces_piscine` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_piscine`
--

/*!40000 ALTER TABLE `caisse_piscine` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_piscine` ENABLE KEYS */;


--
-- Definition of table `caisse_reservation`
--

CREATE TABLE IF NOT EXISTS `caisse_reservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `motif` varchar(200) DEFAULT NULL,
  `variation` varchar(45) NOT NULL,
  `reservation` int(10) unsigned DEFAULT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_reservation`
--

/*!40000 ALTER TABLE `caisse_reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_reservation` ENABLE KEYS */;


--
-- Definition of table `caisse_restaurant`
--

CREATE TABLE IF NOT EXISTS `caisse_restaurant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `restaurant_vente` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_restaurant`
--

/*!40000 ALTER TABLE `caisse_restaurant` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_restaurant` ENABLE KEYS */;


--
-- Definition of table `caracteristique_chambre`
--

CREATE TABLE IF NOT EXISTS `caracteristique_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caracteristique_chambre`
--

/*!40000 ALTER TABLE `caracteristique_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `caracteristique_chambre` ENABLE KEYS */;


--
-- Definition of table `carte_fidelite`
--

CREATE TABLE IF NOT EXISTS `carte_fidelite` (
  `id` int(10) unsigned NOT NULL,
  `client` int(10) unsigned NOT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carte_fidelite`
--

/*!40000 ALTER TABLE `carte_fidelite` DISABLE KEYS */;
/*!40000 ALTER TABLE `carte_fidelite` ENABLE KEYS */;


--
-- Definition of table `categorie_boisson`
--

CREATE TABLE IF NOT EXISTS `categorie_boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_boisson`
--

/*!40000 ALTER TABLE `categorie_boisson` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_boisson` ENABLE KEYS */;


--
-- Definition of table `categorie_chambre`
--

CREATE TABLE IF NOT EXISTS `categorie_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_chambre`
--

/*!40000 ALTER TABLE `categorie_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_chambre` ENABLE KEYS */;


--
-- Definition of table `categorie_client`
--

CREATE TABLE IF NOT EXISTS `categorie_client` (
  `id` int(10) unsigned NOT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`designation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_client`
--

/*!40000 ALTER TABLE `categorie_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_client` ENABLE KEYS */;


--
-- Definition of table `categorie_lit`
--

CREATE TABLE IF NOT EXISTS `categorie_lit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_lit`
--

/*!40000 ALTER TABLE `categorie_lit` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_lit` ENABLE KEYS */;


--
-- Definition of table `categorie_menu`
--

CREATE TABLE IF NOT EXISTS `categorie_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_menu`
--

/*!40000 ALTER TABLE `categorie_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_menu` ENABLE KEYS */;


--
-- Definition of table `chambre`
--

CREATE TABLE IF NOT EXISTS `chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `bloc` int(10) unsigned DEFAULT NULL,
  `categorie` int(10) unsigned DEFAULT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  `etage` int(10) unsigned DEFAULT NULL,
  `type_chambre` int(10) unsigned DEFAULT NULL,
  `caracteristique_chambre` int(10) unsigned DEFAULT NULL,
  `situation_chambre` int(10) unsigned DEFAULT NULL,
  `statut` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chambre`
--

/*!40000 ALTER TABLE `chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `chambre` ENABLE KEYS */;


--
-- Definition of table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(10) unsigned NOT NULL,
  `nom` varchar(45) DEFAULT NULL,
  `prenoms` varchar(200) DEFAULT NULL,
  `surnom` varchar(100) DEFAULT NULL,
  `but_visite` varchar(200) DEFAULT NULL,
  `age` varchar(45) DEFAULT NULL,
  `sexe` varchar(45) DEFAULT NULL,
  `pays_residence` varchar(100) DEFAULT NULL,
  `nationalite` varchar(100) DEFAULT NULL,
  `religion` varchar(200) DEFAULT NULL,
  `adresse_perso` varchar(200) DEFAULT NULL,
  `adresse_pro` varchar(200) DEFAULT NULL,
  `mobile_perso` varchar(45) DEFAULT NULL,
  `mobile_pro` varchar(45) DEFAULT NULL,
  `fixe_perso` varchar(45) DEFAULT NULL,
  `fixe_pro` varchar(45) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `id_card` varchar(45) DEFAULT NULL,
  `passeport` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `profession` varchar(200) DEFAULT NULL,
  `societe` varchar(200) DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL,
  `photo_grand_format` varchar(150) DEFAULT NULL,
  `categorie_client` int(10) unsigned DEFAULT NULL,
  `carte_fidelite` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

/*!40000 ALTER TABLE `client` DISABLE KEYS */;
/*!40000 ALTER TABLE `client` ENABLE KEYS */;


--
-- Definition of table `etage`
--

CREATE TABLE IF NOT EXISTS `etage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(150) DEFAULT NULL,
  `bloc` int(10) unsigned DEFAULT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etage`
--

/*!40000 ALTER TABLE `etage` DISABLE KEYS */;
/*!40000 ALTER TABLE `etage` ENABLE KEYS */;


--
-- Definition of table `facture`
--

CREATE TABLE IF NOT EXISTS `facture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reservation` int(10) unsigned DEFAULT NULL,
  `details` varchar(300) DEFAULT NULL,
  `cout` varchar(45) NOT NULL,
  `etat` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facture`
--

/*!40000 ALTER TABLE `facture` DISABLE KEYS */;
/*!40000 ALTER TABLE `facture` ENABLE KEYS */;

--
-- Definition of table `facture_table`
--

CREATE TABLE IF NOT EXISTS `facture_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_id` int(10) unsigned NOT NULL,
  `info` varchar(300) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facture_table`
--

/*!40000 ALTER TABLE `facture_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `facture_table` ENABLE KEYS */;

--
-- Definition of table `info`
--

CREATE TABLE IF NOT EXISTS `info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `info` varchar(300) NOT NULL,
  `type_info` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

/*!40000 ALTER TABLE `info` DISABLE KEYS */;
/*!40000 ALTER TABLE `info` ENABLE KEYS */;


--
-- Definition of table `lit`
--

CREATE TABLE IF NOT EXISTS `lit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  `chambre` int(10) unsigned NOT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  `categorie_lit` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lit`
--

/*!40000 ALTER TABLE `lit` DISABLE KEYS */;
/*!40000 ALTER TABLE `lit` ENABLE KEYS */;


--
-- Definition of table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `info` varchar(400) NOT NULL,
  `login` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=441 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log`
--

/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;


--
-- Definition of table `mac`
--

CREATE TABLE IF NOT EXISTS `mac` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `addresse` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mac`
--

/*!40000 ALTER TABLE `mac` DISABLE KEYS */;
/*!40000 ALTER TABLE `mac` ENABLE KEYS */;


--
-- Definition of table `mac_ok`
--

CREATE TABLE IF NOT EXISTS `mac_ok` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mac` int(10) unsigned NOT NULL,
  `ok` tinyint(1) unsigned NOT NULL,
  `nb` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `cle` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mac_ok`
--

/*!40000 ALTER TABLE `mac_ok` DISABLE KEYS */;
/*!40000 ALTER TABLE `mac_ok` ENABLE KEYS */;


--
-- Definition of table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `categorie_menu` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;


--
-- Definition of table `pays`
--

DROP TABLE IF EXISTS `pays`;
CREATE TABLE `pays` (
  `nom` varchar(100) NOT NULL,
  `chemin_drapeau` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pays`
--

/*!40000 ALTER TABLE `pays` DISABLE KEYS */;
INSERT INTO `pays` (`nom`,`chemin_drapeau`) VALUES 
 ('AFGHANISTAN','afghanistan.gif'),
 ('ALBANIE','albanie.gif'),
 ('ALGERIE','algerie.gif'),
 ('ANDORRE','andorre.gif'),
 ('ANGOLA','angola.gif'),
 ('ANGUILLA','anguilla.gif'),
 ('ANTIGUA','antigua.gif'),
 ('ARGENTINE','argentine.gif'),
 ('ARUBA','aruba.gif'),
 ('AUSTRIA','austria.gif'),
 ('AZERBAIDJAN','azerbaidjan.gif'),
 ('BAHREIN','bahrein.gif'),
 ('BANGLADESH','bangladesh.gif'),
 ('BARBADOS','barbados.gif'),
 ('BELGICA','belgica.gif'),
 ('BELIZE','belize.gif'),
 ('BENIN','benin.gif'),
 ('BERMUDES','bermudes.gif'),
 ('BHUTAN','bhutan.gif'),
 ('BIELORUSSIE','bielorussie.gif'),
 ('BOLIVIE','bolivie.gif'),
 ('BOSNIE-HERZEGOVINE','bosnie-herzegovine.gif'),
 ('BOTSWANA','botswana.gif'),
 ('BRAZIL','brazil.gif'),
 ('BRUNEI','brunei.gif'),
 ('BULGARIE','bulgarie.gif'),
 ('BURKINA-FASO','burkina-faso.gif'),
 ('BURUNDI','burundi.gif'),
 ('CAMBODGE','cambodge.gif'),
 ('CAMEROUN','cameroun.gif'),
 ('CANADA','canada.gif'),
 ('CAP-VERT','cap-vert.gif'),
 ('CHILI','chili.gif'),
 ('CHINE','chine.gif'),
 ('CHYPRE','chypre.gif'),
 ('COLOMBIA','colombia.gif'),
 ('COMOROS','comoros.gif'),
 ('CONGO','congo.gif'),
 ('COSTA-RICA','costa-rica.gif'),
 ('COTE-IVOIRE','cote-ivoire.gif'),
 ('CROATIE','croatie.gif'),
 ('CUBA','cuba.gif'),
 ('DANEMARK','danemark.gif'),
 ('DJIBOUTI','djibouti.gif'),
 ('DOMINICA','dominica.gif'),
 ('ECUADOR','ecuador.gif'),
 ('EGYPTE','egypte.gif'),
 ('EMIRATS-ARABES-UNIS','emirats-arabes-unis.gif'),
 ('ERYTHREE','erythree.gif'),
 ('ESPAGNE','espagne.gif'),
 ('ESTONIE','estonie.gif'),
 ('FIDJI','fidji.gif'),
 ('FINLANDIA','finlandia.gif'),
 ('FRANCE','france.gif'),
 ('GABON','gabon.gif'),
 ('GAMBIE','gambie.gif'),
 ('GHANA','ghana.gif'),
 ('GRECE','grece.gif'),
 ('GRENADE','grenade.gif'),
 ('GUADALUPE','guadalupe.gif'),
 ('GUAM','guam.gif'),
 ('GUATEMALA','guatemala.gif'),
 ('GUINEA','guinea.gif'),
 ('GUINEE-EQUATORIALE','guinee-equatoriale.gif'),
 ('GUYANE','guyane.gif'),
 ('HAITI','haiti.gif'),
 ('HONDURAS','honduras.gif'),
 ('HONGRIE','hongrie.gif'),
 ('ILES-CAIMAN','iles-caiman.gif'),
 ('ILES-CHRISTMAS','iles-christmas.gif'),
 ('ILES-COCO','iles-coco.gif'),
 ('ILES-COOK','iles-cook.gif'),
 ('ILES-MARIANNES','iles-mariannes.gif'),
 ('ILES-MARSHALL','iles-marshall.gif'),
 ('ILES-NORFOLK','iles-norfolk.gif'),
 ('ILES-SALOMON','iles-salomon.gif'),
 ('ILES-SANDWICH','iles-sandwich.gif'),
 ('INDE','inde.gif'),
 ('INDONESIE','indonesie.gif'),
 ('IRAK','irak.gif'),
 ('IRAN','iran.gif'),
 ('IRLANDA','irlanda.gif'),
 ('ISLANDE','islande.gif'),
 ('ISRAEL','israel.gif'),
 ('ITALIA','italia.gif'),
 ('JAMAICA','jamaica.gif'),
 ('JAPAN','japan.gif'),
 ('JORDANIE','jordanie.gif'),
 ('KAZAKHSTAN','kazakhstan.gif'),
 ('KENYA','kenya.gif'),
 ('KIRGHIZISTAN','kirghizistan.gif'),
 ('KIRIBATI','kiribati.gif'),
 ('KOWEIT','koweit.gif'),
 ('LAOS','laos.gif'),
 ('LESOTHO','lesotho.gif'),
 ('LETTONIE','lettonie.gif'),
 ('LIBAN','liban.gif'),
 ('LIBERIA','liberia.gif'),
 ('LIECHTENSTEIN','liechtenstein.gif'),
 ('LITTUANIE','littuanie.gif'),
 ('LUXEMBURG','luxemburg.gif'),
 ('LYBIE','lybie.gif'),
 ('MACEDOINE','macedoine.gif'),
 ('MALAWI','malawi.gif'),
 ('MALAYSIA','malaysia.gif'),
 ('MALDIVES','maldives.gif'),
 ('MALI','mali.gif'),
 ('MALTE','malte.gif'),
 ('MAURICE','maurice.gif'),
 ('MAURITANIA','mauritania.gif'),
 ('MEXIQUE','mexique.gif'),
 ('MICRONESIE','micronesie.gif'),
 ('MOLDAVIE','moldavie.gif'),
 ('MONACO','monaco.gif'),
 ('MONGOLIE','mongolie.gif'),
 ('MONSERRAT','monserrat.gif'),
 ('MONTENEGROE','montenegroe.gif'),
 ('MOZAMBIQUE','mozambique.gif'),
 ('MYANMAR','myanmar.gif'),
 ('NAMIBIE','namibie.gif'),
 ('NAURU','nauru.gif'),
 ('NEPAL','nepal.gif'),
 ('NICARAGUA','nicaragua.gif'),
 ('NIGER','niger.gif'),
 ('NIGERIA','nigeria.gif'),
 ('NIUE','niue.gif'),
 ('NORTH KOREA','korea_north.gif'),
 ('NORVEGE','norvege.gif'),
 ('NOUVELLE-CALEDONIE','nouvelle-caledonie.gif'),
 ('NOUVELLE-ZELANDE','nouvelle-zelande.gif'),
 ('OMAN','oman.gif'),
 ('OUGANDA','ouganda.gif'),
 ('PAKISTAN','pakistan.gif'),
 ('PALAU','palau.gif'),
 ('PALESTINE','palestine.gif'),
 ('PANAMA','panama.gif'),
 ('PAPOUASIE-NOUVELLE-GUINEE','papouasie-nouvelle_guinee.gif'),
 ('PARAGUAY','paraguay.gif'),
 ('PAYS-BAS','pays-bas.gif'),
 ('PERU','peru.gif'),
 ('PHILLIPINES','phillipines.gif'),
 ('PITCAIRN','pitcairn.gif'),
 ('POLOGNE','pologne.gif'),
 ('PORTO-RICO','porto-rico.gif'),
 ('PORTUGAL','portugal.gif'),
 ('QATAR','qatar.gif'),
 ('REPUBLIQUE-CENTRAFRICAINE','republique_centrafricaine.gif'),
 ('REPUBLIQUE-CONGOLAISE','republique_congolaise.gif'),
 ('REPUBLIQUE-DOMINICAINE','republique_dominicaine.gif'),
 ('REPUBLIQUE-TCHEQUE','republique_tcheque.gif'),
 ('ROUMANIE','roumanie.gif'),
 ('RUSSIE','russie.gif'),
 ('RWANDA','rwanda.gif'),
 ('SAHARA-OCCIDENTAL','sahara-occidental.gif'),
 ('SAINT-CHRISTOPH-ET-NIEVES','saint-christoph-et-nieves.gif'),
 ('SAINT-HELENE','saint-helene.gif'),
 ('SAINT-MARIN','saint-marin.gif'),
 ('SAINT-VINCENT','saint_vincent.gif'),
 ('SAINTE-LUCIE','sainte-lucie.gif'),
 ('SAMOA','samoa.gif'),
 ('SAO-TOME-AND-PRINCIPE','sao_tome_and_principe.gif'),
 ('SAUDI-ARABIA','saudi_arabia.gif'),
 ('SENEGAL','senegal.gif'),
 ('SERBIE','serbie.gif'),
 ('SEYCHELLES','seychelles.gif'),
 ('SIERRA-LEONE','sierra_leone.gif'),
 ('SINGAPOUR','singapour.gif'),
 ('SLOVAQUIE','slovaquie.gif'),
 ('SLOVENIE','slovenie.gif'),
 ('SOMALIE','somalie.gif'),
 ('SOUDAN','soudan.gif'),
 ('SOUTH AFRICA','southafrica.gif'),
 ('SOUTH KOREA','korea_south.gif'),
 ('SRI LANKA','sri_lanka.gif'),
 ('SUEDE','suede.gif'),
 ('SUISSE','suisse.gif'),
 ('SURINAME','suriname.gif'),
 ('SWAZILAND','swaziland.gif'),
 ('SYRIE','syrie.gif'),
 ('TADJIKISTAN','tadjikistan.gif'),
 ('TAIWAN','taiwan.gif'),
 ('TANZANIE','tanzanie.gif'),
 ('TCHAD','tchad.gif'),
 ('THAILANDE','thailande.gif'),
 ('TIBET','tibet.gif'),
 ('TIMOR-ORIENTAL','timor-oriental.gif'),
 ('TOGO','togo.gif'),
 ('TOKELAU','tokelau.gif'),
 ('TONGA','tonga.gif'),
 ('TRINITE-TOBAGO','trinite-tobago.gif'),
 ('TUNISIE','tunisie.gif'),
 ('TURK-CAIQUE','turk-caique.gif'),
 ('TURKMENISTAN','turkmenistan.gif'),
 ('TURQUIE','turquie.gif'),
 ('TUVALU','tuvalu.gif'),
 ('UKRAINE','ukraine.gif'),
 ('URUGUAY','uruguay.gif'),
 ('USA','usa.gif'),
 ('UZBEKISTAN','uzbekistan.gif'),
 ('VANEZUELA','vanezuela.gif'),
 ('VANUATU','vanuatu.gif'),
 ('VATICAN','vatican.gif'),
 ('VIETNAM','vietnam.gif'),
 ('YEMEN','yemen.gif'),
 ('YUGOSLAVIA','yugoslavia.gif'),
 ('ZAMBIA','zambia.gif'),
 ('ZIMBABWE','zimbabwe.gif');
/*!40000 ALTER TABLE `pays` ENABLE KEYS */;


--
-- Definition of table `penalite`
--

CREATE TABLE IF NOT EXISTS `penalite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(300) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  `reservation` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penalite`
--

/*!40000 ALTER TABLE `penalite` DISABLE KEYS */;
/*!40000 ALTER TABLE `penalite` ENABLE KEYS */;


--
-- Definition of table `perte`
--

CREATE TABLE IF NOT EXISTS `perte` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(300) NOT NULL,
  `cout` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perte`
--

/*!40000 ALTER TABLE `perte` DISABLE KEYS */;
/*!40000 ALTER TABLE `perte` ENABLE KEYS */;


--
-- Definition of table `piscine`
--

CREATE TABLE IF NOT EXISTS `piscine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `prix_unitaire` varchar(45) NOT NULL,
  `prix_unitaire_enfant` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `piscine`
--

/*!40000 ALTER TABLE `piscine` DISABLE KEYS */;
/*!40000 ALTER TABLE `piscine` ENABLE KEYS */;


--
-- Definition of table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chambre` int(10) unsigned NOT NULL,
  `date_reservation` varchar(45) NOT NULL,
  `date_arrivee` varchar(45) NOT NULL,
  `date_depart` varchar(45) NOT NULL,
  `client` int(10) unsigned DEFAULT NULL,
  `etat_reservation` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;


--
-- Definition of table `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;


--
-- Definition of table `restaurant_vente`
--

CREATE TABLE IF NOT EXISTS `restaurant_vente` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `paye` tinyint(1) unsigned DEFAULT '0',
  `reservation` int(10) unsigned DEFAULT NULL,
  `serveur` int(10) unsigned DEFAULT NULL,
  `restaurant` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `cloture` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant_vente`
--

/*!40000 ALTER TABLE `restaurant_vente` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant_vente` ENABLE KEYS */;


--
-- Definition of table `serveur`
--

CREATE TABLE IF NOT EXISTS `serveur` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifiant` varchar(45) NOT NULL,
  `mention` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `serveur`
--

/*!40000 ALTER TABLE `serveur` DISABLE KEYS */;
/*!40000 ALTER TABLE `serveur` ENABLE KEYS */;


--
-- Definition of table `situation_chambre`
--

CREATE TABLE IF NOT EXISTS `situation_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `situation_chambre`
--

/*!40000 ALTER TABLE `situation_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `situation_chambre` ENABLE KEYS */;


--
-- Definition of table `stock_boisson`
--

CREATE TABLE IF NOT EXISTS `stock_boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `boisson` int(10) unsigned NOT NULL,
  `bar_vente` int(10) unsigned DEFAULT NULL,
  `provenance` varchar(100) DEFAULT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_boisson`
--

/*!40000 ALTER TABLE `stock_boisson` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_boisson` ENABLE KEYS */;


--
-- Definition of table `table_hotel`
--

CREATE TABLE IF NOT EXISTS `table_hotel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(45) DEFAULT NULL,
  `cloture` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_hotel`
--

/*!40000 ALTER TABLE `table_hotel` DISABLE KEYS */;
/*!40000 ALTER TABLE `table_hotel` ENABLE KEYS */;


--
-- Definition of table `type_chambre`
--

CREATE TABLE IF NOT EXISTS `type_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_chambre`
--

/*!40000 ALTER TABLE `type_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_chambre` ENABLE KEYS */;


--
-- Definition of table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(45) DEFAULT NULL,
  `prenoms` varchar(45) DEFAULT NULL,
  `login` varchar(45) NOT NULL,
  `passwd` varchar(45) NOT NULL,
  `tel` varchar(45) DEFAULT NULL,
  `accreditation` varchar(45) DEFAULT 'utilisateur',
  `photo` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utilisateur`
--

/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` (`id`,`nom`,`prenoms`,`login`,`passwd`,`tel`,`accreditation`,`photo`) VALUES
 (1,'admin',NULL,'admin','d033e22ae348aeb5660fc2140aec35850c4da997',NULL,'Administrateur','');
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;


--
-- Definition of table `vente_acces_piscine`
--

CREATE TABLE IF NOT EXISTS `vente_acces_piscine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `piscine` int(10) unsigned NOT NULL,
  `login` varchar(45) NOT NULL,
  `reservation` int(10) unsigned DEFAULT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vente_acces_piscine`
--

/*!40000 ALTER TABLE `vente_acces_piscine` DISABLE KEYS */;
/*!40000 ALTER TABLE `vente_acces_piscine` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
