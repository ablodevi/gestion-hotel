(Fran�ais)

Cette application est �crite en JAVA. 

Assurez vous d'avoir JAVA Runtime Environment (JRE) ainsi que MySQL Server install�s sur votre machine !

Installez la base de donn�es (fichier hotel.sql) sur votre serveur MySQL.
 
D�compressez les deux zip. D�placez le dossier lib contenant les librairies drectement � l'int�rieur du dossier HotelPro. 

Modifiez le fichier persistence (src -> META-INF -> persistence) en y mettant le mot de passe de votre serveur MySQL.

Compilez le projet dans votre IDE favori (moi je pr�f�re Netbeans).

C'est parti! :)



(English)

This software is written in JAVA.

Make sure JAVA Runtime Environment (JRE) and MySQL Server are installed on your computer ! 

Install the database (file hotel.sql) on your MySQL server.

Unzip both zips. Move the lib folder containing the libraries directly inside the HotelPro folder.

Modify the persistence file (src -> META-INF -> persistence) by putting the password of your MySQL Server.

Compile the project in your preferred IDE (I use Netbeans).

That's it. There you go!