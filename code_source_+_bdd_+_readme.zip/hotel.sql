-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.32-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema hotel
--

CREATE DATABASE IF NOT EXISTS hotel;
USE hotel;

--
-- Definition of table `accreditation`
--

DROP TABLE IF EXISTS `accreditation`;
CREATE TABLE `accreditation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(45) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accreditation`
--

/*!40000 ALTER TABLE `accreditation` DISABLE KEYS */;
INSERT INTO `accreditation` (`id`,`libelle`,`description`) VALUES 
 (1,'Utilisateur',NULL),
 (2,'Administrateur',NULL);
/*!40000 ALTER TABLE `accreditation` ENABLE KEYS */;


--
-- Definition of table `bar`
--

DROP TABLE IF EXISTS `bar`;
CREATE TABLE `bar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bar`
--

/*!40000 ALTER TABLE `bar` DISABLE KEYS */;
INSERT INTO `bar` (`id`,`libelle`,`description`) VALUES 
 (1,'MARYLAND',NULL);
/*!40000 ALTER TABLE `bar` ENABLE KEYS */;


--
-- Definition of table `bar_vente`
--

DROP TABLE IF EXISTS `bar_vente`;
CREATE TABLE `bar_vente` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boisson` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `paye` tinyint(1) unsigned DEFAULT '0',
  `reservation` int(10) unsigned DEFAULT NULL,
  `serveur` int(10) unsigned DEFAULT NULL,
  `bar` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `cloture` tinyint(1) unsigned DEFAULT '0',
  `date_facture` varchar(45) DEFAULT NULL,
  `num_facture` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bar_vente`
--

/*!40000 ALTER TABLE `bar_vente` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_vente` ENABLE KEYS */;


--
-- Definition of table `bloc`
--

DROP TABLE IF EXISTS `bloc`;
CREATE TABLE `bloc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(45) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloc`
--

/*!40000 ALTER TABLE `bloc` DISABLE KEYS */;
/*!40000 ALTER TABLE `bloc` ENABLE KEYS */;


--
-- Definition of table `boisson`
--

DROP TABLE IF EXISTS `boisson`;
CREATE TABLE `boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(45) DEFAULT NULL,
  `cout` varchar(45) DEFAULT NULL,
  `categorie_boisson` int(10) unsigned DEFAULT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boisson`
--

/*!40000 ALTER TABLE `boisson` DISABLE KEYS */;
INSERT INTO `boisson` (`id`,`libelle`,`cout`,`categorie_boisson`,`login`) VALUES 
 (1,'PILS 65','800',1,'admin'),
 (2,'PILS 33','500',1,'admin'),
 (3,'GUINESS 65','1200',1,'admin'),
 (4,'GUINESS 33','800',1,'admin'),
 (5,'CASTEL 65','800',1,'admin'),
 (6,'CASTEL 33','500',1,'admin'),
 (7,'EKU 65','1000',1,'admin'),
 (8,'EKU 33','800',1,'admin'),
 (9,'AWOOYO','1000',1,'admin'),
 (10,'33 EXPORT 33','500',1,'admin'),
 (11,'LION KILLER','800',1,'admin'),
 (12,'SODA WATER 33','500',1,'admin'),
 (13,'MALTA 33','500',1,'admin'),
 (14,'SPORT ACTIF 33','500',1,'admin'),
 (15,'COCKTAIL 30','500',1,'admin'),
 (16,'COCA 30','500',1,'admin'),
 (17,'SPRITE 30','500',1,'admin'),
 (18,'SCHWEPPS 33','500',1,'admin'),
 (19,'FANTA','500',1,'admin'),
 (20,'RED BULL','1000',1,'admin'),
 (21,'XXL 33','800',1,'admin'),
 (22,'COINTREAU','1500',3,'admin'),
 (23,'MARIE BRIZARE','1500',3,'admin'),
 (24,'COGNAC BISQUIT','2500',3,'admin'),
 (25,'ARMAGNAC','2000',3,'admin'),
 (26,'GRAND MARNIER','2000',3,'admin'),
 (27,'COGNAC XO','2000',3,'admin'),
 (28,'BLACK LABEL','2500',3,'admin'),
 (29,'DIMPLE','2500',3,'admin'),
 (30,'CHIVAS','2500',3,'admin'),
 (31,'JB','1000',3,'admin'),
 (32,'RED LABEL','1000',3,'admin'),
 (33,'GRANT\'S','1000',3,'admin'),
 (34,'RHUM BLANC','800',3,'admin'),
 (35,'RHUM','800',3,'admin'),
 (36,'GORDON GIN','800',3,'admin'),
 (37,'CAMPARI','1000',3,'admin'),
 (38,'RICARD','1300',3,'admin'),
 (39,'MARTINI ROUGE','800',3,'admin'),
 (40,'MARTINI BLANC','800',3,'admin'),
 (41,'PORTO','800',3,'admin'),
 (42,'SUZE','1000',3,'admin'),
 (43,'BAILLER\'S','1000',3,'admin'),
 (44,'BLEU DE CURACAO','500',3,'admin'),
 (45,'MALIBOU','1000',3,'admin'),
 (46,'CREME DE CASIS','500',3,'admin'),
 (47,'SIROP GRENADINE','500',3,'admin'),
 (48,'SIROP DE MENTHE','500',3,'admin'),
 (49,'SIROP CITRON','500',3,'admin'),
 (50,'BORDEAUX SAUVIGNON','6000',4,'admin'),
 (51,'SYLVANER SCHUTZ','6000',4,'admin'),
 (52,'VEUVES DE VERNAY','6000',5,'admin'),
 (53,'PROVENCE BILLETTE','7500',6,'admin'),
 (54,'MUSCADET SEVRE','6000',6,'admin'),
 (55,'DOMAINE DE LA LANDES','7000',6,'admin'),
 (56,'CÔTE DE PROVENCE','7000',6,'admin'),
 (57,'BORDEAUX CHÂTEAUX GRAVEYERES','6000',7,'admin'),
 (58,'BORDEAUX LOUIS DE COMPONAC','8000',7,'admin'),
 (59,'BORDEAUX BERGERAC','8000',7,'admin'),
 (60,'BORDEAUX REYNAUD LACOSTE','6500',7,'admin'),
 (61,'CÔTE DE RHÔNE BARAÏY','8000',7,'admin'),
 (62,'CÔTE DE RHÔNE VIEILLE VIGNE','8000',7,'admin'),
 (63,'VITALE 0.5','250',1,'admin'),
 (64,'VITALE 0.8','500',1,'admin'),
 (65,'VITALE 1.5','750',1,'admin'),
 (66,'GIN CAMPARI','1000',3,'admin'),
 (67,'JACK DANIEL\'S','2000',3,'admin');
/*!40000 ALTER TABLE `boisson` ENABLE KEYS */;


--
-- Definition of table `boisson_seuil`
--

DROP TABLE IF EXISTS `boisson_seuil`;
CREATE TABLE `boisson_seuil` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boisson` int(10) DEFAULT NULL,
  `seuil` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boisson_seuil`
--

/*!40000 ALTER TABLE `boisson_seuil` DISABLE KEYS */;
/*!40000 ALTER TABLE `boisson_seuil` ENABLE KEYS */;


--
-- Definition of table `caisse_bar`
--

DROP TABLE IF EXISTS `caisse_bar`;
CREATE TABLE `caisse_bar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `bar_vente` int(10) unsigned DEFAULT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_bar`
--

/*!40000 ALTER TABLE `caisse_bar` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_bar` ENABLE KEYS */;


--
-- Definition of table `caisse_divers`
--

DROP TABLE IF EXISTS `caisse_divers`;
CREATE TABLE `caisse_divers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `motif` varchar(200) NOT NULL,
  `variation` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_divers`
--

/*!40000 ALTER TABLE `caisse_divers` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_divers` ENABLE KEYS */;


--
-- Definition of table `caisse_piscine`
--

DROP TABLE IF EXISTS `caisse_piscine`;
CREATE TABLE `caisse_piscine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `vente_acces_piscine` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_piscine`
--

/*!40000 ALTER TABLE `caisse_piscine` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_piscine` ENABLE KEYS */;


--
-- Definition of table `caisse_reservation`
--

DROP TABLE IF EXISTS `caisse_reservation`;
CREATE TABLE `caisse_reservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `motif` varchar(200) DEFAULT NULL,
  `variation` varchar(45) NOT NULL,
  `reservation` int(10) unsigned DEFAULT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_reservation`
--

/*!40000 ALTER TABLE `caisse_reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_reservation` ENABLE KEYS */;


--
-- Definition of table `caisse_restaurant`
--

DROP TABLE IF EXISTS `caisse_restaurant`;
CREATE TABLE `caisse_restaurant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `restaurant_vente` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caisse_restaurant`
--

/*!40000 ALTER TABLE `caisse_restaurant` DISABLE KEYS */;
/*!40000 ALTER TABLE `caisse_restaurant` ENABLE KEYS */;


--
-- Definition of table `caracteristique_chambre`
--

DROP TABLE IF EXISTS `caracteristique_chambre`;
CREATE TABLE `caracteristique_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caracteristique_chambre`
--

/*!40000 ALTER TABLE `caracteristique_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `caracteristique_chambre` ENABLE KEYS */;


--
-- Definition of table `carte_fidelite`
--

DROP TABLE IF EXISTS `carte_fidelite`;
CREATE TABLE `carte_fidelite` (
  `id` int(10) unsigned NOT NULL,
  `client` int(10) unsigned NOT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carte_fidelite`
--

/*!40000 ALTER TABLE `carte_fidelite` DISABLE KEYS */;
/*!40000 ALTER TABLE `carte_fidelite` ENABLE KEYS */;


--
-- Definition of table `categorie_boisson`
--

DROP TABLE IF EXISTS `categorie_boisson`;
CREATE TABLE `categorie_boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_boisson`
--

/*!40000 ALTER TABLE `categorie_boisson` DISABLE KEYS */;
INSERT INTO `categorie_boisson` (`id`,`libelle`) VALUES 
 (1,'BOISSONS FRAÎCHES'),
 (2,'CHAMPAGNES'),
 (3,'SPIRITUEUX'),
 (4,'VINS BLANCS'),
 (5,'VINS MOUSSEUX'),
 (6,'VINS ROSES'),
 (7,'VINS ROUGES');
/*!40000 ALTER TABLE `categorie_boisson` ENABLE KEYS */;


--
-- Definition of table `categorie_chambre`
--

DROP TABLE IF EXISTS `categorie_chambre`;
CREATE TABLE `categorie_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_chambre`
--

/*!40000 ALTER TABLE `categorie_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_chambre` ENABLE KEYS */;


--
-- Definition of table `categorie_client`
--

DROP TABLE IF EXISTS `categorie_client`;
CREATE TABLE `categorie_client` (
  `id` int(10) unsigned NOT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`designation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_client`
--

/*!40000 ALTER TABLE `categorie_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_client` ENABLE KEYS */;


--
-- Definition of table `categorie_lit`
--

DROP TABLE IF EXISTS `categorie_lit`;
CREATE TABLE `categorie_lit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_lit`
--

/*!40000 ALTER TABLE `categorie_lit` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorie_lit` ENABLE KEYS */;


--
-- Definition of table `categorie_menu`
--

DROP TABLE IF EXISTS `categorie_menu`;
CREATE TABLE `categorie_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorie_menu`
--

/*!40000 ALTER TABLE `categorie_menu` DISABLE KEYS */;
INSERT INTO `categorie_menu` (`id`,`libelle`) VALUES 
 (1,'ACCOMPAGNEMENTS'),
 (3,'BOISSONS CHAUDES'),
 (2,'PLATS CHAUDS');
/*!40000 ALTER TABLE `categorie_menu` ENABLE KEYS */;


--
-- Definition of table `chambre`
--

DROP TABLE IF EXISTS `chambre`;
CREATE TABLE `chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `bloc` int(10) unsigned DEFAULT NULL,
  `categorie` int(10) unsigned DEFAULT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  `etage` int(10) unsigned DEFAULT NULL,
  `type_chambre` int(10) unsigned DEFAULT NULL,
  `caracteristique_chambre` int(10) unsigned DEFAULT NULL,
  `situation_chambre` int(10) unsigned DEFAULT NULL,
  `statut` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chambre`
--

/*!40000 ALTER TABLE `chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `chambre` ENABLE KEYS */;


--
-- Definition of table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(10) unsigned NOT NULL,
  `nom` varchar(45) DEFAULT NULL,
  `prenoms` varchar(200) DEFAULT NULL,
  `surnom` varchar(100) DEFAULT NULL,
  `but_visite` varchar(200) DEFAULT NULL,
  `age` varchar(45) DEFAULT NULL,
  `sexe` varchar(45) DEFAULT NULL,
  `pays_residence` varchar(100) DEFAULT NULL,
  `nationalite` varchar(100) DEFAULT NULL,
  `religion` varchar(200) DEFAULT NULL,
  `adresse_perso` varchar(200) DEFAULT NULL,
  `adresse_pro` varchar(200) DEFAULT NULL,
  `mobile_perso` varchar(45) DEFAULT NULL,
  `mobile_pro` varchar(45) DEFAULT NULL,
  `fixe_perso` varchar(45) DEFAULT NULL,
  `fixe_pro` varchar(45) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `id_card` varchar(45) DEFAULT NULL,
  `passeport` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `profession` varchar(200) DEFAULT NULL,
  `societe` varchar(200) DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL,
  `photo_grand_format` varchar(150) DEFAULT NULL,
  `categorie_client` int(10) unsigned DEFAULT NULL,
  `carte_fidelite` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

/*!40000 ALTER TABLE `client` DISABLE KEYS */;
/*!40000 ALTER TABLE `client` ENABLE KEYS */;


--
-- Definition of table `etage`
--

DROP TABLE IF EXISTS `etage`;
CREATE TABLE `etage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(150) DEFAULT NULL,
  `bloc` int(10) unsigned DEFAULT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etage`
--

/*!40000 ALTER TABLE `etage` DISABLE KEYS */;
/*!40000 ALTER TABLE `etage` ENABLE KEYS */;


--
-- Definition of table `facture`
--

DROP TABLE IF EXISTS `facture`;
CREATE TABLE `facture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reservation` int(10) unsigned DEFAULT NULL,
  `details` varchar(300) DEFAULT NULL,
  `cout` varchar(45) NOT NULL,
  `etat` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facture`
--

/*!40000 ALTER TABLE `facture` DISABLE KEYS */;
/*!40000 ALTER TABLE `facture` ENABLE KEYS */;


--
-- Definition of table `facture_table`
--

DROP TABLE IF EXISTS `facture_table`;
CREATE TABLE `facture_table` (
  `id` int(10) unsigned NOT NULL,
  `table_id` int(10) unsigned NOT NULL,
  `info` varchar(300) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `date_facture` varchar(45) DEFAULT NULL,
  `num_facture` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facture_table`
--

/*!40000 ALTER TABLE `facture_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `facture_table` ENABLE KEYS */;


--
-- Definition of table `flux_prix_boisson`
--

DROP TABLE IF EXISTS `flux_prix_boisson`;
CREATE TABLE `flux_prix_boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `boisson` int(10) unsigned NOT NULL,
  `prix` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flux_prix_boisson`
--

/*!40000 ALTER TABLE `flux_prix_boisson` DISABLE KEYS */;
/*!40000 ALTER TABLE `flux_prix_boisson` ENABLE KEYS */;


--
-- Definition of table `flux_prix_menu`
--

DROP TABLE IF EXISTS `flux_prix_menu`;
CREATE TABLE `flux_prix_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` int(10) unsigned NOT NULL,
  `prix` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flux_prix_menu`
--

/*!40000 ALTER TABLE `flux_prix_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `flux_prix_menu` ENABLE KEYS */;


--
-- Definition of table `info`
--

DROP TABLE IF EXISTS `info`;
CREATE TABLE `info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `info` varchar(300) NOT NULL,
  `type_info` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

/*!40000 ALTER TABLE `info` DISABLE KEYS */;
/*!40000 ALTER TABLE `info` ENABLE KEYS */;


--
-- Definition of table `lit`
--

DROP TABLE IF EXISTS `lit`;
CREATE TABLE `lit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  `chambre` int(10) unsigned NOT NULL,
  `disponibilite` tinyint(1) unsigned DEFAULT '1',
  `categorie_lit` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lit`
--

/*!40000 ALTER TABLE `lit` DISABLE KEYS */;
/*!40000 ALTER TABLE `lit` ENABLE KEYS */;


--
-- Definition of table `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `info` varchar(400) NOT NULL,
  `login` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log`
--

/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` (`id`,`info`,`login`,`date_heure`) VALUES 
 (1,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nThu Jun 06 12:31:05 UTC 2013 : Connexion réussie','admin','Thu Jun 06 12:31:06 UTC 2013'),
 (2,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nThu Jun 06 12:39:22 UTC 2013 : Connexion réussie','admin','Thu Jun 06 12:39:22 UTC 2013'),
 (3,'L\'utilisateur \'admin\' essaie de se connecter. \nThu Jun 06 12:40:46 UTC 2013 : Connection reussie de l\'admin admin','admin','Thu Jun 06 12:40:46 UTC 2013'),
 (4,'L\'utilisateur \'admin\' essaie de se connecter. \nThu Jun 06 12:41:42 UTC 2013 : Connection reussie de l\'admin admin','admin','Thu Jun 06 12:41:42 UTC 2013'),
 (5,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nThu Jun 06 13:09:07 UTC 2013 : Connexion réussie','admin','Thu Jun 06 13:09:07 UTC 2013'),
 (6,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nThu Jun 06 13:16:08 UTC 2013 : Connexion réussie','admin','Thu Jun 06 13:16:08 UTC 2013'),
 (7,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nSat Jun 08 17:41:49 UTC 2013 : Connexion réussie','admin','Sat Jun 08 17:41:49 UTC 2013'),
 (8,'L\'utilisateur \'admin\' essaie de se connecter. \nSat Jun 08 17:58:48 UTC 2013 : Connection reussie de l\'admin admin','admin','Sat Jun 08 17:58:48 UTC 2013'),
 (9,'L\'utilisateur \'admin\' essaie de se reconnecter. \nSat Jun 08 17:59:07 UTC 2013 : Connexion reussie','admin','Sat Jun 08 17:59:07 UTC 2013'),
 (10,'L\'utilisateur \'admin\' essaie de se connecter. \nSat Jun 08 17:59:43 UTC 2013 : Connection reussie de l\'admin admin','admin','Sat Jun 08 17:59:43 UTC 2013'),
 (11,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nSat Jun 08 19:35:28 UTC 2013 : Connexion réussie','admin','Sat Jun 08 19:35:28 UTC 2013'),
 (12,'L\'utilisateur \'admin\' essaie de se connecter. \nSat Jun 08 19:36:02 UTC 2013 : Connection reussie de l\'admin admin','admin','Sat Jun 08 19:36:02 UTC 2013'),
 (13,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 00:27:32 UTC 2013 : Connexion réussie','admin','Wed Jun 12 00:27:32 UTC 2013'),
 (14,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 00:34:35 UTC 2013 : Connexion réussie','admin','Wed Jun 12 00:34:35 UTC 2013'),
 (15,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 00:40:39 UTC 2013 : Connexion réussie','admin','Wed Jun 12 00:40:39 UTC 2013'),
 (16,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 00:50:15 UTC 2013 : Connexion réussie','admin','Wed Jun 12 00:50:15 UTC 2013'),
 (17,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 07:46:48 UTC 2013 : Connexion réussie','admin','Wed Jun 12 07:46:48 UTC 2013'),
 (18,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 08:23:54 UTC 2013 : Connexion réussie','admin','Wed Jun 12 08:23:54 UTC 2013'),
 (19,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 08:33:54 UTC 2013 : Connexion réussie','admin','Wed Jun 12 08:33:54 UTC 2013'),
 (20,'L\'utilisateur \'admin\' essaie de se connecter. \nWed Jun 12 08:36:52 UTC 2013 : Connection reussie de l\'admin admin','admin','Wed Jun 12 08:36:52 UTC 2013'),
 (21,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nWed Jun 12 08:40:09 UTC 2013 : Connexion réussie','admin','Wed Jun 12 08:40:09 UTC 2013'),
 (22,'L\'utilisateur \'admin\' essaie de se connecter à HOTEL PRO. \nTue Jun 18 19:37:44 UTC 2013 : Connexion réussie','admin','Tue Jun 18 19:37:44 UTC 2013');
/*!40000 ALTER TABLE `log` ENABLE KEYS */;


--
-- Definition of table `mac`
--

DROP TABLE IF EXISTS `mac`;
CREATE TABLE `mac` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `addresse` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mac`
--

/*!40000 ALTER TABLE `mac` DISABLE KEYS */;
/*!40000 ALTER TABLE `mac` ENABLE KEYS */;


--
-- Definition of table `mac_ok`
--

DROP TABLE IF EXISTS `mac_ok`;
CREATE TABLE `mac_ok` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mac` int(10) unsigned NOT NULL,
  `ok` tinyint(1) unsigned NOT NULL,
  `nb` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `cle` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mac_ok`
--

/*!40000 ALTER TABLE `mac_ok` DISABLE KEYS */;
/*!40000 ALTER TABLE `mac_ok` ENABLE KEYS */;


--
-- Definition of table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `categorie_menu` int(10) unsigned DEFAULT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`libelle`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`id`,`libelle`,`cout`,`categorie_menu`,`login`) VALUES 
 (1,'FILET DE POULET','3000',2,'admin'),
 (2,'CÔTE DE PORC','3000',2,'admin'),
 (3,'STEAK','3000',2,'admin'),
 (4,'CAFE','500',3,'admin'),
 (5,'THE','500',3,'admin'),
 (6,'YEBESSESSI','2500',1,'admin');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;


--
-- Definition of table `pays`
--

DROP TABLE IF EXISTS `pays`;
CREATE TABLE `pays` (
  `nom` varchar(100) NOT NULL,
  `chemin_drapeau` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pays`
--

/*!40000 ALTER TABLE `pays` DISABLE KEYS */;
INSERT INTO `pays` (`nom`,`chemin_drapeau`) VALUES 
 ('AFGHANISTAN','afghanistan.gif'),
 ('ALBANIE','albanie.gif'),
 ('ALGERIE','algerie.gif'),
 ('ANDORRE','andorre.gif'),
 ('ANGOLA','angola.gif'),
 ('ANGUILLA','anguilla.gif'),
 ('ANTIGUA','antigua.gif'),
 ('ARGENTINE','argentine.gif'),
 ('ARUBA','aruba.gif'),
 ('AUSTRIA','austria.gif'),
 ('AZERBAIDJAN','azerbaidjan.gif'),
 ('BAHREIN','bahrein.gif'),
 ('BANGLADESH','bangladesh.gif'),
 ('BARBADOS','barbados.gif'),
 ('BELGICA','belgica.gif'),
 ('BELIZE','belize.gif'),
 ('BENIN','benin.gif'),
 ('BERMUDES','bermudes.gif'),
 ('BHUTAN','bhutan.gif'),
 ('BIELORUSSIE','bielorussie.gif'),
 ('BOLIVIE','bolivie.gif'),
 ('BOSNIE-HERZEGOVINE','bosnie-herzegovine.gif'),
 ('BOTSWANA','botswana.gif'),
 ('BRAZIL','brazil.gif'),
 ('BRUNEI','brunei.gif'),
 ('BULGARIE','bulgarie.gif'),
 ('BURKINA-FASO','burkina-faso.gif'),
 ('BURUNDI','burundi.gif'),
 ('CAMBODGE','cambodge.gif'),
 ('CAMEROUN','cameroun.gif'),
 ('CANADA','canada.gif'),
 ('CAP-VERT','cap-vert.gif'),
 ('CHILI','chili.gif'),
 ('CHINE','chine.gif'),
 ('CHYPRE','chypre.gif'),
 ('COLOMBIA','colombia.gif'),
 ('COMOROS','comoros.gif'),
 ('CONGO','congo.gif'),
 ('COSTA-RICA','costa-rica.gif'),
 ('COTE-IVOIRE','cote-ivoire.gif'),
 ('CROATIE','croatie.gif'),
 ('CUBA','cuba.gif'),
 ('DANEMARK','danemark.gif'),
 ('DJIBOUTI','djibouti.gif'),
 ('DOMINICA','dominica.gif'),
 ('ECUADOR','ecuador.gif'),
 ('EGYPTE','egypte.gif'),
 ('EMIRATS-ARABES-UNIS','emirats-arabes-unis.gif'),
 ('ERYTHREE','erythree.gif'),
 ('ESPAGNE','espagne.gif'),
 ('ESTONIE','estonie.gif'),
 ('FIDJI','fidji.gif'),
 ('FINLANDIA','finlandia.gif'),
 ('FRANCE','france.gif'),
 ('GABON','gabon.gif'),
 ('GAMBIE','gambie.gif'),
 ('GHANA','ghana.gif'),
 ('GRECE','grece.gif'),
 ('GRENADE','grenade.gif'),
 ('GUADALUPE','guadalupe.gif'),
 ('GUAM','guam.gif'),
 ('GUATEMALA','guatemala.gif'),
 ('GUINEA','guinea.gif'),
 ('GUINEE-EQUATORIALE','guinee-equatoriale.gif'),
 ('GUYANE','guyane.gif'),
 ('HAITI','haiti.gif'),
 ('HONDURAS','honduras.gif'),
 ('HONGRIE','hongrie.gif'),
 ('ILES-CAIMAN','iles-caiman.gif'),
 ('ILES-CHRISTMAS','iles-christmas.gif'),
 ('ILES-COCO','iles-coco.gif'),
 ('ILES-COOK','iles-cook.gif'),
 ('ILES-MARIANNES','iles-mariannes.gif'),
 ('ILES-MARSHALL','iles-marshall.gif'),
 ('ILES-NORFOLK','iles-norfolk.gif'),
 ('ILES-SALOMON','iles-salomon.gif'),
 ('ILES-SANDWICH','iles-sandwich.gif'),
 ('INDE','inde.gif'),
 ('INDONESIE','indonesie.gif'),
 ('IRAK','irak.gif'),
 ('IRAN','iran.gif'),
 ('IRLANDA','irlanda.gif'),
 ('ISLANDE','islande.gif'),
 ('ISRAEL','israel.gif'),
 ('ITALIA','italia.gif'),
 ('JAMAICA','jamaica.gif'),
 ('JAPAN','japan.gif'),
 ('JORDANIE','jordanie.gif'),
 ('KAZAKHSTAN','kazakhstan.gif'),
 ('KENYA','kenya.gif'),
 ('KIRGHIZISTAN','kirghizistan.gif'),
 ('KIRIBATI','kiribati.gif'),
 ('KOWEIT','koweit.gif'),
 ('LAOS','laos.gif'),
 ('LESOTHO','lesotho.gif'),
 ('LETTONIE','lettonie.gif'),
 ('LIBAN','liban.gif'),
 ('LIBERIA','liberia.gif'),
 ('LIECHTENSTEIN','liechtenstein.gif'),
 ('LITTUANIE','littuanie.gif'),
 ('LUXEMBURG','luxemburg.gif'),
 ('LYBIE','lybie.gif'),
 ('MACEDOINE','macedoine.gif'),
 ('MALAWI','malawi.gif'),
 ('MALAYSIA','malaysia.gif'),
 ('MALDIVES','maldives.gif'),
 ('MALI','mali.gif'),
 ('MALTE','malte.gif'),
 ('MAURICE','maurice.gif'),
 ('MAURITANIA','mauritania.gif'),
 ('MEXIQUE','mexique.gif'),
 ('MICRONESIE','micronesie.gif'),
 ('MOLDAVIE','moldavie.gif'),
 ('MONACO','monaco.gif'),
 ('MONGOLIE','mongolie.gif'),
 ('MONSERRAT','monserrat.gif'),
 ('MONTENEGROE','montenegroe.gif'),
 ('MOZAMBIQUE','mozambique.gif'),
 ('MYANMAR','myanmar.gif'),
 ('NAMIBIE','namibie.gif'),
 ('NAURU','nauru.gif'),
 ('NEPAL','nepal.gif'),
 ('NICARAGUA','nicaragua.gif'),
 ('NIGER','niger.gif'),
 ('NIGERIA','nigeria.gif'),
 ('NIUE','niue.gif'),
 ('NORTH KOREA','korea_north.gif'),
 ('NORVEGE','norvege.gif'),
 ('NOUVELLE-CALEDONIE','nouvelle-caledonie.gif'),
 ('NOUVELLE-ZELANDE','nouvelle-zelande.gif'),
 ('OMAN','oman.gif'),
 ('OUGANDA','ouganda.gif'),
 ('PAKISTAN','pakistan.gif'),
 ('PALAU','palau.gif'),
 ('PALESTINE','palestine.gif'),
 ('PANAMA','panama.gif'),
 ('PAPOUASIE-NOUVELLE-GUINEE','papouasie-nouvelle_guinee.gif'),
 ('PARAGUAY','paraguay.gif'),
 ('PAYS-BAS','pays-bas.gif'),
 ('PERU','peru.gif'),
 ('PHILLIPINES','phillipines.gif'),
 ('PITCAIRN','pitcairn.gif'),
 ('POLOGNE','pologne.gif'),
 ('PORTO-RICO','porto-rico.gif'),
 ('PORTUGAL','portugal.gif'),
 ('QATAR','qatar.gif'),
 ('REPUBLIQUE-CENTRAFRICAINE','republique_centrafricaine.gif'),
 ('REPUBLIQUE-CONGOLAISE','republique_congolaise.gif'),
 ('REPUBLIQUE-DOMINICAINE','republique_dominicaine.gif'),
 ('REPUBLIQUE-TCHEQUE','republique_tcheque.gif'),
 ('ROUMANIE','roumanie.gif'),
 ('RUSSIE','russie.gif'),
 ('RWANDA','rwanda.gif'),
 ('SAHARA-OCCIDENTAL','sahara-occidental.gif'),
 ('SAINT-CHRISTOPH-ET-NIEVES','saint-christoph-et-nieves.gif'),
 ('SAINT-HELENE','saint-helene.gif'),
 ('SAINT-MARIN','saint-marin.gif'),
 ('SAINT-VINCENT','saint_vincent.gif'),
 ('SAINTE-LUCIE','sainte-lucie.gif'),
 ('SAMOA','samoa.gif'),
 ('SAO-TOME-AND-PRINCIPE','sao_tome_and_principe.gif'),
 ('SAUDI-ARABIA','saudi_arabia.gif'),
 ('SENEGAL','senegal.gif'),
 ('SERBIE','serbie.gif'),
 ('SEYCHELLES','seychelles.gif'),
 ('SIERRA-LEONE','sierra_leone.gif'),
 ('SINGAPOUR','singapour.gif'),
 ('SLOVAQUIE','slovaquie.gif'),
 ('SLOVENIE','slovenie.gif'),
 ('SOMALIE','somalie.gif'),
 ('SOUDAN','soudan.gif'),
 ('SOUTH AFRICA','southafrica.gif'),
 ('SOUTH KOREA','korea_south.gif'),
 ('SRI LANKA','sri_lanka.gif'),
 ('SUEDE','suede.gif'),
 ('SUISSE','suisse.gif'),
 ('SURINAME','suriname.gif'),
 ('SWAZILAND','swaziland.gif'),
 ('SYRIE','syrie.gif'),
 ('TADJIKISTAN','tadjikistan.gif'),
 ('TAIWAN','taiwan.gif'),
 ('TANZANIE','tanzanie.gif'),
 ('TCHAD','tchad.gif'),
 ('THAILANDE','thailande.gif'),
 ('TIBET','tibet.gif'),
 ('TIMOR-ORIENTAL','timor-oriental.gif'),
 ('TOGO','togo.gif'),
 ('TOKELAU','tokelau.gif'),
 ('TONGA','tonga.gif'),
 ('TRINITE-TOBAGO','trinite-tobago.gif'),
 ('TUNISIE','tunisie.gif'),
 ('TURK-CAIQUE','turk-caique.gif'),
 ('TURKMENISTAN','turkmenistan.gif'),
 ('TURQUIE','turquie.gif'),
 ('TUVALU','tuvalu.gif'),
 ('UKRAINE','ukraine.gif'),
 ('URUGUAY','uruguay.gif'),
 ('USA','usa.gif'),
 ('UZBEKISTAN','uzbekistan.gif'),
 ('VANEZUELA','vanezuela.gif'),
 ('VANUATU','vanuatu.gif'),
 ('VATICAN','vatican.gif'),
 ('VIETNAM','vietnam.gif'),
 ('YEMEN','yemen.gif'),
 ('YUGOSLAVIA','yugoslavia.gif'),
 ('ZAMBIA','zambia.gif'),
 ('ZIMBABWE','zimbabwe.gif');
/*!40000 ALTER TABLE `pays` ENABLE KEYS */;


--
-- Definition of table `penalite`
--

DROP TABLE IF EXISTS `penalite`;
CREATE TABLE `penalite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(300) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  `reservation` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penalite`
--

/*!40000 ALTER TABLE `penalite` DISABLE KEYS */;
/*!40000 ALTER TABLE `penalite` ENABLE KEYS */;


--
-- Definition of table `perte`
--

DROP TABLE IF EXISTS `perte`;
CREATE TABLE `perte` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(300) NOT NULL,
  `cout` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perte`
--

/*!40000 ALTER TABLE `perte` DISABLE KEYS */;
/*!40000 ALTER TABLE `perte` ENABLE KEYS */;


--
-- Definition of table `piscine`
--

DROP TABLE IF EXISTS `piscine`;
CREATE TABLE `piscine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `prix_unitaire` varchar(45) NOT NULL,
  `prix_unitaire_enfant` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `piscine`
--

/*!40000 ALTER TABLE `piscine` DISABLE KEYS */;
/*!40000 ALTER TABLE `piscine` ENABLE KEYS */;


--
-- Definition of table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
CREATE TABLE `reservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chambre` int(10) unsigned NOT NULL,
  `date_reservation` varchar(45) NOT NULL,
  `date_arrivee` varchar(45) NOT NULL,
  `date_depart` varchar(45) NOT NULL,
  `client` int(10) unsigned DEFAULT NULL,
  `etat_reservation` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;


--
-- Definition of table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
CREATE TABLE `restaurant` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` (`id`,`libelle`,`description`) VALUES 
 (1,'MARYLAND',NULL);
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;


--
-- Definition of table `restaurant_vente`
--

DROP TABLE IF EXISTS `restaurant_vente`;
CREATE TABLE `restaurant_vente` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` int(10) unsigned NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `paye` tinyint(1) unsigned DEFAULT '0',
  `reservation` int(10) unsigned DEFAULT NULL,
  `serveur` int(10) unsigned DEFAULT NULL,
  `restaurant` int(10) unsigned NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `cloture` tinyint(1) unsigned DEFAULT '0',
  `date_facture` varchar(45) DEFAULT NULL,
  `num_facture` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant_vente`
--

/*!40000 ALTER TABLE `restaurant_vente` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant_vente` ENABLE KEYS */;


--
-- Definition of table `serveur`
--

DROP TABLE IF EXISTS `serveur`;
CREATE TABLE `serveur` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifiant` varchar(45) NOT NULL,
  `mention` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `serveur`
--

/*!40000 ALTER TABLE `serveur` DISABLE KEYS */;
INSERT INTO `serveur` (`id`,`identifiant`,`mention`) VALUES 
 (1,'Bob','GERANT');
/*!40000 ALTER TABLE `serveur` ENABLE KEYS */;


--
-- Definition of table `situation_chambre`
--

DROP TABLE IF EXISTS `situation_chambre`;
CREATE TABLE `situation_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `situation_chambre`
--

/*!40000 ALTER TABLE `situation_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `situation_chambre` ENABLE KEYS */;


--
-- Definition of table `stock_boisson`
--

DROP TABLE IF EXISTS `stock_boisson`;
CREATE TABLE `stock_boisson` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation` varchar(45) NOT NULL,
  `date_heure` varchar(45) NOT NULL,
  `boisson` int(10) unsigned NOT NULL,
  `bar_vente` int(10) unsigned DEFAULT NULL,
  `provenance` varchar(100) DEFAULT NULL,
  `login` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_boisson`
--

/*!40000 ALTER TABLE `stock_boisson` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_boisson` ENABLE KEYS */;


--
-- Definition of table `table_hotel`
--

DROP TABLE IF EXISTS `table_hotel`;
CREATE TABLE `table_hotel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(45) DEFAULT NULL,
  `cloture` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_hotel`
--

/*!40000 ALTER TABLE `table_hotel` DISABLE KEYS */;
INSERT INTO `table_hotel` (`id`,`designation`,`cloture`) VALUES 
 (1,'Table 1',1),
 (2,'Table 2',1),
 (3,'Table 3',1),
 (4,'Table 4',1),
 (5,'Table 5',1),
 (6,'Table 6',1),
 (7,'Table 7',1),
 (8,'Table 8',1),
 (9,'Table 9',1),
 (10,'Table 10',1),
 (11,'Table 11',1),
 (12,'Table 12',1),
 (13,'Table 13',1),
 (14,'Table 14',1),
 (15,'Table 15',1);
/*!40000 ALTER TABLE `table_hotel` ENABLE KEYS */;


--
-- Definition of table `type_chambre`
--

DROP TABLE IF EXISTS `type_chambre`;
CREATE TABLE `type_chambre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) NOT NULL,
  `cout` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_chambre`
--

/*!40000 ALTER TABLE `type_chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_chambre` ENABLE KEYS */;


--
-- Definition of table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE `utilisateur` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(45) DEFAULT NULL,
  `prenoms` varchar(45) DEFAULT NULL,
  `login` varchar(45) NOT NULL,
  `passwd` varchar(45) NOT NULL,
  `tel` varchar(45) DEFAULT NULL,
  `accreditation` varchar(45) DEFAULT 'utilisateur',
  `photo` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_2` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utilisateur`
--

/*!40000 ALTER TABLE `utilisateur` DISABLE KEYS */;
INSERT INTO `utilisateur` (`id`,`nom`,`prenoms`,`login`,`passwd`,`tel`,`accreditation`,`photo`) VALUES 
 (1,'admin',NULL,'admin','d033e22ae348aeb5660fc2140aec35850c4da997',NULL,'Administrateur','');
/*!40000 ALTER TABLE `utilisateur` ENABLE KEYS */;


--
-- Definition of table `vente_acces_piscine`
--

DROP TABLE IF EXISTS `vente_acces_piscine`;
CREATE TABLE `vente_acces_piscine` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `cout` varchar(45) NOT NULL,
  `piscine` int(10) unsigned NOT NULL,
  `login` varchar(45) NOT NULL,
  `reservation` int(10) unsigned DEFAULT NULL,
  `date_heure` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vente_acces_piscine`
--

/*!40000 ALTER TABLE `vente_acces_piscine` DISABLE KEYS */;
/*!40000 ALTER TABLE `vente_acces_piscine` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
